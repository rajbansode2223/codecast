import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").notNull().default("viewer"), // viewer, creator, admin
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  embedUrl: text("embed_url"), // YouTube/Vimeo URL
  thumbnailUrl: text("thumbnail_url"),
  duration: integer("duration"), // in seconds
  category: varchar("category").notNull(), // Frontend, Backend, System Design, etc.
  difficulty: varchar("difficulty").notNull(), // Beginner, Intermediate, Advanced
  tags: text("tags").array().default([]), // Array of tag strings
  creatorId: varchar("creator_id").notNull().references(() => users.id),
  views: integer("views").default(0),
  likes: integer("likes").default(0),
  dislikes: integer("dislikes").default(0),
  isPublished: boolean("is_published").default(true),
  
  // Developer-focused unique features
  codeSnippets: text("code_snippets").array().default([]), // Code snippets shown in video
  githubRepo: text("github_repo"), // Associated GitHub repository
  stackOverflowLinks: text("stackoverflow_links").array().default([]), // Related SO questions
  prerequisites: text("prerequisites").array().default([]), // Required knowledge
  learningOutcomes: text("learning_outcomes").array().default([]), // What viewers will learn
  estimatedWatchTime: integer("estimated_watch_time"), // AI-suggested optimal watch time
  hasLiveDemo: boolean("has_live_demo").default(false), // Contains live coding demo
  complexity: integer("complexity").default(1), // 1-10 scale for algorithmic complexity
  industryRelevance: text("industry_relevance").array().default([]), // Industry applications
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  videoId: integer("video_id").notNull().references(() => videos.id, { onDelete: "cascade" }),
  userId: varchar("user_id").references(() => users.id), // nullable for anonymous comments
  isAnonymous: boolean("is_anonymous").default(true),
  isModerated: boolean("is_moderated").default(false),
  isFlagged: boolean("is_flagged").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const videoLikes = pgTable("video_likes", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").notNull().references(() => videos.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  isLike: boolean("is_like").notNull(), // true for like, false for dislike
  createdAt: timestamp("created_at").defaultNow(),
});

export const watchHistory = pgTable("watch_history", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").notNull().references(() => videos.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  watchedAt: timestamp("watched_at").defaultNow(),
  watchDuration: integer("watch_duration"), // seconds watched
});

// Learning Paths - Unique feature for structured learning
export const learningPaths = pgTable("learning_paths", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  creatorId: varchar("creator_id").notNull().references(() => users.id),
  category: varchar("category").notNull(),
  difficulty: varchar("difficulty").notNull(),
  estimatedHours: integer("estimated_hours").default(0),
  tags: text("tags").array().default([]),
  isPublished: boolean("is_published").default(false),
  enrollmentCount: integer("enrollment_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Learning Path Videos - Junction table for ordered video sequences
export const learningPathVideos = pgTable("learning_path_videos", {
  id: serial("id").primaryKey(),
  pathId: integer("path_id").notNull().references(() => learningPaths.id, { onDelete: "cascade" }),
  videoId: integer("video_id").notNull().references(() => videos.id, { onDelete: "cascade" }),
  order: integer("order").notNull(),
  isOptional: boolean("is_optional").default(false),
  notes: text("notes"), // Path creator's notes for this video
});

// Code Challenges - Interactive coding challenges linked to videos
export const codeChallenges = pgTable("code_challenges", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").references(() => videos.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description").notNull(),
  startingCode: text("starting_code"),
  solutionCode: text("solution_code"),
  testCases: text("test_cases").array().default([]),
  language: varchar("language").notNull(), // JavaScript, Python, etc.
  difficulty: varchar("difficulty").notNull(),
  hints: text("hints").array().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

// User Progress - Track learning journey
export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  videoId: integer("video_id").references(() => videos.id, { onDelete: "cascade" }),
  pathId: integer("path_id").references(() => learningPaths.id, { onDelete: "cascade" }),
  challengeId: integer("challenge_id").references(() => codeChallenges.id, { onDelete: "cascade" }),
  status: varchar("status").notNull(), // watching, completed, bookmarked, etc.
  completedAt: timestamp("completed_at"),
  notes: text("notes"), // User's personal notes
  rating: integer("rating"), // 1-5 stars
  createdAt: timestamp("created_at").defaultNow(),
});

// Study Groups - Collaborative learning
export const studyGroups = pgTable("study_groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  creatorId: varchar("creator_id").notNull().references(() => users.id),
  pathId: integer("path_id").references(() => learningPaths.id),
  isPrivate: boolean("is_private").default(false),
  memberLimit: integer("member_limit").default(50),
  currentMembers: integer("current_members").default(1),
  meetingSchedule: text("meeting_schedule"), // JSON string for meeting times
  discordLink: text("discord_link"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Skill Assessments - Test knowledge before/after videos
export const skillAssessments = pgTable("skill_assessments", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  category: varchar("category").notNull(),
  difficulty: varchar("difficulty").notNull(),
  questions: text("questions").array().default([]), // JSON array of questions
  passingScore: integer("passing_score").default(70),
  timeLimit: integer("time_limit"), // minutes
  createdAt: timestamp("created_at").defaultNow(),
});

// Code Reviews - Peer review system
export const codeReviews = pgTable("code_reviews", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").notNull().references(() => videos.id, { onDelete: "cascade" }),
  submitterId: varchar("submitter_id").notNull().references(() => users.id),
  reviewerId: varchar("reviewer_id").references(() => users.id),
  codeSubmission: text("code_submission").notNull(),
  reviewComments: text("review_comments"),
  status: varchar("status").default("pending"), // pending, reviewed, approved
  rating: integer("rating"), // 1-5 stars
  createdAt: timestamp("created_at").defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
});

// AI-Powered Code Analysis & Performance Insights
export const codeAnalysis = pgTable("code_analysis", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").notNull().references(() => videos.id, { onDelete: "cascade" }),
  codeSnippet: text("code_snippet").notNull(),
  language: varchar("language").notNull(),
  complexityScore: integer("complexity_score"), // 1-10 cyclomatic complexity
  performanceMetrics: jsonb("performance_metrics"), // Big O notation, execution time predictions
  securityVulnerabilities: text("security_vulnerabilities").array().default([]),
  codeSmells: text("code_smells").array().default([]),
  optimizationSuggestions: text("optimization_suggestions").array().default([]),
  industryBenchmarks: jsonb("industry_benchmarks"), // How it compares to industry standards
  maintainabilityScore: integer("maintainability_score"), // 1-100
  testability: integer("testability"), // How easily testable the code is
  createdAt: timestamp("created_at").defaultNow(),
});

// Real-time Collaborative Coding Sessions
export const collaborationSessions = pgTable("collaboration_sessions", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").notNull().references(() => videos.id, { onDelete: "cascade" }),
  hostId: varchar("host_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  maxParticipants: integer("max_participants").default(10),
  currentParticipants: integer("current_participants").default(0),
  isActive: boolean("is_active").default(true),
  codeEnvironment: varchar("code_environment"), // replit, codesandbox, stackblitz
  sharedCodeUrl: text("shared_code_url"),
  voiceChatEnabled: boolean("voice_chat_enabled").default(false),
  screenShareEnabled: boolean("screen_share_enabled").default(false),
  scheduledAt: timestamp("scheduled_at"),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Interactive Code Execution with Live Results
export const codeExecutions = pgTable("code_executions", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").notNull().references(() => videos.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id),
  code: text("code").notNull(),
  language: varchar("language").notNull(),
  input: text("input"),
  output: text("output"),
  executionTime: integer("execution_time"), // milliseconds
  memoryUsage: integer("memory_usage"), // bytes
  cpuUsage: integer("cpu_usage"), // percentage
  exitCode: integer("exit_code"),
  errorMessage: text("error_message"),
  environmentVersion: varchar("environment_version"),
  dependencies: text("dependencies").array().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

// Advanced Git Integration & Version Control Tracking
export const gitIntegrations = pgTable("git_integrations", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").notNull().references(() => videos.id, { onDelete: "cascade" }),
  repositoryUrl: text("repository_url").notNull(),
  branch: varchar("branch").default("main"),
  commitHash: varchar("commit_hash"),
  pullRequestUrl: text("pull_request_url"),
  issueTags: text("issue_tags").array().default([]),
  contributorCount: integer("contributor_count"),
  lastCommitMessage: text("last_commit_message"),
  codeFrequency: jsonb("code_frequency"), // Lines added/removed over time
  languageDistribution: jsonb("language_distribution"),
  lastSyncAt: timestamp("last_sync_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Comprehensive Learning Analytics & Progress Tracking
export const learningAnalytics = pgTable("learning_analytics", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  videoId: integer("video_id").notNull().references(() => videos.id, { onDelete: "cascade" }),
  watchTime: integer("watch_time"), // Total seconds watched
  completionPercentage: integer("completion_percentage"), // 0-100
  pausePoints: jsonb("pause_points"), // Array of timestamps where user paused
  rewindSections: jsonb("rewind_sections"), // Sections user rewound multiple times
  playbackSpeed: integer("playback_speed").default(100), // Preferred speed percentage
  codeInteractions: integer("code_interactions").default(0),
  notesCount: integer("notes_count").default(0),
  questionsAsked: integer("questions_asked").default(0),
  challengesAttempted: integer("challenges_attempted").default(0),
  challengesCompleted: integer("challenges_completed").default(0),
  averageAttempts: integer("average_attempts"), // Average attempts per challenge
  skillGains: text("skill_gains").array().default([]),
  comprehensionScore: integer("comprehension_score"), // AI-calculated 1-100
  engagementScore: integer("engagement_score"), // Based on interaction patterns
  learningVelocity: integer("learning_velocity"), // Progress speed metric
  createdAt: timestamp("created_at").defaultNow(),
});

// AI-Powered Mentorship & Skill Matching
export const mentorshipPrograms = pgTable("mentorship_programs", {
  id: serial("id").primaryKey(),
  menteeId: varchar("mentee_id").notNull().references(() => users.id),
  mentorId: varchar("mentor_id").notNull().references(() => users.id),
  skillFocus: text("skill_focus").array().notNull(), // Primary skills being mentored
  experienceLevel: varchar("experience_level").notNull(), // Mentee's current level
  goalTimeline: varchar("goal_timeline"), // Expected learning timeline
  matchScore: integer("match_score"), // AI-calculated compatibility 1-100
  compatibilityFactors: jsonb("compatibility_factors"), // Detailed matching criteria
  status: varchar("status").default("matched"), // matched, active, completed, paused
  sessionCount: integer("session_count").default(0),
  totalHours: integer("total_hours").default(0),
  progressRating: integer("progress_rating"), // Mentor's assessment of mentee progress
  menteeRating: integer("mentee_rating"), // Mentee's rating of mentor
  lastInteraction: timestamp("last_interaction"),
  nextSession: timestamp("next_session"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Industry-Standard Code Quality Benchmarks
export const qualityBenchmarks = pgTable("quality_benchmarks", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").notNull().references(() => videos.id, { onDelete: "cascade" }),
  language: varchar("language").notNull(),
  framework: varchar("framework"),
  testCoverage: integer("test_coverage"), // Percentage of code covered by tests
  codeSmellCount: integer("code_smell_count").default(0),
  duplicateLines: integer("duplicate_lines").default(0),
  cyclomaticComplexity: integer("cyclomatic_complexity"),
  maintainabilityIndex: integer("maintainability_index"), // Microsoft's maintainability index
  technicalDebt: integer("technical_debt"), // Estimated minutes to fix issues
  securityScore: integer("security_score"), // 1-100 security assessment
  performanceScore: integer("performance_score"), // 1-100 performance rating
  industryPercentile: integer("industry_percentile"), // How it ranks vs industry
  companyStandards: jsonb("company_standards"), // Meets standards of which companies
  certificationLevel: varchar("certification_level"), // junior, mid, senior, architect
  createdAt: timestamp("created_at").defaultNow(),
});

// Live Stream Integration for Real-time Learning
export const liveStreams = pgTable("live_streams", {
  id: serial("id").primaryKey(),
  streamerId: varchar("streamer_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  category: varchar("category").notNull(),
  difficulty: varchar("difficulty").notNull(),
  tags: text("tags").array().default([]),
  streamUrl: text("stream_url"),
  chatEnabled: boolean("chat_enabled").default(true),
  codeShareEnabled: boolean("code_share_enabled").default(true),
  maxViewers: integer("max_viewers").default(1000),
  currentViewers: integer("current_viewers").default(0),
  totalViews: integer("total_views").default(0),
  scheduledAt: timestamp("scheduled_at"),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  isRecorded: boolean("is_recorded").default(true),
  recordingUrl: text("recording_url"),
  status: varchar("status").default("scheduled"), // scheduled, live, ended, cancelled
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  videos: many(videos),
  comments: many(comments),
  videoLikes: many(videoLikes),
  watchHistory: many(watchHistory),
  learningPaths: many(learningPaths),
  userProgress: many(userProgress),
  studyGroups: many(studyGroups),
  codeReviews: many(codeReviews),
}));

export const videosRelations = relations(videos, ({ one, many }) => ({
  creator: one(users, {
    fields: [videos.creatorId],
    references: [users.id],
  }),
  comments: many(comments),
  videoLikes: many(videoLikes),
  watchHistory: many(watchHistory),
  learningPathVideos: many(learningPathVideos),
  codeChallenges: many(codeChallenges),
  codeReviews: many(codeReviews),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  video: one(videos, {
    fields: [comments.videoId],
    references: [videos.id],
  }),
  user: one(users, {
    fields: [comments.userId],
    references: [users.id],
  }),
}));

export const videoLikesRelations = relations(videoLikes, ({ one }) => ({
  video: one(videos, {
    fields: [videoLikes.videoId],
    references: [videos.id],
  }),
  user: one(users, {
    fields: [videoLikes.userId],
    references: [users.id],
  }),
}));

export const watchHistoryRelations = relations(watchHistory, ({ one }) => ({
  video: one(videos, {
    fields: [watchHistory.videoId],
    references: [videos.id],
  }),
  user: one(users, {
    fields: [watchHistory.userId],
    references: [users.id],
  }),
}));

export const learningPathsRelations = relations(learningPaths, ({ one, many }) => ({
  creator: one(users, {
    fields: [learningPaths.creatorId],
    references: [users.id],
  }),
  videos: many(learningPathVideos),
  studyGroups: many(studyGroups),
  userProgress: many(userProgress),
}));

export const learningPathVideosRelations = relations(learningPathVideos, ({ one }) => ({
  path: one(learningPaths, {
    fields: [learningPathVideos.pathId],
    references: [learningPaths.id],
  }),
  video: one(videos, {
    fields: [learningPathVideos.videoId],
    references: [videos.id],
  }),
}));

export const codeChallengesRelations = relations(codeChallenges, ({ one, many }) => ({
  video: one(videos, {
    fields: [codeChallenges.videoId],
    references: [videos.id],
  }),
  userProgress: many(userProgress),
}));

export const userProgressRelations = relations(userProgress, ({ one }) => ({
  user: one(users, {
    fields: [userProgress.userId],
    references: [users.id],
  }),
  video: one(videos, {
    fields: [userProgress.videoId],
    references: [videos.id],
  }),
  path: one(learningPaths, {
    fields: [userProgress.pathId],
    references: [learningPaths.id],
  }),
  challenge: one(codeChallenges, {
    fields: [userProgress.challengeId],
    references: [codeChallenges.id],
  }),
}));

export const studyGroupsRelations = relations(studyGroups, ({ one }) => ({
  creator: one(users, {
    fields: [studyGroups.creatorId],
    references: [users.id],
  }),
  path: one(learningPaths, {
    fields: [studyGroups.pathId],
    references: [learningPaths.id],
  }),
}));

export const codeReviewsRelations = relations(codeReviews, ({ one }) => ({
  video: one(videos, {
    fields: [codeReviews.videoId],
    references: [videos.id],
  }),
  submitter: one(users, {
    fields: [codeReviews.submitterId],
    references: [users.id],
  }),
  reviewer: one(users, {
    fields: [codeReviews.reviewerId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertVideoSchema = createInsertSchema(videos).omit({
  id: true,
  views: true,
  likes: true,
  dislikes: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  isModerated: true,
  isFlagged: true,
  createdAt: true,
});

export const insertVideoLikeSchema = createInsertSchema(videoLikes).omit({
  id: true,
  createdAt: true,
});

export const insertWatchHistorySchema = createInsertSchema(watchHistory).omit({
  id: true,
  watchedAt: true,
});

export const insertLearningPathSchema = createInsertSchema(learningPaths).omit({
  id: true,
  enrollmentCount: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCodeChallengeSchema = createInsertSchema(codeChallenges).omit({
  id: true,
  createdAt: true,
});

export const insertUserProgressSchema = createInsertSchema(userProgress).omit({
  id: true,
  createdAt: true,
});

export const insertStudyGroupSchema = createInsertSchema(studyGroups).omit({
  id: true,
  currentMembers: true,
  createdAt: true,
});

export const insertCodeReviewSchema = createInsertSchema(codeReviews).omit({
  id: true,
  createdAt: true,
  reviewedAt: true,
});

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type Video = typeof videos.$inferSelect;
export type VideoWithCreator = Video & { creator: User };
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;
export type CommentWithUser = Comment & { user: User | null };
export type InsertVideoLike = z.infer<typeof insertVideoLikeSchema>;
export type VideoLike = typeof videoLikes.$inferSelect;
export type InsertWatchHistory = z.infer<typeof insertWatchHistorySchema>;
export type WatchHistory = typeof watchHistory.$inferSelect;

export type InsertLearningPath = z.infer<typeof insertLearningPathSchema>;
export type LearningPath = typeof learningPaths.$inferSelect;
export type LearningPathWithCreator = LearningPath & { creator: User };

export type InsertCodeChallenge = z.infer<typeof insertCodeChallengeSchema>;
export type CodeChallenge = typeof codeChallenges.$inferSelect;

export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;
export type UserProgress = typeof userProgress.$inferSelect;

export type InsertStudyGroup = z.infer<typeof insertStudyGroupSchema>;
export type StudyGroup = typeof studyGroups.$inferSelect;
export type StudyGroupWithCreator = StudyGroup & { creator: User };

export type InsertCodeReview = z.infer<typeof insertCodeReviewSchema>;
export type CodeReview = typeof codeReviews.$inferSelect;
export type CodeReviewWithUsers = CodeReview & { 
  submitter: User; 
  reviewer: User | null; 
  video: Video; 
};
