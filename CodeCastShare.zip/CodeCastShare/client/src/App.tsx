import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import VideoPlayer from "@/pages/VideoPlayer";
import LearningPaths from "@/pages/LearningPaths";
import Trending from "@/pages/Trending";
import Categories from "@/pages/Categories";
import CreatorDashboard from "@/pages/CreatorDashboard";
import AdminPanel from "@/pages/AdminPanel";
import InnovationShowcase from "@/pages/InnovationShowcase";
import SocialHub from "@/pages/SocialHub";
import LiveCodingPage from "@/pages/LiveCodingPage";
import { AIAssistant } from "@/components/AIAssistant";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/video/:id" component={VideoPlayer} />
      <Route path="/learning-paths" component={LearningPaths} />
      <Route path="/trending" component={Trending} />
      <Route path="/categories" component={Categories} />
      <Route path="/creator-dashboard" component={CreatorDashboard} />
      <Route path="/admin" component={AdminPanel} />
      <Route path="/innovation" component={InnovationShowcase} />
      <Route path="/social" component={SocialHub} />
      <Route path="/live-coding" component={LiveCodingPage} />
      <Route path="/landing" component={Landing} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
        <AIAssistant />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
