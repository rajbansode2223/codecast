import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Filter } from "lucide-react";

interface FilterBarProps {
  filters: {
    category: string;
    difficulty: string;
    sortBy: string;
  };
  onFiltersChange: (filters: { category: string; difficulty: string; sortBy: string; }) => void;
  totalVideos: number;
}

export function FilterBar({ filters, onFiltersChange, totalVideos }: FilterBarProps) {
  const categories = [
    "All Categories",
    "Frontend",
    "Backend", 
    "System Design",
    "DevOps",
    "Mobile"
  ];

  const difficulties = [
    "All Levels",
    "Beginner",
    "Intermediate", 
    "Advanced"
  ];

  const sortOptions = [
    "Latest",
    "Most Viewed",
    "Most Liked",
    "Duration"
  ];

  const handleCategoryChange = (value: string) => {
    onFiltersChange({
      ...filters,
      category: value === "All Categories" ? "" : value
    });
  };

  const handleDifficultyChange = (value: string) => {
    onFiltersChange({
      ...filters,
      difficulty: value === "All Levels" ? "" : value
    });
  };

  const handleSortChange = (value: string) => {
    onFiltersChange({
      ...filters,
      sortBy: value
    });
  };

  return (
    <section className="bg-muted/50 border-b border-border py-4">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex flex-wrap gap-3 items-center">
            <div className="flex items-center text-muted-foreground mr-2">
              <Filter className="w-4 h-4 mr-2" />
              <span className="text-sm font-medium">Filters:</span>
            </div>
            
            <Select 
              value={filters.category || "All Categories"} 
              onValueChange={handleCategoryChange}
            >
              <SelectTrigger className="w-40 bg-background">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select 
              value={filters.difficulty || "All Levels"} 
              onValueChange={handleDifficultyChange}
            >
              <SelectTrigger className="w-36 bg-background">
                <SelectValue placeholder="Difficulty" />
              </SelectTrigger>
              <SelectContent>
                {difficulties.map((difficulty) => (
                  <SelectItem key={difficulty} value={difficulty}>
                    {difficulty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select 
              value={filters.sortBy} 
              onValueChange={handleSortChange}
            >
              <SelectTrigger className="w-36 bg-background">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                {sortOptions.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center text-muted-foreground">
            <span className="text-sm">
              <span className="font-medium text-foreground">{totalVideos.toLocaleString()}</span> videos found
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
