import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LearningPath } from "@/components/LearningPath";
import { 
  BookOpen, 
  Search, 
  Filter,
  TrendingUp,
  Users,
  Clock,
  Star,
  Plus
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface LearningPathData {
  id: number;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  estimatedHours: number;
  enrollmentCount: number;
  tags: string[];
  creator: {
    id: string;
    firstName: string;
    lastName: string;
    profileImageUrl?: string;
  };
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
}

interface PathVideo {
  video: {
    id: number;
    title: string;
    duration: number;
    creator: {
      id: string;
      firstName: string;
      lastName: string;
      profileImageUrl?: string;
    };
  };
  order: number;
  isOptional: boolean;
  notes?: string;
}

export default function LearningPaths() {
  const [activeTab, setActiveTab] = useState("browse");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState("all");
  const [selectedPath, setSelectedPath] = useState<LearningPathData | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch all learning paths
  const { data: pathsData, isLoading: pathsLoading } = useQuery({
    queryKey: ['/api/learning-paths', searchTerm, selectedCategory, selectedDifficulty],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchTerm) params.append('search', searchTerm);
      if (selectedCategory && selectedCategory !== 'all') params.append('category', selectedCategory);
      if (selectedDifficulty && selectedDifficulty !== 'all') params.append('difficulty', selectedDifficulty);
      
      const response = await fetch(`/api/learning-paths?${params.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch learning paths');
      return response.json();
    },
    enabled: activeTab === "browse",
  });

  // Fetch user's enrolled paths
  const { data: enrolledPaths, isLoading: enrolledLoading } = useQuery({
    queryKey: ['/api/user/enrolled-paths'],
    queryFn: async () => {
      const response = await fetch('/api/user/enrolled-paths');
      if (!response.ok) throw new Error('Failed to fetch enrolled paths');
      return response.json();
    },
    enabled: activeTab === "my-learning",
  });

  // Fetch path videos when a path is selected
  const { data: pathVideos } = useQuery({
    queryKey: ['/api/learning-paths', selectedPath?.id, 'videos'],
    queryFn: async () => {
      if (!selectedPath) return [];
      const response = await fetch(`/api/learning-paths/${selectedPath.id}/videos`);
      if (!response.ok) throw new Error('Failed to fetch path videos');
      return response.json();
    },
    enabled: !!selectedPath,
  });

  // Fetch user progress for selected path
  const { data: userProgress } = useQuery({
    queryKey: ['/api/learning-paths', selectedPath?.id, 'progress'],
    queryFn: async () => {
      if (!selectedPath) return null;
      const response = await fetch(`/api/learning-paths/${selectedPath.id}/progress`);
      if (!response.ok) throw new Error('Failed to fetch progress');
      return response.json();
    },
    enabled: !!selectedPath,
  });

  // Enrollment mutation
  const enrollMutation = useMutation({
    mutationFn: async (pathId: number) => {
      const response = await fetch(`/api/learning-paths/${pathId}/enroll`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error('Failed to enroll');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/enrolled-paths'] });
      toast({
        title: "Enrolled successfully!",
        description: "You're now enrolled in this learning path.",
      });
    },
    onError: () => {
      toast({
        title: "Enrollment failed",
        description: "Please try again later.",
        variant: "destructive",
      });
    },
  });

  // Mark video as completed
  const completeMutation = useMutation({
    mutationFn: async ({ videoId, pathId }: { videoId: number; pathId?: number }) => {
      const response = await fetch(`/api/videos/${videoId}/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pathId }),
      });
      if (!response.ok) throw new Error('Failed to mark complete');
      return response.json();
    },
    onSuccess: () => {
      if (selectedPath) {
        queryClient.invalidateQueries({ 
          queryKey: ['/api/learning-paths', selectedPath.id, 'progress'] 
        });
      }
      toast({
        title: "Progress updated",
        description: "Video marked as completed.",
      });
    },
  });

  const handlePathSelect = (path: LearningPathData) => {
    setSelectedPath(path);
  };

  const handleEnroll = (pathId: number) => {
    enrollMutation.mutate(pathId);
  };

  const handleVideoClick = (videoId: number) => {
    if (selectedPath) {
      completeMutation.mutate({ videoId, pathId: selectedPath.id });
    }
  };

  const formatVideosForComponent = (videos: PathVideo[]) => {
    return videos?.map(({ video, order, isOptional, notes }) => ({
      id: video.id,
      title: video.title,
      duration: video.duration,
      order,
      isOptional,
      notes,
      isCompleted: false, // This would be determined by user progress
    })) || [];
  };

  const allPaths = pathsData?.paths || [];
  const categories = ["Web Development", "Mobile Development", "Data Science", "DevOps", "AI/ML"];
  const difficulties = ["Beginner", "Intermediate", "Advanced"];

  const filteredPaths = allPaths.filter((path: LearningPathData) => {
    const matchesSearch = !searchTerm || 
      path.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      path.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === "all" || path.category === selectedCategory;
    const matchesDifficulty = selectedDifficulty === "all" || path.difficulty === selectedDifficulty;
    
    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  const featuredPaths = allPaths.slice(0, 3);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-gray-900 flex items-center justify-center gap-3">
            <BookOpen className="h-10 w-10 text-blue-500" />
            Learning Paths
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Structured learning journeys designed by industry experts. Follow curated video sequences 
            to master specific technologies and concepts step by step.
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <BookOpen className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <div className="text-2xl font-bold">{pathsData?.total || 0}</div>
              <div className="text-sm text-gray-600">Learning Paths</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <Users className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <div className="text-2xl font-bold">{Array.isArray(enrolledPaths) ? enrolledPaths.length : 0}</div>
              <div className="text-sm text-gray-600">Enrolled</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <Clock className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <div className="text-2xl font-bold">
                {Array.isArray(enrolledPaths) ? enrolledPaths.reduce((total: number, path: LearningPathData) => total + path.estimatedHours, 0) : 0}h
              </div>
              <div className="text-sm text-gray-600">Study Time</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <Star className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
              <div className="text-2xl font-bold">4.8</div>
              <div className="text-sm text-gray-600">Avg Rating</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="browse" className="flex items-center gap-2">
              <Search className="h-4 w-4" />
              Browse All Paths
            </TabsTrigger>
            <TabsTrigger value="my-learning" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              My Learning
            </TabsTrigger>
            <TabsTrigger value="featured" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Featured Paths
            </TabsTrigger>
          </TabsList>

          {/* Browse All Paths */}
          <TabsContent value="browse" className="space-y-6">
            {/* Search and Filters */}
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search learning paths..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Difficulty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  {difficulties.map((difficulty) => (
                    <SelectItem key={difficulty} value={difficulty}>
                      {difficulty}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button variant="outline" className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                More Filters
              </Button>
            </div>

            {/* Learning Paths Grid */}
            {pathsLoading ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {[...Array(4)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-4 bg-gray-200 rounded w-full"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="h-20 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredPaths.map((path: LearningPathData) => (
                  <LearningPath
                    key={path.id}
                    path={path}
                    videos={selectedPath?.id === path.id ? formatVideosForComponent(pathVideos || []) : []}
                    userProgress={selectedPath?.id === path.id ? userProgress : undefined}
                    onEnroll={() => handleEnroll(path.id)}
                    onVideoClick={handleVideoClick}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          {/* My Learning */}
          <TabsContent value="my-learning" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">My Enrolled Paths</h2>
              <Button className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Browse More Paths
              </Button>
            </div>

            {enrolledLoading ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {[...Array(2)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-4 bg-gray-200 rounded w-full"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="h-20 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : !Array.isArray(enrolledPaths) || enrolledPaths.length === 0 ? (
              <Card className="text-center py-12">
                <CardContent>
                  <BookOpen className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No Enrolled Paths</h3>
                  <p className="text-gray-600 mb-4">
                    Start your learning journey by enrolling in a learning path.
                  </p>
                  <Button onClick={() => setActiveTab("browse")}>
                    Browse Learning Paths
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {Array.isArray(enrolledPaths) && enrolledPaths.map((path: LearningPathData) => (
                  <LearningPath
                    key={path.id}
                    path={path}
                    videos={selectedPath?.id === path.id ? formatVideosForComponent(pathVideos || []) : []}
                    userProgress={selectedPath?.id === path.id ? userProgress : undefined}
                    onVideoClick={handleVideoClick}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          {/* Featured Paths */}
          <TabsContent value="featured" className="space-y-6">
            <div className="text-center space-y-4">
              <h2 className="text-3xl font-bold">Featured Learning Paths</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Hand-picked learning paths recommended by our community and experts. 
                Perfect for advancing your career and staying current with industry trends.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {featuredPaths.map((path: LearningPathData) => (
                <LearningPath
                  key={path.id}
                  path={path}
                  videos={selectedPath?.id === path.id ? formatVideosForComponent(pathVideos) : []}
                  userProgress={selectedPath?.id === path.id ? userProgress : undefined}
                  onEnroll={() => handleEnroll(path.id)}
                  onVideoClick={handleVideoClick}
                />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}