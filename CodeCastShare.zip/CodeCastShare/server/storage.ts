import {
  users,
  videos,
  comments,
  videoLikes,
  watchHistory,
  learningPaths,
  learningPathVideos,
  userProgress,
  type User,
  type UpsertUser,
  type InsertVideo,
  type Video,
  type VideoWithCreator,
  type InsertComment,
  type Comment,
  type CommentWithUser,
  type InsertVideoLike,
  type VideoLike,
  type InsertWatchHistory,
  type InsertLearningPath,
  type LearningPath,
  type LearningPathWithCreator,
  type InsertUserProgress,
  type UserProgress,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, and, or, ilike, sql, count } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Video operations
  createVideo(video: InsertVideo): Promise<Video>;
  getVideo(id: number): Promise<VideoWithCreator | undefined>;
  getVideos(filters?: {
    category?: string;
    difficulty?: string;
    tags?: string[];
    search?: string;
    sortBy?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ videos: VideoWithCreator[]; total: number }>;
  getUserVideos(userId: string): Promise<VideoWithCreator[]>;
  updateVideo(id: number, updates: Partial<InsertVideo>): Promise<Video | undefined>;
  deleteVideo(id: number, userId: string): Promise<boolean>;
  incrementViews(videoId: number): Promise<void>;
  
  // Comment operations
  createComment(comment: InsertComment): Promise<Comment>;
  getVideoComments(videoId: number): Promise<CommentWithUser[]>;
  deleteComment(id: number, userId?: string): Promise<boolean>;
  flagComment(id: number): Promise<boolean>;
  moderateComment(id: number, isApproved: boolean): Promise<boolean>;
  getFlaggedComments(): Promise<CommentWithUser[]>;
  
  // Like/Dislike operations
  toggleVideoLike(videoId: number, userId: string, isLike: boolean): Promise<VideoLike>;
  getUserVideoLike(videoId: number, userId: string): Promise<VideoLike | undefined>;
  
  // Watch history
  addWatchHistory(history: InsertWatchHistory): Promise<void>;
  getUserWatchHistory(userId: string, limit?: number): Promise<VideoWithCreator[]>;
  
  // Analytics
  getCreatorAnalytics(userId: string): Promise<{
    totalViews: number;
    totalLikes: number;
    totalVideos: number;
    avgWatchTime: number;
  }>;
  
  getAdminAnalytics(): Promise<{
    totalUsers: number;
    totalVideos: number;
    flaggedComments: number;
    activeToday: number;
    topTags: string[];
  }>;
  
  // Learning Paths operations
  createLearningPath(path: InsertLearningPath): Promise<LearningPath>;
  getLearningPaths(filters?: {
    category?: string;
    difficulty?: string;
    search?: string;
    creatorId?: string;
    isPublished?: boolean;
    limit?: number;
    offset?: number;
  }): Promise<{ paths: LearningPathWithCreator[]; total: number }>;
  getLearningPath(id: number): Promise<LearningPathWithCreator | undefined>;
  updateLearningPath(id: number, updates: Partial<InsertLearningPath>): Promise<LearningPath | undefined>;
  deleteLearningPath(id: number, creatorId: string): Promise<boolean>;
  addVideoToPath(pathId: number, videoId: number, order: number, isOptional?: boolean, notes?: string): Promise<void>;
  removeVideoFromPath(pathId: number, videoId: number): Promise<boolean>;
  getPathVideos(pathId: number): Promise<Array<{ video: VideoWithCreator; order: number; isOptional: boolean; notes?: string }>>;
  enrollInPath(userId: string, pathId: number): Promise<UserProgress>;
  getUserPathProgress(userId: string, pathId: number): Promise<{ completedVideos: number; totalVideos: number; enrolledAt?: string } | undefined>;
  getUserEnrolledPaths(userId: string): Promise<LearningPathWithCreator[]>;
  markVideoCompleted(userId: string, videoId: number, pathId?: number): Promise<void>;
  
  // Admin operations
  getAllUsers(): Promise<User[]>;
  updateUserRole(userId: string, role: string): Promise<User | undefined>;
  suspendUser(userId: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Video operations
  async createVideo(video: InsertVideo): Promise<Video> {
    const [newVideo] = await db.insert(videos).values(video).returning();
    return newVideo;
  }

  async getVideo(id: number): Promise<VideoWithCreator | undefined> {
    const [video] = await db
      .select()
      .from(videos)
      .leftJoin(users, eq(videos.creatorId, users.id))
      .where(eq(videos.id, id));
    
    if (!video.videos) return undefined;
    
    return {
      ...video.videos,
      creator: video.users!,
    };
  }

  async getVideos(filters: {
    category?: string;
    difficulty?: string;
    tags?: string[];
    search?: string;
    sortBy?: string;
    limit?: number;
    offset?: number;
  } = {}): Promise<{ videos: VideoWithCreator[]; total: number }> {
    const {
      category,
      difficulty,
      tags,
      search,
      sortBy = "latest",
      limit = 20,
      offset = 0,
    } = filters;

    let query = db
      .select()
      .from(videos)
      .leftJoin(users, eq(videos.creatorId, users.id))
      .where(eq(videos.isPublished, true));

    const conditions = [];

    if (category && category !== "All Categories") {
      conditions.push(eq(videos.category, category));
    }

    if (difficulty && difficulty !== "All Levels") {
      conditions.push(eq(videos.difficulty, difficulty));
    }

    if (search) {
      conditions.push(
        or(
          ilike(videos.title, `%${search}%`),
          ilike(videos.description, `%${search}%`)
        )
      );
    }

    if (tags && tags.length > 0) {
      conditions.push(
        sql`${videos.tags} && ${tags}`
      );
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    // Apply sorting
    switch (sortBy) {
      case "Most Viewed":
        query = query.orderBy(desc(videos.views));
        break;
      case "Most Liked":
        query = query.orderBy(desc(videos.likes));
        break;
      case "Duration":
        query = query.orderBy(asc(videos.duration));
        break;
      default: // Latest
        query = query.orderBy(desc(videos.createdAt));
    }

    const results = await query.limit(limit).offset(offset);
    
    // Get total count
    const [totalResult] = await db
      .select({ count: count() })
      .from(videos)
      .where(
        conditions.length > 0
          ? and(eq(videos.isPublished, true), ...conditions)
          : eq(videos.isPublished, true)
      );

    const mappedVideos: VideoWithCreator[] = results.map((result) => ({
      ...result.videos!,
      creator: result.users!,
    }));

    return {
      videos: mappedVideos,
      total: totalResult.count,
    };
  }

  async getUserVideos(userId: string): Promise<VideoWithCreator[]> {
    const results = await db
      .select()
      .from(videos)
      .leftJoin(users, eq(videos.creatorId, users.id))
      .where(eq(videos.creatorId, userId))
      .orderBy(desc(videos.createdAt));

    return results.map((result) => ({
      ...result.videos!,
      creator: result.users!,
    }));
  }

  async updateVideo(id: number, updates: Partial<InsertVideo>): Promise<Video | undefined> {
    const [updated] = await db
      .update(videos)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(videos.id, id))
      .returning();
    return updated;
  }

  async deleteVideo(id: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(videos)
      .where(and(eq(videos.id, id), eq(videos.creatorId, userId)));
    return result.rowCount > 0;
  }

  async incrementViews(videoId: number): Promise<void> {
    await db
      .update(videos)
      .set({ views: sql`${videos.views} + 1` })
      .where(eq(videos.id, videoId));
  }

  // Comment operations
  async createComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db.insert(comments).values(comment).returning();
    return newComment;
  }

  async getVideoComments(videoId: number): Promise<CommentWithUser[]> {
    const results = await db
      .select()
      .from(comments)
      .leftJoin(users, eq(comments.userId, users.id))
      .where(and(eq(comments.videoId, videoId), eq(comments.isModerated, false)))
      .orderBy(desc(comments.createdAt));

    return results.map((result) => ({
      ...result.comments,
      user: result.users,
    }));
  }

  async deleteComment(id: number, userId?: string): Promise<boolean> {
    const conditions = [eq(comments.id, id)];
    if (userId) {
      conditions.push(eq(comments.userId, userId));
    }

    const result = await db.delete(comments).where(and(...conditions));
    return result.rowCount > 0;
  }

  async flagComment(id: number): Promise<boolean> {
    const result = await db
      .update(comments)
      .set({ isFlagged: true })
      .where(eq(comments.id, id));
    return result.rowCount > 0;
  }

  async moderateComment(id: number, isApproved: boolean): Promise<boolean> {
    const result = await db
      .update(comments)
      .set({ isModerated: !isApproved, isFlagged: false })
      .where(eq(comments.id, id));
    return result.rowCount > 0;
  }

  async getFlaggedComments(): Promise<CommentWithUser[]> {
    const results = await db
      .select()
      .from(comments)
      .leftJoin(users, eq(comments.userId, users.id))
      .where(eq(comments.isFlagged, true))
      .orderBy(desc(comments.createdAt));

    return results.map((result) => ({
      ...result.comments,
      user: result.users,
    }));
  }

  // Like/Dislike operations
  async toggleVideoLike(videoId: number, userId: string, isLike: boolean): Promise<VideoLike> {
    // Check if user already liked/disliked this video
    const existing = await this.getUserVideoLike(videoId, userId);

    if (existing) {
      // Update existing like/dislike
      const [updated] = await db
        .update(videoLikes)
        .set({ isLike })
        .where(and(eq(videoLikes.videoId, videoId), eq(videoLikes.userId, userId)))
        .returning();

      // Update video counts
      await this.updateVideoLikeCounts(videoId);
      return updated;
    } else {
      // Create new like/dislike
      const [newLike] = await db
        .insert(videoLikes)
        .values({ videoId, userId, isLike })
        .returning();

      // Update video counts
      await this.updateVideoLikeCounts(videoId);
      return newLike;
    }
  }

  private async updateVideoLikeCounts(videoId: number): Promise<void> {
    const [likesCount] = await db
      .select({ count: count() })
      .from(videoLikes)
      .where(and(eq(videoLikes.videoId, videoId), eq(videoLikes.isLike, true)));

    const [dislikesCount] = await db
      .select({ count: count() })
      .from(videoLikes)
      .where(and(eq(videoLikes.videoId, videoId), eq(videoLikes.isLike, false)));

    await db
      .update(videos)
      .set({
        likes: likesCount.count,
        dislikes: dislikesCount.count,
      })
      .where(eq(videos.id, videoId));
  }

  async getUserVideoLike(videoId: number, userId: string): Promise<VideoLike | undefined> {
    const [like] = await db
      .select()
      .from(videoLikes)
      .where(and(eq(videoLikes.videoId, videoId), eq(videoLikes.userId, userId)));
    return like;
  }

  // Watch history
  async addWatchHistory(history: InsertWatchHistory): Promise<void> {
    await db.insert(watchHistory).values(history);
  }

  async getUserWatchHistory(userId: string, limit = 10): Promise<VideoWithCreator[]> {
    const results = await db
      .select()
      .from(watchHistory)
      .innerJoin(videos, eq(watchHistory.videoId, videos.id))
      .leftJoin(users, eq(videos.creatorId, users.id))
      .where(eq(watchHistory.userId, userId))
      .orderBy(desc(watchHistory.watchedAt))
      .limit(limit);

    return results.map((result) => ({
      ...result.videos,
      creator: result.users!,
    }));
  }

  // Analytics
  async getCreatorAnalytics(userId: string): Promise<{
    totalViews: number;
    totalLikes: number;
    totalVideos: number;
    avgWatchTime: number;
  }> {
    const [stats] = await db
      .select({
        totalViews: sql<number>`COALESCE(SUM(${videos.views}), 0)`,
        totalLikes: sql<number>`COALESCE(SUM(${videos.likes}), 0)`,
        totalVideos: count(videos.id),
      })
      .from(videos)
      .where(eq(videos.creatorId, userId));

    // Mock average watch time for now
    return {
      ...stats,
      avgWatchTime: 525, // 8:45 in seconds
    };
  }

  async getAdminAnalytics(): Promise<{
    totalUsers: number;
    totalVideos: number;
    flaggedComments: number;
    activeToday: number;
    topTags: string[];
  }> {
    const [userCount] = await db.select({ count: count() }).from(users);
    const [videoCount] = await db.select({ count: count() }).from(videos);
    const [flaggedCount] = await db
      .select({ count: count() })
      .from(comments)
      .where(eq(comments.isFlagged, true));

    // Mock active today count
    const activeToday = Math.floor(userCount.count * 0.7);

    // Get top tags
    const tagResults = await db
      .select({ tags: videos.tags })
      .from(videos)
      .where(sql`array_length(${videos.tags}, 1) > 0`);

    const tagCounts: Record<string, number> = {};
    tagResults.forEach((result) => {
      result.tags?.forEach((tag) => {
        tagCounts[tag] = (tagCounts[tag] || 0) + 1;
      });
    });

    const topTags = Object.entries(tagCounts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5)
      .map(([tag]) => tag);

    return {
      totalUsers: userCount.count,
      totalVideos: videoCount.count,
      flaggedComments: flaggedCount.count,
      activeToday,
      topTags,
    };
  }

  // Admin operations
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async updateUserRole(userId: string, role: string): Promise<User | undefined> {
    const [updated] = await db
      .update(users)
      .set({ role, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return updated;
  }

  async suspendUser(userId: string): Promise<boolean> {
    // For now, we'll just update their role to indicate suspension
    const result = await db
      .update(users)
      .set({ role: "suspended", updatedAt: new Date() })
      .where(eq(users.id, userId));
    return (result.rowCount ?? 0) > 0;
  }

  // Learning Paths operations
  async createLearningPath(path: InsertLearningPath): Promise<LearningPath> {
    const [newPath] = await db.insert(learningPaths).values(path).returning();
    return newPath;
  }

  async getLearningPaths(filters: {
    category?: string;
    difficulty?: string;
    search?: string;
    creatorId?: string;
    isPublished?: boolean;
    limit?: number;
    offset?: number;
  } = {}): Promise<{ paths: LearningPathWithCreator[]; total: number }> {
    const { category, difficulty, search, creatorId, isPublished = true, limit = 20, offset = 0 } = filters;

    let query = db
      .select({
        path: learningPaths,
        creator: users,
      })
      .from(learningPaths)
      .innerJoin(users, eq(learningPaths.creatorId, users.id))
      .$dynamic();

    const conditions = [];
    if (category) conditions.push(eq(learningPaths.category, category));
    if (difficulty) conditions.push(eq(learningPaths.difficulty, difficulty));
    if (search) conditions.push(ilike(learningPaths.title, `%${search}%`));
    if (creatorId) conditions.push(eq(learningPaths.creatorId, creatorId));
    if (isPublished !== undefined) conditions.push(eq(learningPaths.isPublished, isPublished));

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    const pathsWithCreators = await query
      .orderBy(desc(learningPaths.createdAt))
      .limit(limit)
      .offset(offset);

    const [{ count: total }] = await db
      .select({ count: count() })
      .from(learningPaths)
      .where(conditions.length > 0 ? and(...conditions) : undefined);

    const results: LearningPathWithCreator[] = pathsWithCreators.map(({ path, creator }) => ({
      ...path,
      creator,
    }));

    return { paths: results, total: Number(total) };
  }

  async getLearningPath(id: number): Promise<LearningPathWithCreator | undefined> {
    const [result] = await db
      .select({
        path: learningPaths,
        creator: users,
      })
      .from(learningPaths)
      .innerJoin(users, eq(learningPaths.creatorId, users.id))
      .where(eq(learningPaths.id, id));

    if (!result) return undefined;

    return {
      ...result.path,
      creator: result.creator,
    };
  }

  async updateLearningPath(id: number, updates: Partial<InsertLearningPath>): Promise<LearningPath | undefined> {
    const [updated] = await db
      .update(learningPaths)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(learningPaths.id, id))
      .returning();
    return updated;
  }

  async deleteLearningPath(id: number, creatorId: string): Promise<boolean> {
    const result = await db
      .delete(learningPaths)
      .where(and(eq(learningPaths.id, id), eq(learningPaths.creatorId, creatorId)));
    return (result.rowCount ?? 0) > 0;
  }

  async addVideoToPath(pathId: number, videoId: number, order: number, isOptional = false, notes?: string): Promise<void> {
    await db.insert(learningPathVideos).values({
      pathId,
      videoId,
      order,
      isOptional,
      notes,
    });
  }

  async removeVideoFromPath(pathId: number, videoId: number): Promise<boolean> {
    const result = await db
      .delete(learningPathVideos)
      .where(and(eq(learningPathVideos.pathId, pathId), eq(learningPathVideos.videoId, videoId)));
    return (result.rowCount ?? 0) > 0;
  }

  async getPathVideos(pathId: number): Promise<Array<{ video: VideoWithCreator; order: number; isOptional: boolean; notes?: string }>> {
    const results = await db
      .select({
        video: videos,
        creator: users,
        order: learningPathVideos.order,
        isOptional: learningPathVideos.isOptional,
        notes: learningPathVideos.notes,
      })
      .from(learningPathVideos)
      .innerJoin(videos, eq(learningPathVideos.videoId, videos.id))
      .innerJoin(users, eq(videos.creatorId, users.id))
      .where(eq(learningPathVideos.pathId, pathId))
      .orderBy(asc(learningPathVideos.order));

    return results.map(({ video, creator, order, isOptional, notes }) => ({
      video: { ...video, creator },
      order,
      isOptional: isOptional ?? false,
      notes: notes || undefined,
    }));
  }

  async enrollInPath(userId: string, pathId: number): Promise<UserProgress> {
    const [enrollment] = await db
      .insert(userProgress)
      .values({
        userId,
        pathId,
        status: "enrolled",
      })
      .returning();
    return enrollment;
  }

  async getUserPathProgress(userId: string, pathId: number): Promise<{ completedVideos: number; totalVideos: number; enrolledAt?: string } | undefined> {
    // Get enrollment date
    const [enrollment] = await db
      .select({ enrolledAt: userProgress.createdAt })
      .from(userProgress)
      .where(and(eq(userProgress.userId, userId), eq(userProgress.pathId, pathId)))
      .limit(1);

    if (!enrollment) return undefined;

    // Get total videos in path
    const [{ totalVideos }] = await db
      .select({ totalVideos: count() })
      .from(learningPathVideos)
      .where(eq(learningPathVideos.pathId, pathId));

    // Get completed videos
    const [{ completedVideos }] = await db
      .select({ completedVideos: count() })
      .from(userProgress)
      .innerJoin(learningPathVideos, eq(userProgress.videoId, learningPathVideos.videoId))
      .where(
        and(
          eq(userProgress.userId, userId),
          eq(learningPathVideos.pathId, pathId),
          eq(userProgress.status, "completed")
        )
      );

    return {
      completedVideos: Number(completedVideos),
      totalVideos: Number(totalVideos),
      enrolledAt: enrollment.enrolledAt?.toISOString(),
    };
  }

  async getUserEnrolledPaths(userId: string): Promise<LearningPathWithCreator[]> {
    const results = await db
      .select({
        path: learningPaths,
        creator: users,
      })
      .from(userProgress)
      .innerJoin(learningPaths, eq(userProgress.pathId, learningPaths.id))
      .innerJoin(users, eq(learningPaths.creatorId, users.id))
      .where(and(eq(userProgress.userId, userId), eq(userProgress.status, "enrolled")))
      .groupBy(learningPaths.id, users.id);

    return results.map(({ path, creator }) => ({
      ...path,
      creator,
    }));
  }

  async markVideoCompleted(userId: string, videoId: number, pathId?: number): Promise<void> {
    await db
      .insert(userProgress)
      .values({
        userId,
        videoId,
        pathId,
        status: "completed",
        completedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: [userProgress.userId, userProgress.videoId],
        set: {
          status: "completed",
          completedAt: new Date(),
        },
      });
  }
}

export const storage = new DatabaseStorage();
