import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Video, Search, Upload, User, Settings, LogOut, BarChart3, Shield } from "lucide-react";

interface NavigationProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onUploadClick?: () => void;
}

export function Navigation({ searchQuery, onSearchChange, onUploadClick }: NavigationProps) {
  const { user, isAuthenticated } = useAuth();
  const [location] = useLocation();

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const canUpload = user && (user.role === 'creator' || user.role === 'admin');
  const isAdmin = user && user.role === 'admin';

  return (
    <nav className="bg-card border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            <Link href="/" className="flex items-center space-x-2">
              <Video className="text-primary text-2xl" />
              <span className="text-xl font-bold text-foreground">CodeCast</span>
            </Link>
            {isAuthenticated && (
              <div className="hidden md:flex space-x-6">
                <Link href="/" className={`text-muted-foreground hover:text-foreground transition-colors ${location === '/' ? 'text-foreground' : ''}`}>
                  Browse
                </Link>
                <Link href="/learning-paths" className={`text-muted-foreground hover:text-foreground transition-colors ${location === '/learning-paths' ? 'text-foreground' : ''}`}>
                  Learning Paths
                </Link>
                <Link href="/trending" className={`text-muted-foreground hover:text-foreground transition-colors ${location === '/trending' ? 'text-foreground' : ''}`}>
                  Trending
                </Link>
                <Link href="/categories" className={`text-muted-foreground hover:text-foreground transition-colors ${location === '/categories' ? 'text-foreground' : ''}`}>
                  Categories
                </Link>
                <Link href="/innovation" className={`text-muted-foreground hover:text-foreground transition-colors ${location === '/innovation' ? 'text-foreground' : ''}`}>
                  Innovation
                </Link>
              </div>
            )}
          </div>
          
          {/* Search Bar */}
          {isAuthenticated && (
            <div className="flex-1 max-w-lg mx-8 hidden md:block">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search dev videos..."
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  className="w-full bg-muted text-foreground pl-10"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              </div>
            </div>
          )}

          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                {/* Creator Upload Button */}
                {canUpload && onUploadClick && (
                  <Button onClick={onUploadClick} className="hidden md:flex">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload
                  </Button>
                )}
                
                {/* User Menu */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={user?.profileImageUrl || undefined} alt="User avatar" />
                        <AvatarFallback>
                          {user?.firstName?.[0] || user?.email?.[0] || 'U'}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56" align="end" forceMount>
                    <div className="flex items-center justify-start gap-2 p-2">
                      <div className="flex flex-col space-y-1 leading-none">
                        <p className="font-medium">
                          {user?.firstName && user?.lastName 
                            ? `${user.firstName} ${user.lastName}`
                            : user?.email
                          }
                        </p>
                        <p className="text-xs text-muted-foreground capitalize">
                          {user?.role}
                        </p>
                      </div>
                    </div>
                    <DropdownMenuSeparator />
                    
                    {canUpload && (
                      <DropdownMenuItem asChild>
                        <Link href="/creator/dashboard">
                          <BarChart3 className="mr-2 h-4 w-4" />
                          Creator Dashboard
                        </Link>
                      </DropdownMenuItem>
                    )}
                    
                    {isAdmin && (
                      <DropdownMenuItem asChild>
                        <Link href="/admin">
                          <Shield className="mr-2 h-4 w-4" />
                          Admin Panel
                        </Link>
                      </DropdownMenuItem>
                    )}
                    
                    <DropdownMenuItem>
                      <User className="mr-2 h-4 w-4" />
                      Profile
                    </DropdownMenuItem>
                    
                    <DropdownMenuItem>
                      <Settings className="mr-2 h-4 w-4" />
                      Settings
                    </DropdownMenuItem>
                    
                    <DropdownMenuSeparator />
                    
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      Log out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <Button onClick={handleLogin}>
                Sign In
              </Button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
