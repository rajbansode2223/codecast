import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { VideoGrid } from "@/components/VideoGrid";
import { Navigation } from "@/components/Navigation";
import { useState } from "react";
import { TrendingUp, Flame, Clock, Eye } from "lucide-react";

export default function Trending() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: trendingData, isLoading } = useQuery({
    queryKey: ["/api/trending"],
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/analytics/trending-stats"],
    enabled: false, // We'll use mock data for now
  });

  // Mock trending stats for demonstration
  const trendingStats = {
    totalViews: 1250000,
    activeViewers: 8450,
    topCategories: ["Frontend", "Backend", "DevOps"],
    growthRate: 23.5
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation 
        searchQuery={searchQuery} 
        onSearchChange={setSearchQuery}
      />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <TrendingUp className="h-8 w-8 text-red-500" />
            <h1 className="text-3xl font-bold text-gray-900">Trending Now</h1>
          </div>
          <p className="text-gray-600 text-lg">
            Discover the most popular developer content right now
          </p>
        </div>

        {/* Trending Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Eye className="h-5 w-5 text-blue-500" />
                Total Views
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-blue-600">
                {trendingStats.totalViews.toLocaleString()}
              </p>
              <p className="text-sm text-gray-600">Last 24 hours</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Flame className="h-5 w-5 text-red-500" />
                Active Now
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-red-600">
                {trendingStats.activeViewers.toLocaleString()}
              </p>
              <p className="text-sm text-gray-600">Watching now</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-green-500" />
                Growth Rate
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-green-600">
                +{trendingStats.growthRate}%
              </p>
              <p className="text-sm text-gray-600">vs last week</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="h-5 w-5 text-purple-500" />
                Hot Categories
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-1">
                {trendingStats.topCategories.map((category) => (
                  <Badge key={category} variant="secondary" className="text-xs">
                    {category}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Trending Sections */}
        <div className="space-y-12">
          {/* Most Watched Today */}
          <section>
            <div className="flex items-center gap-3 mb-6">
              <Flame className="h-6 w-6 text-red-500" />
              <h2 className="text-2xl font-bold text-gray-900">Most Watched Today</h2>
            </div>
            <VideoGrid 
              videos={trendingData?.videos || []}
              isLoading={isLoading}
              total={trendingData?.total || 0}
            />
          </section>

          {/* Fastest Growing */}
          <section>
            <div className="flex items-center gap-3 mb-6">
              <TrendingUp className="h-6 w-6 text-green-500" />
              <h2 className="text-2xl font-bold text-gray-900">Fastest Growing</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge variant="destructive" className="text-xs">
                        +{(50 + i * 20)}% views
                      </Badge>
                      <span className="text-sm text-gray-500">#{i}</span>
                    </div>
                    <CardTitle className="text-lg">
                      React Hooks Masterclass {i}
                    </CardTitle>
                    <CardDescription>
                      Learn advanced React patterns and state management
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <span>{(1200 + i * 300).toLocaleString()} views</span>
                      <span>{15 + i * 5} min</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Trending by Category */}
          <section>
            <div className="flex items-center gap-3 mb-6">
              <div className="h-6 w-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded"></div>
              <h2 className="text-2xl font-bold text-gray-900">Trending by Category</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {['Frontend', 'Backend', 'Mobile', 'DevOps'].map((category) => (
                <Card key={category} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-xl">{category}</CardTitle>
                    <CardDescription>
                      Top trending videos in {category.toLowerCase()} development
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div>
                            <p className="font-medium text-sm">
                              {category} Tutorial #{i}
                            </p>
                            <p className="text-xs text-gray-600">
                              {(500 + i * 200).toLocaleString()} views
                            </p>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            #{i}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}