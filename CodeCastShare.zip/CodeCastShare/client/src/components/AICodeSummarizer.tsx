import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Brain, 
  FileText, 
  Lightbulb, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp,
  Code,
  BookOpen,
  Target,
  Zap,
  Search,
  Download,
  Share,
  RefreshCw
} from "lucide-react";

interface CodeAnalysis {
  summary: string;
  keyPoints: string[];
  complexity: {
    score: number;
    level: "low" | "medium" | "high";
    factors: string[];
  };
  patterns: {
    name: string;
    description: string;
    confidence: number;
  }[];
  suggestions: {
    type: "optimization" | "refactoring" | "best-practice" | "security";
    description: string;
    priority: "low" | "medium" | "high";
    codeExample?: string;
  }[];
  concepts: {
    name: string;
    explanation: string;
    difficulty: "beginner" | "intermediate" | "advanced";
  }[];
  learningPath: {
    current: string;
    next: string[];
    prerequisites: string[];
  };
}

interface AICodeSummarizerProps {
  initialCode?: string;
  language?: string;
  onAnalysisComplete?: (analysis: CodeAnalysis) => void;
}

export function AICodeSummarizer({ initialCode = "", language = "javascript", onAnalysisComplete }: AICodeSummarizerProps) {
  const [code, setCode] = useState(initialCode);
  const [selectedLanguage, setSelectedLanguage] = useState(language);
  const [analysis, setAnalysis] = useState<CodeAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);

  // Sample code examples for demonstration
  const sampleCodes = {
    javascript: `function fibonacci(n) {
  if (n <= 1) return n;
  
  let cache = {};
  
  function fib(num) {
    if (num in cache) return cache[num];
    cache[num] = fib(num - 1) + fib(num - 2);
    return cache[num];
  }
  
  return fib(n);
}

// Usage with array methods
const numbers = [1, 2, 3, 4, 5];
const fibSequence = numbers.map(n => fibonacci(n));
console.log(fibSequence);`,
    
    python: `class DataProcessor:
    def __init__(self, data):
        self.data = data
        self.processed = False
    
    def clean_data(self):
        # Remove null values and duplicates
        cleaned = [x for x in self.data if x is not None]
        return list(set(cleaned))
    
    def transform(self, func):
        if not self.processed:
            self.data = self.clean_data()
            self.processed = True
        return [func(x) for x in self.data]
    
    def aggregate(self, operation='sum'):
        operations = {
            'sum': sum,
            'avg': lambda x: sum(x) / len(x),
            'max': max,
            'min': min
        }
        return operations.get(operation, sum)(self.data)`,
    
    java: `public class BinarySearchTree {
    private Node root;
    
    private class Node {
        int data;
        Node left, right;
        
        Node(int data) {
            this.data = data;
            left = right = null;
        }
    }
    
    public void insert(int data) {
        root = insertRec(root, data);
    }
    
    private Node insertRec(Node root, int data) {
        if (root == null) {
            root = new Node(data);
            return root;
        }
        
        if (data < root.data) {
            root.left = insertRec(root.left, data);
        } else if (data > root.data) {
            root.right = insertRec(root.right, data);
        }
        
        return root;
    }
    
    public boolean search(int data) {
        return searchRec(root, data);
    }
    
    private boolean searchRec(Node root, int data) {
        if (root == null) return false;
        if (root.data == data) return true;
        
        return data < root.data 
            ? searchRec(root.left, data)
            : searchRec(root.right, data);
    }
}`
  };

  useEffect(() => {
    if (!code && sampleCodes[selectedLanguage as keyof typeof sampleCodes]) {
      setCode(sampleCodes[selectedLanguage as keyof typeof sampleCodes]);
    }
  }, [selectedLanguage]);

  const generateAnalysis = async (): Promise<CodeAnalysis> => {
    // Simulate AI analysis with progressive steps
    const steps = [
      "Parsing code structure...",
      "Identifying patterns...",
      "Analyzing complexity...",
      "Generating suggestions...",
      "Creating learning path..."
    ];

    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800));
      setAnalysisProgress((i + 1) * 20);
    }

    // Mock AI analysis based on language and code content
    const mockAnalysis: CodeAnalysis = {
      summary: selectedLanguage === "javascript" 
        ? "This code implements a memoized Fibonacci function using dynamic programming. It demonstrates recursion optimization, caching strategies, and functional programming with array methods."
        : selectedLanguage === "python"
        ? "This code defines a DataProcessor class that implements the builder pattern for data transformation. It showcases object-oriented design, method chaining, and functional programming concepts."
        : "This code implements a Binary Search Tree data structure with recursive insertion and search operations. It demonstrates object-oriented programming, recursion, and tree traversal algorithms.",

      keyPoints: selectedLanguage === "javascript"
        ? [
            "Uses memoization to optimize recursive Fibonacci calculation",
            "Implements dynamic programming technique to avoid redundant calculations",
            "Demonstrates functional programming with map() method",
            "Shows closure usage for cache encapsulation"
          ]
        : selectedLanguage === "python"
        ? [
            "Implements data cleaning with list comprehensions",
            "Uses dictionary for flexible operation mapping", 
            "Demonstrates state management with processed flag",
            "Shows lambda functions for inline operations"
          ]
        : [
            "Implements binary search tree with recursive methods",
            "Uses private inner class for node structure",
            "Demonstrates recursive insertion and search algorithms",
            "Shows proper encapsulation with private methods"
          ],

      complexity: {
        score: selectedLanguage === "javascript" ? 65 : selectedLanguage === "python" ? 45 : 75,
        level: selectedLanguage === "javascript" ? "medium" : selectedLanguage === "python" ? "low" : "high",
        factors: selectedLanguage === "javascript"
          ? ["Recursive calls", "Memoization logic", "Closure usage"]
          : selectedLanguage === "python"
          ? ["List comprehensions", "Class methods", "Dictionary operations"]
          : ["Recursive tree operations", "Node management", "Binary search logic"]
      },

      patterns: selectedLanguage === "javascript"
        ? [
            { name: "Memoization", description: "Caching results to avoid redundant calculations", confidence: 95 },
            { name: "Dynamic Programming", description: "Breaking problem into smaller subproblems", confidence: 90 },
            { name: "Functional Programming", description: "Using higher-order functions like map", confidence: 85 }
          ]
        : selectedLanguage === "python"
        ? [
            { name: "Builder Pattern", description: "Step-by-step object construction", confidence: 80 },
            { name: "Strategy Pattern", description: "Flexible operation selection", confidence: 75 },
            { name: "State Management", description: "Tracking processing state", confidence: 70 }
          ]
        : [
            { name: "Binary Search Tree", description: "Self-organizing tree data structure", confidence: 95 },
            { name: "Recursive Design", description: "Self-referencing method calls", confidence: 90 },
            { name: "Encapsulation", description: "Private methods and inner classes", confidence: 85 }
          ],

      suggestions: selectedLanguage === "javascript"
        ? [
            {
              type: "optimization",
              description: "Consider using iterative approach for very large numbers to avoid stack overflow",
              priority: "medium",
              codeExample: "// Iterative version\nfunction fibIterative(n) {\n  if (n <= 1) return n;\n  let a = 0, b = 1;\n  for (let i = 2; i <= n; i++) {\n    [a, b] = [b, a + b];\n  }\n  return b;\n}"
            },
            {
              type: "best-practice",
              description: "Add input validation to handle edge cases",
              priority: "high",
              codeExample: "if (typeof n !== 'number' || n < 0) {\n  throw new Error('Input must be a non-negative number');\n}"
            }
          ]
        : selectedLanguage === "python"
        ? [
            {
              type: "best-practice",
              description: "Add type hints for better code documentation",
              priority: "medium",
              codeExample: "from typing import List, Callable, Any\n\ndef transform(self, func: Callable[[Any], Any]) -> List[Any]:"
            },
            {
              type: "optimization",
              description: "Use pandas for better performance with large datasets",
              priority: "low"
            }
          ]
        : [
            {
              type: "best-practice",
              description: "Add null checks for robustness",
              priority: "high",
              codeExample: "if (root == null || data == null) {\n    throw new IllegalArgumentException();\n}"
            },
            {
              type: "optimization",
              description: "Consider implementing tree balancing for better performance",
              priority: "medium"
            }
          ],

      concepts: selectedLanguage === "javascript"
        ? [
            { name: "Memoization", explanation: "Technique to store results of expensive function calls", difficulty: "intermediate" },
            { name: "Closures", explanation: "Functions that have access to outer scope variables", difficulty: "intermediate" },
            { name: "Dynamic Programming", explanation: "Solving problems by breaking them into subproblems", difficulty: "advanced" }
          ]
        : selectedLanguage === "python"
        ? [
            { name: "List Comprehensions", explanation: "Concise way to create lists from iterables", difficulty: "beginner" },
            { name: "Class Methods", explanation: "Functions defined inside a class", difficulty: "beginner" },
            { name: "Lambda Functions", explanation: "Anonymous functions for simple operations", difficulty: "intermediate" }
          ]
        : [
            { name: "Binary Search Tree", explanation: "Tree data structure with ordered node arrangement", difficulty: "intermediate" },
            { name: "Recursion", explanation: "Function calling itself with modified parameters", difficulty: "intermediate" },
            { name: "Tree Traversal", explanation: "Systematic way of visiting tree nodes", difficulty: "advanced" }
          ],

      learningPath: selectedLanguage === "javascript"
        ? {
            current: "Dynamic Programming with Memoization",
            next: ["Advanced Recursion Patterns", "Performance Optimization", "Algorithm Design"],
            prerequisites: ["Basic Functions", "Objects and Arrays", "Recursion Fundamentals"]
          }
        : selectedLanguage === "python"
        ? {
            current: "Object-Oriented Programming",
            next: ["Design Patterns", "Data Processing Libraries", "Advanced Python Features"],
            prerequisites: ["Python Basics", "Functions", "Data Structures"]
          }
        : {
            current: "Tree Data Structures",
            next: ["Advanced Trees (AVL, Red-Black)", "Graph Algorithms", "Algorithm Complexity"],
            prerequisites: ["Object-Oriented Programming", "Recursion", "Basic Data Structures"]
          }
    };

    return mockAnalysis;
  };

  const analyzeCode = async () => {
    if (!code.trim()) return;

    setIsAnalyzing(true);
    setAnalysisProgress(0);

    try {
      const result = await generateAnalysis();
      setAnalysis(result);
      onAnalysisComplete?.(result);
    } catch (error) {
      console.error("Analysis failed:", error);
    } finally {
      setIsAnalyzing(false);
      setAnalysisProgress(0);
    }
  };

  const loadSampleCode = () => {
    const sample = sampleCodes[selectedLanguage as keyof typeof sampleCodes];
    if (sample) {
      setCode(sample);
      setAnalysis(null);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "text-red-600 bg-red-50";
      case "medium": return "text-yellow-600 bg-yellow-50";
      case "low": return "text-green-600 bg-green-50";
      default: return "text-gray-600 bg-gray-50";
    }
  };

  const getComplexityColor = (level: string) => {
    switch (level) {
      case "low": return "text-green-600";
      case "medium": return "text-yellow-600";
      case "high": return "text-red-600";
      default: return "text-gray-600";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Brain className="h-6 w-6" />
          <h2 className="text-2xl font-bold">AI Code Summarization</h2>
        </div>
        <Badge variant="outline" className="flex items-center gap-1">
          <Zap className="h-3 w-3" />
          AI Powered
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Code Input */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Code className="h-5 w-5" />
                Code Input
              </CardTitle>
              <div className="flex items-center gap-2">
                <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="javascript">JavaScript</SelectItem>
                    <SelectItem value="python">Python</SelectItem>
                    <SelectItem value="java">Java</SelectItem>
                    <SelectItem value="cpp">C++</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" onClick={loadSampleCode}>
                  Load Sample
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="min-h-80 font-mono text-sm"
              placeholder="Paste your code here for AI analysis..."
            />
            
            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">
                {code.split('\n').length} lines • {code.length} characters
              </div>
              <Button onClick={analyzeCode} disabled={isAnalyzing || !code.trim()}>
                {isAnalyzing ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Brain className="h-4 w-4 mr-2" />
                    Analyze Code
                  </>
                )}
              </Button>
            </div>

            {isAnalyzing && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Analysis Progress</span>
                  <span>{analysisProgress}%</span>
                </div>
                <Progress value={analysisProgress} />
              </div>
            )}
          </CardContent>
        </Card>

        {/* Analysis Results */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              AI Analysis Results
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!analysis ? (
              <div className="text-center py-12 text-muted-foreground">
                <Brain className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Submit code above to get AI-powered analysis</p>
              </div>
            ) : (
              <Tabs defaultValue="summary" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="summary">Summary</TabsTrigger>
                  <TabsTrigger value="complexity">Complexity</TabsTrigger>
                  <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
                  <TabsTrigger value="learning">Learning</TabsTrigger>
                </TabsList>

                <TabsContent value="summary" className="space-y-4">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-2">Code Summary</h3>
                      <p className="text-sm text-muted-foreground">{analysis.summary}</p>
                    </div>
                    
                    <div>
                      <h3 className="font-semibold mb-2">Key Points</h3>
                      <ul className="space-y-1">
                        {analysis.keyPoints.map((point, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                            {point}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-2">Detected Patterns</h3>
                      <div className="space-y-2">
                        {analysis.patterns.map((pattern, index) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                            <div>
                              <p className="font-medium text-sm">{pattern.name}</p>
                              <p className="text-xs text-muted-foreground">{pattern.description}</p>
                            </div>
                            <Badge variant="secondary">{pattern.confidence}%</Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="complexity" className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-muted rounded">
                      <div>
                        <h3 className="font-semibold">Complexity Score</h3>
                        <p className="text-sm text-muted-foreground">Overall code complexity assessment</p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold">{analysis.complexity.score}/100</div>
                        <Badge className={getComplexityColor(analysis.complexity.level)}>
                          {analysis.complexity.level.toUpperCase()}
                        </Badge>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-2">Complexity Factors</h3>
                      <ul className="space-y-1">
                        {analysis.complexity.factors.map((factor, index) => (
                          <li key={index} className="flex items-center gap-2 text-sm">
                            <TrendingUp className="h-4 w-4 text-blue-600" />
                            {factor}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-4 bg-blue-50 rounded">
                      <h4 className="font-medium text-blue-900 mb-1">Complexity Tips</h4>
                      <p className="text-sm text-blue-700">
                        {analysis.complexity.level === "high" 
                          ? "Consider breaking this code into smaller, more focused functions."
                          : analysis.complexity.level === "medium"
                          ? "Good balance of functionality and readability. Consider minor refactoring for clarity."
                          : "Well-structured code with good readability and maintainability."
                        }
                      </p>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="suggestions" className="space-y-4">
                  <div className="space-y-3">
                    {analysis.suggestions.map((suggestion, index) => (
                      <Card key={index}>
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="capitalize">
                                {suggestion.type.replace('-', ' ')}
                              </Badge>
                              <Badge className={getPriorityColor(suggestion.priority)}>
                                {suggestion.priority} priority
                              </Badge>
                            </div>
                          </div>
                          <p className="text-sm mb-3">{suggestion.description}</p>
                          {suggestion.codeExample && (
                            <div className="bg-gray-900 text-green-400 p-3 rounded font-mono text-xs overflow-x-auto">
                              <pre>{suggestion.codeExample}</pre>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="learning" className="space-y-4">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-2">Concepts in This Code</h3>
                      <div className="space-y-2">
                        {analysis.concepts.map((concept, index) => (
                          <div key={index} className="p-3 border rounded">
                            <div className="flex items-center justify-between mb-1">
                              <h4 className="font-medium">{concept.name}</h4>
                              <Badge variant="outline" className="capitalize">
                                {concept.difficulty}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">{concept.explanation}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded border border-blue-200">
                      <h3 className="font-semibold mb-3 flex items-center gap-2">
                        <Target className="h-5 w-5" />
                        Personalized Learning Path
                      </h3>
                      
                      <div className="space-y-3">
                        <div>
                          <p className="text-sm font-medium text-blue-900">Current Level:</p>
                          <p className="text-sm text-blue-700">{analysis.learningPath.current}</p>
                        </div>
                        
                        <div>
                          <p className="text-sm font-medium text-blue-900">Next Steps:</p>
                          <ul className="space-y-1">
                            {analysis.learningPath.next.map((step, index) => (
                              <li key={index} className="text-sm text-blue-700 flex items-center gap-1">
                                <Lightbulb className="h-3 w-3" />
                                {step}
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <p className="text-sm font-medium text-blue-900">Prerequisites Covered:</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {analysis.learningPath.prerequisites.map((prereq, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                ✓ {prereq}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}