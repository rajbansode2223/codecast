import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LiveCoding } from "@/components/LiveCoding";
import { InteractiveCodeSnippets } from "@/components/InteractiveCodeSnippets";
import { AICodeSummarizer } from "@/components/AICodeSummarizer";
import { BugWalkthroughMode } from "@/components/BugWalkthroughMode";
import { VersionControlIntegration } from "@/components/VersionControlIntegration";
import { 
  Code, 
  Clock, 
  Users, 
  Zap,
  BookOpen,
  Video,
  Play,
  TrendingUp,
  Brain,
  Bug,
  GitBranch,
  Layers,
  Terminal
} from "lucide-react";

export default function LiveCodingPage() {
  const [activeSession, setActiveSession] = useState<string | null>(null);

  const sampleSessions = [
    {
      id: "session1",
      title: "Building a React Todo App",
      description: "Step-by-step implementation of a todo application with React hooks",
      language: "javascript",
      duration: "45 min",
      participants: 234,
      difficulty: "Beginner",
      tags: ["React", "Hooks", "State Management"],
      instructor: "ReactMaster_Pro",
      isLive: true
    },
    {
      id: "session2", 
      title: "Python Data Analysis with Pandas",
      description: "Exploring data visualization and analysis techniques",
      language: "python",
      duration: "60 min", 
      participants: 187,
      difficulty: "Intermediate",
      tags: ["Python", "Pandas", "Data Science"],
      instructor: "DataScience_Expert",
      isLive: false
    },
    {
      id: "session3",
      title: "Algorithm Design Patterns in Java",
      description: "Implementing common algorithms and design patterns",
      language: "java",
      duration: "90 min",
      participants: 156,
      difficulty: "Advanced",
      tags: ["Java", "Algorithms", "Design Patterns"],
      instructor: "AlgoMaster_123",
      isLive: true
    }
  ];

  if (activeSession) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Button 
            variant="outline" 
            onClick={() => setActiveSession(null)}
            className="mb-4"
          >
            ← Back to Sessions
          </Button>
        </div>
        
        <Tabs defaultValue="live-coding" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="live-coding" className="flex items-center gap-2">
              <Terminal className="h-4 w-4" />
              Live Coding
            </TabsTrigger>
            <TabsTrigger value="snippets" className="flex items-center gap-2">
              <Layers className="h-4 w-4" />
              Code Snippets
            </TabsTrigger>
            <TabsTrigger value="ai-summary" className="flex items-center gap-2">
              <Brain className="h-4 w-4" />
              AI Analysis
            </TabsTrigger>
            <TabsTrigger value="bug-walkthrough" className="flex items-center gap-2">
              <Bug className="h-4 w-4" />
              Debug Mode
            </TabsTrigger>
            <TabsTrigger value="version-control" className="flex items-center gap-2">
              <GitBranch className="h-4 w-4" />
              Version Control
            </TabsTrigger>
          </TabsList>

          <TabsContent value="live-coding" className="mt-6">
            <LiveCoding 
              initialCode="// Welcome to Live Coding!\nconsole.log('Hello, World!');"
              language="javascript"
            />
          </TabsContent>

          <TabsContent value="snippets" className="mt-6">
            <InteractiveCodeSnippets />
          </TabsContent>

          <TabsContent value="ai-summary" className="mt-6">
            <AICodeSummarizer />
          </TabsContent>

          <TabsContent value="bug-walkthrough" className="mt-6">
            <BugWalkthroughMode />
          </TabsContent>

          <TabsContent value="version-control" className="mt-6">
            <VersionControlIntegration />
          </TabsContent>
        </Tabs>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
          Live Coding Sessions
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Code along with experts, rewind your progress, and learn through interactive programming
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <Code className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">24</p>
                <p className="text-sm text-muted-foreground">Active Sessions</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Users className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">1.8K</p>
                <p className="text-sm text-muted-foreground">Live Participants</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Clock className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">156</p>
                <p className="text-sm text-muted-foreground">Hours Coded Today</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Zap className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">92%</p>
                <p className="text-sm text-muted-foreground">Success Rate</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Feature Highlights */}
      <Card className="bg-gradient-to-r from-blue-50 to-green-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Video className="h-6 w-6 text-blue-600" />
            Interactive Timeline Features
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Clock className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold mb-2">Rewindable Timeline</h3>
                <p className="text-sm text-muted-foreground">
                  Jump to any point in your coding session and replay your progress step by step
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <Code className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold mb-2">Live Code Execution</h3>
                <p className="text-sm text-muted-foreground">
                  Run code in real-time with instant feedback and error detection
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <BookOpen className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <h3 className="font-semibold mb-2">Auto-Save Snapshots</h3>
                <p className="text-sm text-muted-foreground">
                  Automatic progress saving with manual snapshot creation for key moments
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Live Sessions */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Live Coding Sessions</h2>
          <Button>
            <Play className="h-4 w-4 mr-2" />
            Start New Session
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sampleSessions.map((session) => (
            <Card key={session.id} className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg mb-2">{session.title}</CardTitle>
                    <p className="text-sm text-muted-foreground">{session.description}</p>
                  </div>
                  {session.isLive && (
                    <Badge variant="destructive" className="animate-pulse">
                      LIVE
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{session.language}</Badge>
                      <Badge variant="outline">{session.difficulty}</Badge>
                    </div>
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {session.duration}
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Users className="h-3 w-3" />
                      {session.participants} participants
                    </div>
                    <span className="text-muted-foreground">by {session.instructor}</span>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {session.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <Button 
                    className="w-full"
                    onClick={() => setActiveSession(session.id)}
                  >
                    {session.isLive ? "Join Live Session" : "Start Coding"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Learning Benefits */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-6 w-6 text-green-600" />
            Why Live Coding Works
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-green-600 mb-2">87%</p>
              <p className="text-sm text-muted-foreground">
                better retention with hands-on coding vs watching videos
              </p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-blue-600 mb-2">3.2x</p>
              <p className="text-sm text-muted-foreground">
                faster debugging skills development with timeline replay
              </p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-purple-600 mb-2">65%</p>
              <p className="text-sm text-muted-foreground">
                of learners complete projects when using interactive sessions
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}