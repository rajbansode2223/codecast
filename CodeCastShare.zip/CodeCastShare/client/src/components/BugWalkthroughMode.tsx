import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Bug, 
  Search, 
  CheckCircle, 
  AlertTriangle, 
  ArrowRight, 
  ArrowLeft,
  Play,
  Pause,
  RotateCcw,
  Lightbulb,
  Code,
  Terminal,
  FileText,
  Target,
  Clock,
  Zap
} from "lucide-react";

interface BugStep {
  id: number;
  title: string;
  description: string;
  codeSection?: {
    line: number;
    code: string;
    highlight: boolean;
  };
  explanation: string;
  action: string;
  expectedResult: string;
  commonMistakes: string[];
  tips: string[];
  debuggingTechnique: string;
}

interface BugWalkthrough {
  id: string;
  title: string;
  description: string;
  bugType: "syntax" | "logic" | "runtime" | "performance";
  difficulty: "beginner" | "intermediate" | "advanced";
  language: string;
  originalCode: string;
  fixedCode: string;
  steps: BugStep[];
  learningObjectives: string[];
  estimatedTime: number;
}

interface BugWalkthroughModeProps {
  initialCode?: string;
  onBugFixed?: (fixedCode: string) => void;
}

export function BugWalkthroughMode({ initialCode = "", onBugFixed }: BugWalkthroughModeProps) {
  const [walkthroughs, setWalkthroughs] = useState<BugWalkthrough[]>([]);
  const [selectedWalkthrough, setSelectedWalkthrough] = useState<BugWalkthrough | null>(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [isWalking, setIsWalking] = useState(false);
  const [userCode, setUserCode] = useState(initialCode);
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set());
  const [filterType, setFilterType] = useState("all");
  const [filterDifficulty, setFilterDifficulty] = useState("all");

  // Sample bug walkthroughs
  useEffect(() => {
    const sampleWalkthroughs: BugWalkthrough[] = [
      {
        id: "1",
        title: "Array Index Out of Bounds",
        description: "Learn to identify and fix common array access errors",
        bugType: "runtime",
        difficulty: "beginner",
        language: "javascript",
        originalCode: `function getLastThreeElements(arr) {
  const result = [];
  for (let i = arr.length - 3; i <= arr.length; i++) {
    result.push(arr[i]);
  }
  return result;
}

const numbers = [1, 2, 3, 4, 5];
console.log(getLastThreeElements(numbers));`,
        fixedCode: `function getLastThreeElements(arr) {
  const result = [];
  // Fix: Start from correct index and use proper boundary
  for (let i = Math.max(0, arr.length - 3); i < arr.length; i++) {
    result.push(arr[i]);
  }
  return result;
}

const numbers = [1, 2, 3, 4, 5];
console.log(getLastThreeElements(numbers));`,
        steps: [
          {
            id: 1,
            title: "Identify the Problem",
            description: "Run the code and observe the error",
            codeSection: {
              line: 3,
              code: "for (let i = arr.length - 3; i <= arr.length; i++) {",
              highlight: true
            },
            explanation: "The loop condition `i <= arr.length` causes an out-of-bounds access. Array indices go from 0 to length-1.",
            action: "Execute the code and note the undefined values in output",
            expectedResult: "You should see undefined values in the result array",
            commonMistakes: [
              "Not recognizing that array.length is one more than the last valid index",
              "Using <= instead of < in loop conditions"
            ],
            tips: [
              "Always remember: valid array indices are 0 to length-1",
              "Use console.log to debug loop variables"
            ],
            debuggingTechnique: "Add console.log(i, arr[i]) inside the loop to see what's happening"
          },
          {
            id: 2,
            title: "Analyze the Loop Boundary",
            description: "Examine why the loop goes beyond array bounds",
            codeSection: {
              line: 3,
              code: "i <= arr.length",
              highlight: true
            },
            explanation: "When i equals arr.length, we're accessing an index that doesn't exist. The last valid index is arr.length - 1.",
            action: "Change <= to < in the loop condition",
            expectedResult: "This prevents accessing arr[arr.length] which is undefined",
            commonMistakes: [
              "Thinking array.length is a valid index",
              "Not testing with edge cases like empty arrays"
            ],
            tips: [
              "Use < instead of <= when iterating through arrays",
              "Test your loops with different array sizes"
            ],
            debuggingTechnique: "Print the loop condition values to understand the boundary"
          },
          {
            id: 3,
            title: "Handle Edge Cases",
            description: "Consider what happens with arrays smaller than 3 elements",
            codeSection: {
              line: 3,
              code: "let i = arr.length - 3",
              highlight: true
            },
            explanation: "If arr.length < 3, then arr.length - 3 becomes negative, which isn't a valid starting point.",
            action: "Use Math.max(0, arr.length - 3) to ensure we start from a valid index",
            expectedResult: "The function now works correctly with arrays of any size",
            commonMistakes: [
              "Not considering arrays smaller than expected",
              "Assuming minimum array size without validation"
            ],
            tips: [
              "Always handle edge cases in your functions",
              "Use Math.max/Math.min for boundary constraints"
            ],
            debuggingTechnique: "Test with arrays of different sizes: [], [1], [1,2], [1,2,3], [1,2,3,4,5]"
          },
          {
            id: 4,
            title: "Verify the Fix",
            description: "Test the corrected function with various inputs",
            explanation: "The fixed function should now work correctly with arrays of any size.",
            action: "Test with multiple array sizes to confirm the fix",
            expectedResult: "Function returns correct results for all test cases",
            commonMistakes: [
              "Only testing with the original problematic input",
              "Not verifying edge cases after fixing"
            ],
            tips: [
              "Create comprehensive test cases",
              "Include boundary conditions in your tests"
            ],
            debuggingTechnique: "Write unit tests to prevent regression"
          }
        ],
        learningObjectives: [
          "Understand array indexing and bounds",
          "Learn to identify off-by-one errors",
          "Practice defensive programming with edge cases",
          "Master loop boundary conditions"
        ],
        estimatedTime: 15
      },
      {
        id: "2",
        title: "Async Function Race Condition",
        description: "Debug timing issues in asynchronous code",
        bugType: "logic",
        difficulty: "intermediate",
        language: "javascript",
        originalCode: `let counter = 0;

async function incrementCounter() {
  const current = counter;
  await new Promise(resolve => setTimeout(resolve, 100));
  counter = current + 1;
}

async function runIncrements() {
  await Promise.all([
    incrementCounter(),
    incrementCounter(),
    incrementCounter()
  ]);
  console.log('Final counter:', counter);
}

runIncrements();`,
        fixedCode: `let counter = 0;
const mutex = Promise.resolve();

async function incrementCounter() {
  return mutex.then(async () => {
    const current = counter;
    await new Promise(resolve => setTimeout(resolve, 100));
    counter = current + 1;
  });
}

async function runIncrements() {
  await Promise.all([
    incrementCounter(),
    incrementCounter(),
    incrementCounter()
  ]);
  console.log('Final counter:', counter);
}

runIncrements();`,
        steps: [
          {
            id: 1,
            title: "Observe the Race Condition",
            description: "Run the code and see the unexpected result",
            explanation: "All three async functions read the same initial value of counter (0) before any of them update it.",
            action: "Execute the code multiple times and observe the output",
            expectedResult: "Counter shows 1 instead of expected 3",
            commonMistakes: [
              "Assuming async operations are automatically sequential",
              "Not considering shared state in concurrent operations"
            ],
            tips: [
              "Concurrent async operations can interfere with each other",
              "Shared state needs protection in async environments"
            ],
            debuggingTechnique: "Add console.log statements to track the execution order"
          },
          {
            id: 2,
            title: "Understand the Problem",
            description: "Analyze why the counter doesn't reach the expected value",
            codeSection: {
              line: 4,
              code: "const current = counter;",
              highlight: true
            },
            explanation: "Each function reads counter before any writes happen, creating a race condition.",
            action: "Add logging to see the order of operations",
            expectedResult: "All functions read 0, then all write 1",
            commonMistakes: [
              "Not recognizing non-atomic operations",
              "Confusing concurrent with parallel execution"
            ],
            tips: [
              "Read-modify-write operations need synchronization",
              "Use debugging tools to visualize async execution"
            ],
            debuggingTechnique: "Log timestamps and function IDs to trace execution"
          },
          {
            id: 3,
            title: "Implement Synchronization",
            description: "Use a mutex pattern to serialize access",
            explanation: "A mutex ensures only one async operation modifies the counter at a time.",
            action: "Implement a promise-based mutex to serialize operations",
            expectedResult: "Counter correctly reaches 3",
            commonMistakes: [
              "Using complex synchronization when simple solutions exist",
              "Not chaining promises correctly"
            ],
            tips: [
              "Simple mutex patterns work well for basic synchronization",
              "Consider using async/await with proper sequencing"
            ],
            debuggingTechnique: "Verify mutual exclusion with detailed logging"
          }
        ],
        learningObjectives: [
          "Understand race conditions in async code",
          "Learn synchronization patterns",
          "Master Promise coordination",
          "Practice concurrent programming debugging"
        ],
        estimatedTime: 25
      },
      {
        id: "3",
        title: "Memory Leak in Event Listeners",
        description: "Find and fix memory leaks caused by improper cleanup",
        bugType: "performance",
        difficulty: "advanced",
        language: "javascript",
        originalCode: `class ComponentManager {
  constructor() {
    this.components = new Map();
  }

  createComponent(id, element) {
    const component = {
      id,
      element,
      data: new Array(1000).fill(0).map((_, i) => ({ value: i }))
    };

    // Add event listeners
    element.addEventListener('click', () => {
      console.log('Component clicked:', id);
      this.updateComponent(id);
    });

    this.components.set(id, component);
    return component;
  }

  removeComponent(id) {
    this.components.delete(id);
  }

  updateComponent(id) {
    const component = this.components.get(id);
    if (component) {
      component.data = component.data.map(item => ({
        ...item,
        value: item.value + 1
      }));
    }
  }
}`,
        fixedCode: `class ComponentManager {
  constructor() {
    this.components = new Map();
    this.eventListeners = new Map();
  }

  createComponent(id, element) {
    const component = {
      id,
      element,
      data: new Array(1000).fill(0).map((_, i) => ({ value: i }))
    };

    // Store event listener reference for cleanup
    const clickHandler = () => {
      console.log('Component clicked:', id);
      this.updateComponent(id);
    };

    element.addEventListener('click', clickHandler);
    this.eventListeners.set(id, { element, clickHandler });

    this.components.set(id, component);
    return component;
  }

  removeComponent(id) {
    // Clean up event listeners
    const listener = this.eventListeners.get(id);
    if (listener) {
      listener.element.removeEventListener('click', listener.clickHandler);
      this.eventListeners.delete(id);
    }

    this.components.delete(id);
  }

  updateComponent(id) {
    const component = this.components.get(id);
    if (component) {
      component.data = component.data.map(item => ({
        ...item,
        value: item.value + 1
      }));
    }
  }
}`,
        steps: [
          {
            id: 1,
            title: "Identify the Memory Leak",
            description: "Recognize that event listeners aren't being cleaned up",
            explanation: "When components are removed, their event listeners remain attached to DOM elements, preventing garbage collection.",
            action: "Use browser dev tools to monitor memory usage",
            expectedResult: "Memory usage increases with each component creation/removal cycle",
            commonMistakes: [
              "Forgetting that event listeners hold references",
              "Not considering cleanup in component lifecycle"
            ],
            tips: [
              "Every addEventListener needs a corresponding removeEventListener",
              "Use browser memory profiler to detect leaks"
            ],
            debuggingTechnique: "Monitor heap snapshots in Chrome DevTools"
          },
          {
            id: 2,
            title: "Understand Reference Chains",
            description: "Learn how event listeners prevent garbage collection",
            explanation: "Event listeners create closures that hold references to the component data, preventing cleanup.",
            action: "Analyze the closure scope in the event handler",
            expectedResult: "Event handler references keep component data alive",
            commonMistakes: [
              "Not understanding closure scope in event handlers",
              "Assuming DOM element removal cleans up listeners"
            ],
            tips: [
              "Closures in event handlers can capture large objects",
              "DOM element removal doesn't automatically remove listeners"
            ],
            debuggingTechnique: "Use memory profiler to see retained objects"
          },
          {
            id: 3,
            title: "Implement Proper Cleanup",
            description: "Store listener references and remove them explicitly",
            explanation: "Store event listener references so they can be properly removed during component cleanup.",
            action: "Modify the code to track and remove event listeners",
            expectedResult: "Memory usage remains stable during component creation/removal",
            commonMistakes: [
              "Using anonymous functions that can't be removed",
              "Not storing listener references for cleanup"
            ],
            tips: [
              "Store named function references for removeEventListener",
              "Consider using WeakMap for automatic cleanup"
            ],
            debuggingTechnique: "Verify cleanup with memory profiling tools"
          }
        ],
        learningObjectives: [
          "Understand memory leaks in JavaScript",
          "Learn proper event listener cleanup",
          "Master component lifecycle management",
          "Practice memory profiling techniques"
        ],
        estimatedTime: 30
      }
    ];

    setWalkthroughs(sampleWalkthroughs);
    if (sampleWalkthroughs.length > 0) {
      setSelectedWalkthrough(sampleWalkthroughs[0]);
      setUserCode(sampleWalkthroughs[0].originalCode);
    }
  }, []);

  const filteredWalkthroughs = walkthroughs.filter(walkthrough => {
    const matchesType = filterType === "all" || walkthrough.bugType === filterType;
    const matchesDifficulty = filterDifficulty === "all" || walkthrough.difficulty === filterDifficulty;
    return matchesType && matchesDifficulty;
  });

  const selectWalkthrough = (walkthrough: BugWalkthrough) => {
    setSelectedWalkthrough(walkthrough);
    setUserCode(walkthrough.originalCode);
    setCurrentStep(0);
    setCompletedSteps(new Set());
    setIsWalking(false);
  };

  const nextStep = () => {
    if (selectedWalkthrough && currentStep < selectedWalkthrough.steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const previousStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const markStepCompleted = () => {
    setCompletedSteps(prev => new Set([...Array.from(prev), currentStep]));
  };

  const startWalkthrough = () => {
    setIsWalking(true);
    setCurrentStep(0);
    setCompletedSteps(new Set());
  };

  const resetWalkthrough = () => {
    setIsWalking(false);
    setCurrentStep(0);
    setCompletedSteps(new Set());
    if (selectedWalkthrough) {
      setUserCode(selectedWalkthrough.originalCode);
    }
  };

  const applyFix = () => {
    if (selectedWalkthrough) {
      setUserCode(selectedWalkthrough.fixedCode);
      onBugFixed?.(selectedWalkthrough.fixedCode);
    }
  };

  const getBugTypeColor = (type: string) => {
    switch (type) {
      case "syntax": return "bg-red-100 text-red-700";
      case "logic": return "bg-yellow-100 text-yellow-700";
      case "runtime": return "bg-orange-100 text-orange-700";
      case "performance": return "bg-purple-100 text-purple-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-100 text-green-700";
      case "intermediate": return "bg-yellow-100 text-yellow-700";
      case "advanced": return "bg-red-100 text-red-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const currentStepData = selectedWalkthrough?.steps[currentStep];
  const progress = selectedWalkthrough ? ((currentStep + 1) / selectedWalkthrough.steps.length) * 100 : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bug className="h-6 w-6" />
          <h2 className="text-2xl font-bold">Bug Walkthrough Mode</h2>
        </div>
        <Badge variant="outline" className="flex items-center gap-1">
          <Target className="h-3 w-3" />
          Interactive Debugging
        </Badge>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Bug Type</label>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="syntax">Syntax Errors</SelectItem>
                  <SelectItem value="logic">Logic Errors</SelectItem>
                  <SelectItem value="runtime">Runtime Errors</SelectItem>
                  <SelectItem value="performance">Performance Issues</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Difficulty</label>
              <Select value={filterDifficulty} onValueChange={setFilterDifficulty}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="beginner">Beginner</SelectItem>
                  <SelectItem value="intermediate">Intermediate</SelectItem>
                  <SelectItem value="advanced">Advanced</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Status</label>
              <div className="flex items-center gap-2 pt-2">
                <Badge variant="outline">{filteredWalkthroughs.length} walkthroughs</Badge>
                {selectedWalkthrough && (
                  <Badge variant="secondary">
                    Step {currentStep + 1}/{selectedWalkthrough.steps.length}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Walkthrough List */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Available Walkthroughs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {filteredWalkthroughs.map((walkthrough) => (
                <Card 
                  key={walkthrough.id} 
                  className={`cursor-pointer transition-colors ${
                    selectedWalkthrough?.id === walkthrough.id ? 'border-primary bg-primary/5' : 'hover:bg-muted/50'
                  }`}
                  onClick={() => selectWalkthrough(walkthrough)}
                >
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <h4 className="font-medium text-sm">{walkthrough.title}</h4>
                      <p className="text-xs text-muted-foreground">{walkthrough.description}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1">
                          <Badge className={`text-xs ${getBugTypeColor(walkthrough.bugType)}`}>
                            {walkthrough.bugType}
                          </Badge>
                          <Badge className={`text-xs ${getDifficultyColor(walkthrough.difficulty)}`}>
                            {walkthrough.difficulty}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {walkthrough.estimatedTime}m
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Main Walkthrough Area */}
        <div className="lg:col-span-2 space-y-6">
          {selectedWalkthrough && (
            <>
              {/* Walkthrough Header */}
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Bug className="h-5 w-5" />
                        {selectedWalkthrough.title}
                      </CardTitle>
                      <p className="text-muted-foreground mt-1">{selectedWalkthrough.description}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getBugTypeColor(selectedWalkthrough.bugType)}>
                        {selectedWalkthrough.bugType}
                      </Badge>
                      <Badge className={getDifficultyColor(selectedWalkthrough.difficulty)}>
                        {selectedWalkthrough.difficulty}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {!isWalking ? (
                          <Button onClick={startWalkthrough}>
                            <Play className="h-4 w-4 mr-2" />
                            Start Walkthrough
                          </Button>
                        ) : (
                          <Button variant="outline" onClick={resetWalkthrough}>
                            <RotateCcw className="h-4 w-4 mr-2" />
                            Reset
                          </Button>
                        )}
                        <Button variant="outline" onClick={applyFix}>
                          <Zap className="h-4 w-4 mr-2" />
                          Show Fix
                        </Button>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {selectedWalkthrough.estimatedTime} min • {selectedWalkthrough.steps.length} steps
                      </div>
                    </div>

                    {isWalking && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>Progress</span>
                          <span>{Math.round(progress)}%</span>
                        </div>
                        <Progress value={progress} />
                      </div>
                    )}

                    <div>
                      <h4 className="font-medium mb-2">Learning Objectives</h4>
                      <ul className="space-y-1">
                        {selectedWalkthrough.learningObjectives.map((objective, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <Target className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                            {objective}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Step Content */}
              {isWalking && currentStepData && (
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2">
                        <span className="flex items-center justify-center w-6 h-6 bg-primary text-primary-foreground rounded-full text-sm">
                          {currentStep + 1}
                        </span>
                        {currentStepData.title}
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={previousStep}
                          disabled={currentStep === 0}
                        >
                          <ArrowLeft className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={nextStep}
                          disabled={currentStep === selectedWalkthrough.steps.length - 1}
                        >
                          <ArrowRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Tabs defaultValue="instruction" className="w-full">
                      <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="instruction">
                          <FileText className="h-4 w-4 mr-1" />
                          Instruction
                        </TabsTrigger>
                        <TabsTrigger value="code">
                          <Code className="h-4 w-4 mr-1" />
                          Code Focus
                        </TabsTrigger>
                        <TabsTrigger value="debugging">
                          <Search className="h-4 w-4 mr-1" />
                          Debug Tips
                        </TabsTrigger>
                        <TabsTrigger value="mistakes">
                          <AlertTriangle className="h-4 w-4 mr-1" />
                          Mistakes
                        </TabsTrigger>
                      </TabsList>

                      <TabsContent value="instruction" className="space-y-4">
                        <div className="space-y-3">
                          <div>
                            <h4 className="font-medium text-sm mb-1">Description</h4>
                            <p className="text-sm text-muted-foreground">{currentStepData.description}</p>
                          </div>
                          <div>
                            <h4 className="font-medium text-sm mb-1">Explanation</h4>
                            <p className="text-sm">{currentStepData.explanation}</p>
                          </div>
                          <div>
                            <h4 className="font-medium text-sm mb-1">Action Required</h4>
                            <p className="text-sm font-medium text-blue-700">{currentStepData.action}</p>
                          </div>
                          <div>
                            <h4 className="font-medium text-sm mb-1">Expected Result</h4>
                            <p className="text-sm text-green-700">{currentStepData.expectedResult}</p>
                          </div>
                          <Button 
                            onClick={markStepCompleted}
                            disabled={completedSteps.has(currentStep)}
                            className="w-full"
                          >
                            {completedSteps.has(currentStep) ? (
                              <>
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Step Completed
                              </>
                            ) : (
                              <>
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Mark as Complete
                              </>
                            )}
                          </Button>
                        </div>
                      </TabsContent>

                      <TabsContent value="code" className="space-y-4">
                        {currentStepData.codeSection && (
                          <div className="space-y-2">
                            <h4 className="font-medium text-sm">Focus Area (Line {currentStepData.codeSection.line})</h4>
                            <div className={`p-3 rounded font-mono text-sm ${
                              currentStepData.codeSection.highlight ? 'bg-red-50 border border-red-200' : 'bg-gray-50'
                            }`}>
                              <pre>{currentStepData.codeSection.code}</pre>
                            </div>
                          </div>
                        )}
                        <div>
                          <h4 className="font-medium text-sm mb-2">Debugging Technique</h4>
                          <div className="p-3 bg-blue-50 rounded border border-blue-200">
                            <p className="text-sm text-blue-700">{currentStepData.debuggingTechnique}</p>
                          </div>
                        </div>
                      </TabsContent>

                      <TabsContent value="debugging" className="space-y-4">
                        <div>
                          <h4 className="font-medium text-sm mb-2">Debugging Tips</h4>
                          <ul className="space-y-2">
                            {currentStepData.tips.map((tip, index) => (
                              <li key={index} className="flex items-start gap-2 text-sm">
                                <Lightbulb className="h-4 w-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                                {tip}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </TabsContent>

                      <TabsContent value="mistakes" className="space-y-4">
                        <div>
                          <h4 className="font-medium text-sm mb-2">Common Mistakes</h4>
                          <ul className="space-y-2">
                            {currentStepData.commonMistakes.map((mistake, index) => (
                              <li key={index} className="flex items-start gap-2 text-sm">
                                <AlertTriangle className="h-4 w-4 text-orange-600 mt-0.5 flex-shrink-0" />
                                {mistake}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
              )}

              {/* Code Editor */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Terminal className="h-5 w-5" />
                    Interactive Code Editor
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea
                    value={userCode}
                    onChange={(e) => setUserCode(e.target.value)}
                    className="min-h-64 font-mono text-sm"
                    placeholder="Code will appear here..."
                  />
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  );
}