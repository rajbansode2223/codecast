import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageCircle, Users, Clock, Send, Reply, Heart, Flag } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  message: string;
  timestamp: Date;
  replies?: ChatMessage[];
  likes: number;
  isLiked: boolean;
  type: 'message' | 'reaction' | 'system';
  videoTimestamp?: number;
}

interface LiveChatProps {
  videoId: number;
  isLive?: boolean;
  onTimestampClick?: (timestamp: number) => void;
}

export function LiveChat({ videoId, isLive = false, onTimestampClick }: LiveChatProps) {
  const { user, isAuthenticated } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [activeUsers, setActiveUsers] = useState(0);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Simulate real-time chat with WebSocket-like behavior
  useEffect(() => {
    // Initial messages
    const initialMessages: ChatMessage[] = [
      {
        id: "1",
        userId: "user1",
        userName: "CodeMaster_42",
        userAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face",
        message: "Great explanation of the algorithm! Really helped me understand the time complexity.",
        timestamp: new Date(Date.now() - 300000),
        likes: 5,
        isLiked: false,
        type: 'message',
        videoTimestamp: 120
      },
      {
        id: "2",
        userId: "user2",
        userName: "ReactDev_Sarah",
        userAvatar: "https://images.unsplash.com/photo-1494790108755-2616b612b691?w=40&h=40&fit=crop&crop=face",
        message: "Can someone explain why we use useCallback here?",
        timestamp: new Date(Date.now() - 240000),
        likes: 2,
        isLiked: true,
        type: 'message',
        videoTimestamp: 180,
        replies: [
          {
            id: "2-1",
            userId: "user3",
            userName: "JSExpert_Tom",
            message: "useCallback prevents unnecessary re-renders when passing functions as props",
            timestamp: new Date(Date.now() - 200000),
            likes: 3,
            isLiked: false,
            type: 'message'
          }
        ]
      },
      {
        id: "3",
        userId: "user4",
        userName: "PythonNinja",
        message: "This is exactly what I needed for my project! 🚀",
        timestamp: new Date(Date.now() - 120000),
        likes: 8,
        isLiked: false,
        type: 'message',
        videoTimestamp: 300
      }
    ];

    setMessages(initialMessages);
    setActiveUsers(isLive ? Math.floor(Math.random() * 50) + 10 : Math.floor(Math.random() * 20) + 5);

    // Simulate new messages in live mode
    if (isLive) {
      const interval = setInterval(() => {
        const randomMessages = [
          "This is amazing content!",
          "Thanks for the clear explanation",
          "Could you show the code again?",
          "Perfect timing with this topic",
          "Really helpful for beginners",
          "Can you explain that part again?",
          "Great use case example",
          "This solved my problem!"
        ];

        const randomUsers = [
          { name: "DevLearner_101", avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face" },
          { name: "CodeNewbie_Jane", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face" },
          { name: "TechEnthusiast", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face" },
          { name: "FullStackDev", avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=40&h=40&fit=crop&crop=face" }
        ];

        const randomUser = randomUsers[Math.floor(Math.random() * randomUsers.length)];
        const randomMessage = randomMessages[Math.floor(Math.random() * randomMessages.length)];

        const newMsg: ChatMessage = {
          id: `msg_${Date.now()}`,
          userId: `user_${Math.random()}`,
          userName: randomUser.name,
          userAvatar: randomUser.avatar,
          message: randomMessage,
          timestamp: new Date(),
          likes: 0,
          isLiked: false,
          type: 'message'
        };

        setMessages(prev => [...prev, newMsg]);
      }, Math.random() * 10000 + 5000); // Random interval between 5-15 seconds

      return () => clearInterval(interval);
    }
  }, [isLive, videoId]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = () => {
    if (!newMessage.trim() || !isAuthenticated) return;

    const message: ChatMessage = {
      id: `msg_${Date.now()}`,
      userId: user?.id || "current_user",
      userName: user?.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : "You",
      userAvatar: user?.profileImageUrl,
      message: newMessage,
      timestamp: new Date(),
      likes: 0,
      isLiked: false,
      type: 'message'
    };

    if (replyTo) {
      setMessages(prev => prev.map(msg => 
        msg.id === replyTo 
          ? { ...msg, replies: [...(msg.replies || []), message] }
          : msg
      ));
      setReplyTo(null);
    } else {
      setMessages(prev => [...prev, message]);
    }

    setNewMessage("");
  };

  const likeMessage = (messageId: string) => {
    setMessages(prev => prev.map(msg => 
      msg.id === messageId 
        ? { ...msg, likes: msg.isLiked ? msg.likes - 1 : msg.likes + 1, isLiked: !msg.isLiked }
        : msg
    ));
  };

  const formatTimestamp = (timestamp: Date) => {
    const now = new Date();
    const diff = now.getTime() - timestamp.getTime();
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return "now";
    if (minutes < 60) return `${minutes}m`;
    if (minutes < 1440) return `${Math.floor(minutes / 60)}h`;
    return `${Math.floor(minutes / 1440)}d`;
  };

  const formatVideoTimestamp = (seconds?: number) => {
    if (!seconds) return "";
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <MessageCircle className="h-5 w-5" />
            {isLive ? "Live Chat" : "Discussion"}
          </CardTitle>
          <div className="flex items-center gap-2">
            {isLive && (
              <Badge variant="destructive" className="animate-pulse">
                LIVE
              </Badge>
            )}
            <Badge variant="secondary" className="flex items-center gap-1">
              <Users className="h-3 w-3" />
              {activeUsers}
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-4 pt-0">
        <ScrollArea className="flex-1 pr-4" ref={scrollAreaRef}>
          <div className="space-y-4">
            {messages.map((message) => (
              <div key={message.id} className="group">
                <div className="flex gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={message.userAvatar} />
                    <AvatarFallback>{message.userName[0]}</AvatarFallback>
                  </Avatar>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm">{message.userName}</span>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {formatTimestamp(message.timestamp)}
                      </span>
                      {message.videoTimestamp && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-5 px-2 text-xs text-blue-600 hover:text-blue-700"
                          onClick={() => onTimestampClick?.(message.videoTimestamp!)}
                        >
                          {formatVideoTimestamp(message.videoTimestamp)}
                        </Button>
                      )}
                    </div>

                    <p className="text-sm text-foreground mb-2 break-words">
                      {message.message}
                    </p>

                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        variant="ghost"
                        size="sm"
                        className={`h-6 px-2 text-xs ${message.isLiked ? 'text-red-500' : 'text-muted-foreground'}`}
                        onClick={() => likeMessage(message.id)}
                      >
                        <Heart className={`h-3 w-3 mr-1 ${message.isLiked ? 'fill-current' : ''}`} />
                        {message.likes}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2 text-xs text-muted-foreground"
                        onClick={() => setReplyTo(message.id)}
                      >
                        <Reply className="h-3 w-3 mr-1" />
                        Reply
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2 text-xs text-muted-foreground"
                      >
                        <Flag className="h-3 w-3" />
                      </Button>
                    </div>

                    {/* Replies */}
                    {message.replies && message.replies.length > 0 && (
                      <div className="mt-3 ml-4 border-l-2 border-muted pl-4 space-y-2">
                        {message.replies.map((reply) => (
                          <div key={reply.id} className="flex gap-2">
                            <Avatar className="h-6 w-6">
                              <AvatarFallback className="text-xs">{reply.userName[0]}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium text-xs">{reply.userName}</span>
                                <span className="text-xs text-muted-foreground">
                                  {formatTimestamp(reply.timestamp)}
                                </span>
                              </div>
                              <p className="text-xs text-foreground">{reply.message}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Message Input */}
        <div className="mt-4 pt-4 border-t">
          {replyTo && (
            <div className="flex items-center gap-2 mb-2 p-2 bg-muted rounded text-sm">
              <Reply className="h-4 w-4" />
              <span>Replying to message</span>
              <Button
                variant="ghost"
                size="sm"
                className="ml-auto h-6 w-6 p-0"
                onClick={() => setReplyTo(null)}
              >
                ×
              </Button>
            </div>
          )}
          
          <div className="flex gap-2">
            <Input
              placeholder={isAuthenticated ? "Type a message..." : "Sign in to chat"}
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && sendMessage()}
              disabled={!isAuthenticated}
              className="flex-1"
            />
            <Button
              onClick={sendMessage}
              disabled={!newMessage.trim() || !isAuthenticated}
              size="sm"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          
          {!isAuthenticated && (
            <p className="text-xs text-muted-foreground mt-2 text-center">
              <a href="/api/login" className="text-blue-600 hover:underline">
                Sign in
              </a> to join the conversation
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}