import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Play, Eye, Lightbulb, Trophy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CodeChallengeProps {
  challenge: {
    id: number;
    title: string;
    description: string;
    startingCode: string;
    language: string;
    difficulty: string;
    hints: string[];
    testCases: string[];
  };
  onSubmit?: (code: string) => void;
}

export function CodeChallenge({ challenge, onSubmit }: CodeChallengeProps) {
  const [userCode, setUserCode] = useState(challenge.startingCode || "");
  const [showHints, setShowHints] = useState(false);
  const [currentHint, setCurrentHint] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [testResults, setTestResults] = useState<string[]>([]);
  const { toast } = useToast();

  const handleRunCode = async () => {
    setIsRunning(true);
    // Simulate code execution
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const mockResults = challenge.testCases.map((_, i) => 
      Math.random() > 0.3 ? "✓ Passed" : "✗ Failed"
    );
    setTestResults(mockResults);
    setIsRunning(false);
    
    toast({
      title: "Code executed",
      description: `${mockResults.filter(r => r.includes("✓")).length}/${mockResults.length} tests passed`,
    });
  };

  const handleSubmit = () => {
    onSubmit?.(userCode);
    toast({
      title: "Solution submitted!",
      description: "Your code has been submitted for review.",
    });
  };

  const nextHint = () => {
    if (currentHint < challenge.hints.length - 1) {
      setCurrentHint(currentHint + 1);
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "easy": return "bg-green-100 text-green-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "hard": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-yellow-500" />
              {challenge.title}
            </CardTitle>
            <CardDescription className="mt-2">
              {challenge.description}
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Badge className={getDifficultyColor(challenge.difficulty)}>
              {challenge.difficulty}
            </Badge>
            <Badge variant="outline">{challenge.language}</Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <Tabs defaultValue="challenge" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="challenge">Challenge</TabsTrigger>
            <TabsTrigger value="hints">Hints ({challenge.hints.length})</TabsTrigger>
            <TabsTrigger value="results">Test Results</TabsTrigger>
          </TabsList>

          <TabsContent value="challenge" className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Your Solution:</label>
              <Textarea
                value={userCode}
                onChange={(e) => setUserCode(e.target.value)}
                className="min-h-[300px] font-mono text-sm"
                placeholder="Write your solution here..."
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={handleRunCode} disabled={isRunning} className="flex items-center gap-2">
                <Play className="h-4 w-4" />
                {isRunning ? "Running..." : "Run Tests"}
              </Button>
              <Button onClick={handleSubmit} variant="outline" className="flex items-center gap-2">
                <Trophy className="h-4 w-4" />
                Submit Solution
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="hints" className="space-y-4">
            {challenge.hints.length > 0 ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium flex items-center gap-2">
                    <Lightbulb className="h-4 w-4 text-yellow-500" />
                    Hint {currentHint + 1} of {challenge.hints.length}
                  </h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowHints(!showHints)}
                    className="flex items-center gap-2"
                  >
                    <Eye className="h-4 w-4" />
                    {showHints ? "Hide" : "Show"} Hint
                  </Button>
                </div>

                {showHints && (
                  <Card className="bg-blue-50 border-blue-200">
                    <CardContent className="pt-4">
                      <p className="text-sm text-blue-800">
                        {challenge.hints[currentHint]}
                      </p>
                    </CardContent>
                  </Card>
                )}

                <div className="flex justify-between">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentHint(Math.max(0, currentHint - 1))}
                    disabled={currentHint === 0}
                  >
                    Previous Hint
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={nextHint}
                    disabled={currentHint === challenge.hints.length - 1}
                  >
                    Next Hint
                  </Button>
                </div>
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">
                No hints available for this challenge.
              </p>
            )}
          </TabsContent>

          <TabsContent value="results" className="space-y-4">
            {testResults.length > 0 ? (
              <div className="space-y-2">
                <h3 className="font-medium">Test Results:</h3>
                <div className="space-y-1">
                  {testResults.map((result, index) => (
                    <div
                      key={index}
                      className={`p-2 rounded text-sm font-mono ${
                        result.includes("✓")
                          ? "bg-green-50 text-green-800"
                          : "bg-red-50 text-red-800"
                      }`}
                    >
                      Test Case {index + 1}: {result}
                    </div>
                  ))}
                </div>
                <div className="mt-4 p-3 bg-gray-50 rounded">
                  <p className="text-sm">
                    <strong>Score:</strong> {testResults.filter(r => r.includes("✓")).length}/{testResults.length} tests passed
                  </p>
                </div>
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">
                Run your code to see test results here.
              </p>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}