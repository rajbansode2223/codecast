import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Eye, ThumbsUp, Calendar, Clock, Video as VideoIcon } from "lucide-react";
import type { VideoWithCreator } from "@shared/schema";

interface VideoCardProps {
  video: VideoWithCreator;
}

export function VideoCard({ video }: VideoCardProps) {
  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDate = (date: string | Date) => {
    const now = new Date();
    const videoDate = new Date(date);
    const diffTime = Math.abs(now.getTime() - videoDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return "1 day ago";
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.ceil(diffDays / 7)} week${Math.ceil(diffDays / 7) > 1 ? 's' : ''} ago`;
    if (diffDays < 365) return `${Math.ceil(diffDays / 30)} month${Math.ceil(diffDays / 30) > 1 ? 's' : ''} ago`;
    return `${Math.ceil(diffDays / 365)} year${Math.ceil(diffDays / 365) > 1 ? 's' : ''} ago`;
  };

  const getDifficultyClass = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case 'beginner':
        return 'difficulty-beginner';
      case 'intermediate':
        return 'difficulty-intermediate';
      case 'advanced':
        return 'difficulty-advanced';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getCategoryClass = (category: string) => {
    const categoryLower = category.toLowerCase().replace(/\s+/g, '-');
    return `category-${categoryLower}`;
  };

  return (
    <Link href={`/video/${video.id}`}>
      <Card className="bg-card hover:bg-card/80 transition-all duration-200 cursor-pointer group border-border hover:border-primary/50 animate-fade-in">
        <div className="relative overflow-hidden rounded-t-lg">
          {/* Thumbnail */}
          <div className="aspect-video bg-muted flex items-center justify-center relative">
            {video.thumbnailUrl ? (
              <img 
                src={video.thumbnailUrl} 
                alt={video.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="flex items-center justify-center w-full h-full bg-gradient-to-br from-muted to-muted-foreground/20">
                <VideoIcon className="w-12 h-12 text-muted-foreground/50" />
              </div>
            )}
            
            {/* Duration Badge */}
            {video.duration && (
              <div className="absolute bottom-2 right-2 bg-black/75 text-white px-2 py-1 rounded text-sm font-medium">
                {formatDuration(video.duration)}
              </div>
            )}
            
            {/* Difficulty Badge */}
            <div className="absolute top-2 left-2">
              <Badge className={`${getDifficultyClass(video.difficulty)} border`}>
                {video.difficulty}
              </Badge>
            </div>

            {/* Hover Play Overlay */}
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-200 flex items-center justify-center">
              <div className="w-12 h-12 rounded-full bg-primary/0 group-hover:bg-primary/90 flex items-center justify-center transition-all duration-200 transform scale-0 group-hover:scale-100">
                <div className="w-0 h-0 border-l-6 border-l-white border-y-4 border-y-transparent ml-1"></div>
              </div>
            </div>
          </div>
        </div>
        
        <CardContent className="p-4">
          {/* Title */}
          <h3 className="font-semibold text-foreground mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {video.title}
          </h3>
          
          {/* Creator Info */}
          <div className="flex items-center mb-3">
            <Avatar className="w-6 h-6 mr-2">
              <AvatarImage src={video.creator.profileImageUrl || undefined} />
              <AvatarFallback className="text-xs">
                {video.creator.firstName?.[0] || video.creator.email?.[0] || 'U'}
              </AvatarFallback>
            </Avatar>
            <span className="text-muted-foreground text-sm truncate">
              {video.creator.firstName && video.creator.lastName 
                ? `${video.creator.firstName} ${video.creator.lastName}`
                : video.creator.email
              }
            </span>
          </div>
          
          {/* Tags */}
          {video.tags && video.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-3">
              {video.tags.slice(0, 3).map((tag, index) => (
                <Badge key={index} variant="secondary" className="text-xs px-2 py-1">
                  {tag}
                </Badge>
              ))}
              {video.tags.length > 3 && (
                <Badge variant="secondary" className="text-xs px-2 py-1">
                  +{video.tags.length - 3}
                </Badge>
              )}
            </div>
          )}
          
          {/* Stats */}
          <div className="flex items-center justify-between text-muted-foreground text-sm">
            <div className="flex items-center space-x-4">
              <span className="flex items-center">
                <Eye className="w-4 h-4 mr-1" />
                {video.views >= 1000 
                  ? `${(video.views / 1000).toFixed(1)}K`
                  : video.views.toString()
                }
              </span>
              <span className="flex items-center">
                <ThumbsUp className="w-4 h-4 mr-1" />
                {video.likes}
              </span>
            </div>
            <span className="flex items-center">
              <Calendar className="w-4 h-4 mr-1" />
              {formatDate(video.createdAt!)}
            </span>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
