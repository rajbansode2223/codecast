import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { 
  Radio,
  Eye,
  Heart,
  MessageCircle,
  Share2,
  Settings,
  Maximize,
  Volume2,
  VolumeX,
  Pause,
  Play,
  Users,
  Code,
  Bookmark,
  ThumbsUp,
  Gift,
  Star
} from "lucide-react";

interface LiveStreamPlayerProps {
  streamId: string;
  streamTitle: string;
  streamerName: string;
  category: string;
  isLive: boolean;
  viewerCount: number;
  onInteraction?: (type: string, data: any) => void;
}

interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: Date;
  type: 'message' | 'system' | 'highlight' | 'donation';
  amount?: number;
}

interface CodeSnippet {
  id: string;
  code: string;
  language: string;
  timestamp: Date;
  likes: number;
}

export function LiveStreamPlayer({ 
  streamId, 
  streamTitle, 
  streamerName, 
  category, 
  isLive, 
  viewerCount,
  onInteraction 
}: LiveStreamPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [codeSnippets, setCodeSnippets] = useState<CodeSnippet[]>([]);
  const [activeTab, setActiveTab] = useState<'chat' | 'code' | 'notes'>('chat');
  const [isFollowing, setIsFollowing] = useState(false);
  const [hasLiked, setHasLiked] = useState(false);
  const [notes, setNotes] = useState("");
  const videoRef = useRef<HTMLDivElement>(null);
  const chatRef = useRef<HTMLDivElement>(null);

  // Mock live chat simulation
  useEffect(() => {
    if (!isLive) return;

    const interval = setInterval(() => {
      const mockMessages = [
        "Great explanation of React hooks!",
        "Can you show the performance optimization part again?",
        "This is exactly what I needed to learn",
        "Could you explain the difference between useMemo and useCallback?",
        "Thanks for the live coding session!",
        "How do you handle error boundaries in this setup?",
        "Amazing! Just got my first job thanks to your tutorials",
        "Can we see the network tab to check the API calls?"
      ];

      const mockUsernames = [
        "dev_sarah", "code_ninja", "react_lover", "js_wizard", "frontend_dev",
        "backend_pro", "fullstack_hero", "tech_enthusiast", "coding_student"
      ];

      const randomMessage = mockMessages[Math.floor(Math.random() * mockMessages.length)];
      const randomUsername = mockUsernames[Math.floor(Math.random() * mockUsernames.length)];

      const newMsg: ChatMessage = {
        id: Date.now().toString(),
        username: randomUsername,
        message: randomMessage,
        timestamp: new Date(),
        type: Math.random() > 0.9 ? 'highlight' : 'message'
      };

      setChatMessages(prev => [...prev.slice(-49), newMsg]);
    }, 3000 + Math.random() * 4000);

    return () => clearInterval(interval);
  }, [isLive]);

  // Auto-scroll chat
  useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [chatMessages]);

  const sendMessage = () => {
    if (!newMessage.trim()) return;

    const message: ChatMessage = {
      id: Date.now().toString(),
      username: "You",
      message: newMessage,
      timestamp: new Date(),
      type: 'message'
    };

    setChatMessages(prev => [...prev.slice(-49), message]);
    setNewMessage("");
    onInteraction?.('chat_message', { message: newMessage });
  };

  const toggleLike = () => {
    setHasLiked(!hasLiked);
    onInteraction?.('like', { liked: !hasLiked });
  };

  const toggleFollow = () => {
    setIsFollowing(!isFollowing);
    onInteraction?.('follow', { following: !isFollowing });
  };

  const saveCodeSnippet = () => {
    // Simulate capturing current code being shown
    const snippet: CodeSnippet = {
      id: Date.now().toString(),
      code: `// Code snippet from live stream
function useCustomHook(initialValue) {
  const [value, setValue] = useState(initialValue);
  
  const increment = useCallback(() => {
    setValue(prev => prev + 1);
  }, []);
  
  return { value, increment };
}`,
      language: 'javascript',
      timestamp: new Date(),
      likes: 0
    };

    setCodeSnippets(prev => [snippet, ...prev]);
    onInteraction?.('save_code', snippet);
  };

  const formatTimestamp = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="space-y-4">
      {/* Stream Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10">
            <AvatarFallback>{streamerName.split(' ').map(n => n[0]).join('')}</AvatarFallback>
          </Avatar>
          <div>
            <h2 className="text-xl font-bold">{streamTitle}</h2>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <span>{streamerName}</span>
              <Badge variant="secondary">{category}</Badge>
              {isLive && (
                <Badge className="bg-red-600 text-white">
                  <Radio className="h-3 w-3 mr-1" />
                  LIVE
                </Badge>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 text-sm text-gray-600">
            <Eye className="h-4 w-4" />
            <span>{viewerCount.toLocaleString()}</span>
          </div>
          <Button
            variant={isFollowing ? "default" : "outline"}
            size="sm"
            onClick={toggleFollow}
          >
            {isFollowing ? "Following" : "Follow"}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Video Player */}
        <div className="lg:col-span-3">
          <Card>
            <CardContent className="p-0">
              <div 
                ref={videoRef}
                className="relative bg-black aspect-video rounded-t-lg overflow-hidden"
              >
                {/* Mock video player */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center">
                  <div className="text-center text-white">
                    <Code className="h-16 w-16 mx-auto mb-4 opacity-50" />
                    <p className="text-lg font-semibold">Live Coding Stream</p>
                    <p className="text-sm opacity-75">Building a React Dashboard</p>
                  </div>
                </div>

                {/* Video Controls Overlay */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setIsPlaying(!isPlaying)}
                        className="text-white hover:bg-white/20"
                      >
                        {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setIsMuted(!isMuted)}
                        className="text-white hover:bg-white/20"
                      >
                        {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                      </Button>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={toggleLike}
                        className={`text-white hover:bg-white/20 ${hasLiked ? 'text-red-400' : ''}`}
                      >
                        <Heart className={`h-5 w-5 ${hasLiked ? 'fill-current' : ''}`} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={saveCodeSnippet}
                        className="text-white hover:bg-white/20"
                      >
                        <Bookmark className="h-5 w-5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-white hover:bg-white/20"
                      >
                        <Share2 className="h-5 w-5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setIsFullscreen(!isFullscreen)}
                        className="text-white hover:bg-white/20"
                      >
                        <Maximize className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stream Actions */}
              <div className="p-4 border-t">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Button variant="outline" size="sm" onClick={saveCodeSnippet}>
                      <Code className="h-4 w-4 mr-2" />
                      Save Code
                    </Button>
                    <Button variant="outline" size="sm">
                      <Gift className="h-4 w-4 mr-2" />
                      Support
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <ThumbsUp className="h-4 w-4" />
                    <span>98% positive feedback</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Interactive Sidebar */}
        <div className="space-y-4">
          {/* Tab Navigation */}
          <div className="flex border-b">
            {[
              { id: 'chat', label: 'Chat', icon: MessageCircle },
              { id: 'code', label: 'Code', icon: Code },
              { id: 'notes', label: 'Notes', icon: Bookmark }
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id as any)}
                className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <Icon className="h-4 w-4" />
                {label}
              </button>
            ))}
          </div>

          {/* Chat Tab */}
          {activeTab === 'chat' && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Live Chat ({chatMessages.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div 
                  ref={chatRef}
                  className="h-80 overflow-y-auto space-y-2 p-2 bg-gray-50 rounded-md"
                >
                  {chatMessages.map((msg) => (
                    <div key={msg.id} className={`text-sm ${
                      msg.type === 'highlight' ? 'bg-yellow-100 p-2 rounded' : ''
                    }`}>
                      <div className="flex items-start gap-2">
                        <span className={`font-medium ${
                          msg.username === 'You' ? 'text-blue-600' : 'text-gray-900'
                        }`}>
                          {msg.username}:
                        </span>
                        <span className="text-gray-700 flex-1">{msg.message}</span>
                        <span className="text-xs text-gray-500">
                          {formatTimestamp(msg.timestamp)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="flex gap-2">
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                    className="flex-1"
                  />
                  <Button onClick={sendMessage} size="sm">
                    Send
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Code Snippets Tab */}
          {activeTab === 'code' && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Saved Code Snippets</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {codeSnippets.length === 0 ? (
                    <p className="text-sm text-gray-500 text-center py-8">
                      No code snippets saved yet. Click "Save Code" during the stream!
                    </p>
                  ) : (
                    codeSnippets.map((snippet) => (
                      <div key={snippet.id} className="border rounded-md p-3">
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant="outline">{snippet.language}</Badge>
                          <span className="text-xs text-gray-500">
                            {formatTimestamp(snippet.timestamp)}
                          </span>
                        </div>
                        <pre className="text-xs bg-gray-100 p-2 rounded overflow-x-auto">
                          <code>{snippet.code}</code>
                        </pre>
                        <div className="flex items-center justify-between mt-2">
                          <Button variant="ghost" size="sm">
                            <ThumbsUp className="h-3 w-3 mr-1" />
                            {snippet.likes}
                          </Button>
                          <Button variant="ghost" size="sm">
                            Copy
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Notes Tab */}
          {activeTab === 'notes' && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Stream Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Take notes during the stream..."
                  className="min-h-[300px] resize-none"
                />
                <Button className="w-full mt-3" size="sm">
                  Save Notes
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}