import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Users, 
  Video, 
  Mic, 
  MicOff, 
  VideoOff, 
  Share, 
  Code, 
  Play,
  Terminal,
  MessageSquare,
  Settings,
  Crown,
  Radio
} from "lucide-react";

interface Participant {
  id: string;
  name: string;
  avatar?: string;
  role: 'host' | 'participant';
  isVideoOn: boolean;
  isAudioOn: boolean;
  cursor?: { x: number; y: number };
}

interface LiveCollaborationProps {
  videoId: number;
  isHost?: boolean;
  onJoinSession?: (sessionId: string) => void;
}

export function LiveCollaboration({ videoId, isHost = false, onJoinSession }: LiveCollaborationProps) {
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [code, setCode] = useState(`// Welcome to Live Collaboration!
// Multiple developers can code together in real-time

function fibonacci(n) {
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

console.log(fibonacci(10));`);
  const [chatMessages, setChatMessages] = useState<Array<{id: string, user: string, message: string, timestamp: Date}>>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isVideoOn, setIsVideoOn] = useState(false);
  const [isAudioOn, setIsAudioOn] = useState(false);
  const [executionOutput, setExecutionOutput] = useState("");
  const [isExecuting, setIsExecuting] = useState(false);
  const codeEditorRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (isSessionActive) {
      // Simulate participants joining
      const mockParticipants: Participant[] = [
        {
          id: "host",
          name: "Sarah Chen",
          avatar: "/api/placeholder/32/32",
          role: "host",
          isVideoOn: true,
          isAudioOn: true
        },
        {
          id: "p1",
          name: "Alex Rodriguez",
          avatar: "/api/placeholder/32/32",
          role: "participant",
          isVideoOn: false,
          isAudioOn: true
        },
        {
          id: "p2",
          name: "Jamie Park",
          avatar: "/api/placeholder/32/32",
          role: "participant",
          isVideoOn: true,
          isAudioOn: false
        }
      ];
      setParticipants(mockParticipants);
    }
  }, [isSessionActive]);

  const startSession = () => {
    setIsSessionActive(true);
    onJoinSession?.("session-123");
  };

  const endSession = () => {
    setIsSessionActive(false);
    setParticipants([]);
  };

  const executeCode = async () => {
    setIsExecuting(true);
    // Simulate code execution
    setTimeout(() => {
      setExecutionOutput(`> Running JavaScript code...
55
> Execution completed in 0.23ms`);
      setIsExecuting(false);
    }, 1500);
  };

  const sendMessage = () => {
    if (!newMessage.trim()) return;
    
    const message = {
      id: Date.now().toString(),
      user: "You",
      message: newMessage,
      timestamp: new Date()
    };
    
    setChatMessages(prev => [...prev, message]);
    setNewMessage("");
  };

  const handleCodeChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setCode(e.target.value);
    // In a real implementation, this would sync with other participants via WebSocket
  };

  return (
    <div className="space-y-6">
      {/* Session Control */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-blue-600" />
            Live Collaboration Session
            {isSessionActive && <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              <Radio className="h-3 w-3 mr-1" />
              Live
            </Badge>}
          </CardTitle>
          <CardDescription>
            Code together in real-time with voice, video, and screen sharing
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!isSessionActive ? (
            <div className="text-center py-8">
              <div className="mb-4">
                <Code className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-600">Start a live coding session to collaborate with others</p>
              </div>
              <Button onClick={startSession} className="mr-2">
                <Users className="h-4 w-4 mr-2" />
                {isHost ? 'Start Session' : 'Join Session'}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Participants */}
              <div className="flex items-center justify-between">
                <div className="flex -space-x-2">
                  {participants.map((participant) => (
                    <div key={participant.id} className="relative">
                      <Avatar className="border-2 border-white">
                        <AvatarImage src={participant.avatar} />
                        <AvatarFallback>{participant.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      {participant.role === 'host' && (
                        <Crown className="h-3 w-3 text-yellow-500 absolute -top-1 -right-1" />
                      )}
                    </div>
                  ))}
                </div>
                
                {/* Media Controls */}
                <div className="flex items-center gap-2">
                  <Button
                    variant={isAudioOn ? "default" : "outline"}
                    size="sm"
                    onClick={() => setIsAudioOn(!isAudioOn)}
                  >
                    {isAudioOn ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
                  </Button>
                  <Button
                    variant={isVideoOn ? "default" : "outline"}
                    size="sm"
                    onClick={() => setIsVideoOn(!isVideoOn)}
                  >
                    {isVideoOn ? <Video className="h-4 w-4" /> : <VideoOff className="h-4 w-4" />}
                  </Button>
                  <Button variant="outline" size="sm">
                    <Share className="h-4 w-4" />
                  </Button>
                  <Button variant="destructive" size="sm" onClick={endSession}>
                    End
                  </Button>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {isSessionActive && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Code Editor */}
          <div className="lg:col-span-2 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Code className="h-4 w-4" />
                    Shared Code Editor
                  </span>
                  <Button onClick={executeCode} disabled={isExecuting} size="sm">
                    <Play className="h-4 w-4 mr-2" />
                    {isExecuting ? 'Running...' : 'Run Code'}
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <textarea
                  ref={codeEditorRef}
                  value={code}
                  onChange={handleCodeChange}
                  className="w-full h-80 p-4 font-mono text-sm border rounded-md resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Write your code here..."
                />
                
                {/* Live Cursors */}
                <div className="mt-2 flex items-center gap-2 text-xs text-gray-500">
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>Alex is typing...</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span>Jamie is at line 8</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Execution Output */}
            {executionOutput && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Terminal className="h-4 w-4" />
                    Output
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="bg-gray-900 text-green-400 p-4 rounded-md text-sm font-mono whitespace-pre-wrap">
                    {executionOutput}
                  </pre>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Chat & Participants */}
          <div className="space-y-4">
            {/* Participants Detail */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Participants ({participants.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {participants.map((participant) => (
                    <div key={participant.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={participant.avatar} />
                          <AvatarFallback className="text-xs">
                            {participant.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium">{participant.name}</p>
                          <p className="text-xs text-gray-500 capitalize">{participant.role}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        {participant.isAudioOn ? (
                          <Mic className="h-3 w-3 text-green-500" />
                        ) : (
                          <MicOff className="h-3 w-3 text-gray-400" />
                        )}
                        {participant.isVideoOn ? (
                          <Video className="h-3 w-3 text-green-500" />
                        ) : (
                          <VideoOff className="h-3 w-3 text-gray-400" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Live Chat */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Live Chat
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="h-40 overflow-y-auto space-y-2 border rounded-md p-2">
                    {chatMessages.length === 0 ? (
                      <p className="text-sm text-gray-500 text-center">No messages yet</p>
                    ) : (
                      chatMessages.map((msg) => (
                        <div key={msg.id} className="text-sm">
                          <span className="font-medium text-blue-600">{msg.user}:</span>
                          <span className="ml-2">{msg.message}</span>
                        </div>
                      ))
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Type a message..."
                      onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                      className="flex-1"
                    />
                    <Button onClick={sendMessage} size="sm">
                      Send
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}