import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Trophy, 
  Medal, 
  Award, 
  TrendingUp, 
  Star, 
  Crown,
  Code,
  Database,
  Globe,
  Smartphone,
  Brain,
  Shield,
  Zap,
  Users
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

interface SkillData {
  id: string;
  name: string;
  category: string;
  icon: any;
  totalLearners: number;
  averageProgress: number;
  trending: boolean;
}

interface LeaderboardUser {
  id: string;
  name: string;
  avatar?: string;
  rank: number;
  score: number;
  skillLevel: string;
  completedCourses: number;
  streak: number;
  badges: string[];
  isCurrentUser?: boolean;
}

interface SkillLeaderboardProps {
  selectedSkill?: string;
}

export function SkillLeaderboard({ selectedSkill }: SkillLeaderboardProps) {
  const { user, isAuthenticated } = useAuth();
  const [activeSkill, setActiveSkill] = useState<string>("javascript");
  const [timeframe, setTimeframe] = useState<"week" | "month" | "allTime">("month");
  const [skills, setSkills] = useState<SkillData[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([]);

  // Initialize skills data
  useEffect(() => {
    const skillsData: SkillData[] = [
      {
        id: "javascript",
        name: "JavaScript",
        category: "Frontend",
        icon: Code,
        totalLearners: 15420,
        averageProgress: 68,
        trending: true
      },
      {
        id: "react",
        name: "React",
        category: "Frontend",
        icon: Globe,
        totalLearners: 12850,
        averageProgress: 72,
        trending: true
      },
      {
        id: "nodejs",
        name: "Node.js",
        category: "Backend",
        icon: Database,
        totalLearners: 9640,
        averageProgress: 65,
        trending: false
      },
      {
        id: "python",
        name: "Python",
        category: "Backend",
        icon: Code,
        totalLearners: 18750,
        averageProgress: 71,
        trending: true
      },
      {
        id: "flutter",
        name: "Flutter",
        category: "Mobile",
        icon: Smartphone,
        totalLearners: 6830,
        averageProgress: 59,
        trending: true
      },
      {
        id: "machine-learning",
        name: "Machine Learning",
        category: "AI/ML",
        icon: Brain,
        totalLearners: 11240,
        averageProgress: 54,
        trending: true
      },
      {
        id: "cybersecurity",
        name: "Cybersecurity",
        category: "Security",
        icon: Shield,
        totalLearners: 7950,
        averageProgress: 61,
        trending: false
      },
      {
        id: "devops",
        name: "DevOps",
        category: "Infrastructure",
        icon: Zap,
        totalLearners: 8430,
        averageProgress: 63,
        trending: false
      }
    ];

    setSkills(skillsData);
    if (selectedSkill) {
      setActiveSkill(selectedSkill);
    }
  }, [selectedSkill]);

  // Generate leaderboard data
  useEffect(() => {
    const generateLeaderboard = (skillId: string) => {
      const baseUsers = [
        {
          name: "CodeMaster_Alex",
          avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face",
          skillLevel: "Expert",
          badges: ["100 Day Streak", "Course Creator", "Top Contributor"]
        },
        {
          name: "DevNinja_Sarah",
          avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b691?w=40&h=40&fit=crop&crop=face",
          skillLevel: "Advanced",
          badges: ["Fast Learner", "Project Master", "Community Helper"]
        },
        {
          name: "TechGuru_Mike",
          avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face",
          skillLevel: "Expert",
          badges: ["Mentor", "Bug Hunter", "Innovation Leader"]
        },
        {
          name: "JSExpert_Emma",
          avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face",
          skillLevel: "Advanced",
          badges: ["Code Reviewer", "Open Source", "Team Player"]
        },
        {
          name: "FullStack_Tom",
          avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face",
          skillLevel: "Intermediate",
          badges: ["Rising Star", "Quick Study", "Problem Solver"]
        },
        {
          name: "ReactPro_Lisa",
          avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=40&h=40&fit=crop&crop=face",
          skillLevel: "Advanced",
          badges: ["Component Master", "Performance Pro", "UI Expert"]
        },
        {
          name: "BackendDev_John",
          avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=40&h=40&fit=crop&crop=face",
          skillLevel: "Advanced",
          badges: ["API Designer", "Database Pro", "System Architect"]
        },
        {
          name: "MLEngineer_Anna",
          avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=40&h=40&fit=crop&crop=face",
          skillLevel: "Expert",
          badges: ["Data Scientist", "Model Builder", "Research Lead"]
        },
        {
          name: "MobileDev_Chris",
          avatar: "https://images.unsplash.com/photo-1507591064344-4c6ce005b128?w=40&h=40&fit=crop&crop=face",
          skillLevel: "Intermediate",
          badges: ["App Store Star", "Cross Platform", "UX Focus"]
        },
        {
          name: "SecExpert_Maya",
          avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=40&h=40&fit=crop&crop=face",
          skillLevel: "Expert",
          badges: ["Ethical Hacker", "Security Audit", "Threat Hunter"]
        }
      ];

      const leaderboardData: LeaderboardUser[] = baseUsers.map((user, index) => ({
        id: `user_${index + 1}`,
        name: user.name,
        avatar: user.avatar,
        rank: index + 1,
        score: Math.floor(Math.random() * 2000) + 8000 - (index * 200),
        skillLevel: user.skillLevel,
        completedCourses: Math.floor(Math.random() * 15) + 5 + (10 - index),
        streak: Math.floor(Math.random() * 90) + 10 + (30 - index * 3),
        badges: user.badges,
        isCurrentUser: false
      }));

      // Add current user to leaderboard if authenticated
      if (isAuthenticated && user) {
        const currentUserData: LeaderboardUser = {
          id: user.id || "current_user",
          name: user.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : "You",
          avatar: user.profileImageUrl,
          rank: Math.floor(Math.random() * 50) + 15,
          score: Math.floor(Math.random() * 1500) + 3000,
          skillLevel: "Intermediate",
          completedCourses: Math.floor(Math.random() * 8) + 3,
          streak: Math.floor(Math.random() * 30) + 5,
          badges: ["First Course", "Week Warrior", "Knowledge Seeker"],
          isCurrentUser: true
        };

        leaderboardData.push(currentUserData);
        leaderboardData.sort((a, b) => b.score - a.score);
        
        // Update ranks after sorting
        leaderboardData.forEach((user, index) => {
          user.rank = index + 1;
        });
      }

      return leaderboardData;
    };

    setLeaderboard(generateLeaderboard(activeSkill));
  }, [activeSkill, timeframe, isAuthenticated, user]);

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="h-5 w-5 text-yellow-500" />;
    if (rank === 2) return <Medal className="h-5 w-5 text-gray-400" />;
    if (rank === 3) return <Award className="h-5 w-5 text-amber-600" />;
    return <span className="w-5 text-center font-bold text-muted-foreground">{rank}</span>;
  };

  const getSkillLevelColor = (level: string) => {
    switch (level.toLowerCase()) {
      case "expert": return "bg-purple-500";
      case "advanced": return "bg-blue-500";
      case "intermediate": return "bg-green-500";
      case "beginner": return "bg-orange-500";
      default: return "bg-gray-500";
    }
  };

  const activeSkillData = skills.find(s => s.id === activeSkill);
  const currentUser = leaderboard.find(u => u.isCurrentUser);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Trophy className="h-6 w-6 text-yellow-500" />
          <h2 className="text-2xl font-bold">Skill Leaderboards</h2>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant={timeframe === "week" ? "default" : "outline"}
            size="sm"
            onClick={() => setTimeframe("week")}
          >
            Week
          </Button>
          <Button
            variant={timeframe === "month" ? "default" : "outline"}
            size="sm"
            onClick={() => setTimeframe("month")}
          >
            Month
          </Button>
          <Button
            variant={timeframe === "allTime" ? "default" : "outline"}
            size="sm"
            onClick={() => setTimeframe("allTime")}
          >
            All Time
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Skills List */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Skills</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {skills.map((skill) => {
              const Icon = skill.icon;
              return (
                <Button
                  key={skill.id}
                  variant={activeSkill === skill.id ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setActiveSkill(skill.id)}
                >
                  <Icon className="h-4 w-4 mr-2" />
                  <span className="flex-1 text-left">{skill.name}</span>
                  {skill.trending && (
                    <TrendingUp className="h-3 w-3 text-green-500" />
                  )}
                </Button>
              );
            })}
          </CardContent>
        </Card>

        {/* Main Content */}
        <div className="lg:col-span-3 space-y-6">
          {/* Skill Overview */}
          {activeSkillData && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <activeSkillData.icon className="h-8 w-8" />
                    <div>
                      <CardTitle className="text-xl">{activeSkillData.name}</CardTitle>
                      <p className="text-muted-foreground">{activeSkillData.category}</p>
                    </div>
                  </div>
                  {activeSkillData.trending && (
                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      Trending
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span className="text-2xl font-bold">{activeSkillData.totalLearners.toLocaleString()}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">Total Learners</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold mb-2">{activeSkillData.averageProgress}%</div>
                    <p className="text-sm text-muted-foreground">Average Progress</p>
                    <Progress value={activeSkillData.averageProgress} className="mt-2" />
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold mb-2">{leaderboard.length}</div>
                    <p className="text-sm text-muted-foreground">Active This {timeframe === "week" ? "Week" : timeframe === "month" ? "Month" : "Year"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Current User Stats */}
          {currentUser && (
            <Card className="border-primary/20 bg-primary/5">
              <CardHeader>
                <CardTitle className="text-lg">Your Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-3">
                    {getRankIcon(currentUser.rank)}
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={currentUser.avatar} />
                      <AvatarFallback>{currentUser.name[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{currentUser.name}</p>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className={`${getSkillLevelColor(currentUser.skillLevel)} text-white`}>
                          {currentUser.skillLevel}
                        </Badge>
                        <span className="text-sm text-muted-foreground">Rank #{currentUser.rank}</span>
                      </div>
                    </div>
                  </div>
                  <div className="ml-auto text-right">
                    <div className="text-xl font-bold">{currentUser.score.toLocaleString()}</div>
                    <div className="text-sm text-muted-foreground">points</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Leaderboard */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                Top Learners - {activeSkillData?.name} ({timeframe === "week" ? "This Week" : timeframe === "month" ? "This Month" : "All Time"})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {leaderboard.slice(0, 10).map((user) => (
                  <div
                    key={user.id}
                    className={`flex items-center gap-4 p-3 rounded-lg transition-colors ${
                      user.isCurrentUser 
                        ? 'bg-primary/10 border border-primary/20' 
                        : 'hover:bg-muted/50'
                    }`}
                  >
                    <div className="flex items-center gap-3 flex-1">
                      {getRankIcon(user.rank)}
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={user.avatar} />
                        <AvatarFallback>{user.name[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-medium truncate">{user.name}</p>
                          {user.isCurrentUser && (
                            <Badge variant="secondary" className="text-xs">You</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge 
                            variant="outline" 
                            className={`text-xs ${getSkillLevelColor(user.skillLevel)} text-white`}
                          >
                            {user.skillLevel}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {user.completedCourses} courses • {user.streak} day streak
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {user.badges.slice(0, 2).map((badge, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {badge}
                            </Badge>
                          ))}
                          {user.badges.length > 2 && (
                            <Badge variant="secondary" className="text-xs">
                              +{user.badges.length - 2} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold">{user.score.toLocaleString()}</div>
                      <div className="text-xs text-muted-foreground">points</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}