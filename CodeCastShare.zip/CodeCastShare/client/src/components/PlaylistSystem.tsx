import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  PlayCircle, 
  Plus, 
  List, 
  Clock, 
  Users, 
  BookOpen, 
  Trash2, 
  Edit, 
  Share,
  Star,
  Play,
  MoreHorizontal,
  GripVertical
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "wouter";

interface PlaylistVideo {
  id: number;
  title: string;
  duration: number;
  thumbnail: string;
  creator: string;
  views: number;
  addedAt: Date;
  position: number;
}

interface Playlist {
  id: string;
  name: string;
  description: string;
  visibility: "public" | "private" | "unlisted";
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
  videos: PlaylistVideo[];
  totalDuration: number;
  followers: number;
  category: string;
  tags: string[];
}

interface PlaylistSystemProps {
  currentVideoId?: number;
  onVideoSelect?: (videoId: number) => void;
}

export function PlaylistSystem({ currentVideoId, onVideoSelect }: PlaylistSystemProps) {
  const { user, isAuthenticated } = useAuth();
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [selectedPlaylist, setSelectedPlaylist] = useState<string | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newPlaylist, setNewPlaylist] = useState({
    name: "",
    description: "",
    visibility: "public" as const,
    category: "",
    tags: [] as string[]
  });

  // Sample playlists data
  useEffect(() => {
    const samplePlaylists: Playlist[] = [
      {
        id: "1",
        name: "My Stack Journey",
        description: "Complete path from beginner to full-stack developer",
        visibility: "public",
        createdBy: user?.firstName || "You",
        createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        updatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        totalDuration: 18420, // seconds
        followers: 1247,
        category: "Web Development",
        tags: ["JavaScript", "React", "Node.js", "Full-Stack"],
        videos: [
          {
            id: 1,
            title: "JavaScript Fundamentals for Beginners",
            duration: 3600,
            thumbnail: "https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=160&h=90&fit=crop",
            creator: "CodeMaster",
            views: 45230,
            addedAt: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000),
            position: 1
          },
          {
            id: 2,
            title: "React Components and Props Deep Dive",
            duration: 4200,
            thumbnail: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=160&h=90&fit=crop",
            creator: "ReactGuru",
            views: 32100,
            addedAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
            position: 2
          },
          {
            id: 3,
            title: "Building REST APIs with Node.js and Express",
            duration: 5400,
            thumbnail: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=160&h=90&fit=crop",
            creator: "BackendDev",
            views: 28750,
            addedAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
            position: 3
          },
          {
            id: 4,
            title: "Database Design and MongoDB Essentials",
            duration: 4620,
            thumbnail: "https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=160&h=90&fit=crop",
            creator: "DataExpert",
            views: 19800,
            addedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
            position: 4
          },
          {
            id: 5,
            title: "Full-Stack Project: E-commerce Platform",
            duration: 600,
            thumbnail: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=160&h=90&fit=crop",
            creator: "ProjectPro",
            views: 15600,
            addedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
            position: 5
          }
        ]
      },
      {
        id: "2",
        name: "Backend Deep Dive",
        description: "Advanced backend development concepts and architectures",
        visibility: "public",
        createdBy: user?.firstName || "You",
        createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
        updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        totalDuration: 14280,
        followers: 892,
        category: "Backend",
        tags: ["Node.js", "Python", "Microservices", "Docker"],
        videos: [
          {
            id: 6,
            title: "Microservices Architecture Patterns",
            duration: 4800,
            thumbnail: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=160&h=90&fit=crop",
            creator: "ArchitectPro",
            views: 22100,
            addedAt: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000),
            position: 1
          },
          {
            id: 7,
            title: "Docker Containerization Masterclass",
            duration: 5280,
            thumbnail: "https://images.unsplash.com/photo-1605745341112-85968b19335a?w=160&h=90&fit=crop",
            creator: "DevOpsGuru",
            views: 18700,
            addedAt: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
            position: 2
          },
          {
            id: 8,
            title: "API Security Best Practices",
            duration: 4200,
            thumbnail: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=160&h=90&fit=crop",
            creator: "SecurityExpert",
            views: 16200,
            addedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
            position: 3
          }
        ]
      },
      {
        id: "3",
        name: "AI/ML Fundamentals",
        description: "Journey into artificial intelligence and machine learning",
        visibility: "public",
        createdBy: "MLExpert_Sarah",
        createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
        updatedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        totalDuration: 21600,
        followers: 2156,
        category: "AI/ML",
        tags: ["Python", "TensorFlow", "Neural Networks", "Data Science"],
        videos: [
          {
            id: 9,
            title: "Introduction to Machine Learning",
            duration: 3900,
            thumbnail: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=160&h=90&fit=crop",
            creator: "MLExpert_Sarah",
            views: 34500,
            addedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
            position: 1
          },
          {
            id: 10,
            title: "Neural Networks from Scratch",
            duration: 6300,
            thumbnail: "https://images.unsplash.com/photo-1507146426996-ef05306b995a?w=160&h=90&fit=crop",
            creator: "MLExpert_Sarah",
            views: 28900,
            addedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
            position: 2
          },
          {
            id: 11,
            title: "Deep Learning with TensorFlow",
            duration: 7200,
            thumbnail: "https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=160&h=90&fit=crop",
            creator: "MLExpert_Sarah",
            views: 25400,
            addedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
            position: 3
          },
          {
            id: 12,
            title: "Computer Vision Applications",
            duration: 4200,
            thumbnail: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=160&h=90&fit=crop",
            creator: "MLExpert_Sarah",
            views: 19800,
            addedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
            position: 4
          }
        ]
      }
    ];

    setPlaylists(samplePlaylists);
    setSelectedPlaylist(samplePlaylists[0].id);
  }, [user?.firstName]);

  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  const createPlaylist = () => {
    if (!newPlaylist.name.trim()) return;

    const playlist: Playlist = {
      id: Date.now().toString(),
      name: newPlaylist.name,
      description: newPlaylist.description,
      visibility: newPlaylist.visibility,
      createdBy: user?.firstName || "You",
      createdAt: new Date(),
      updatedAt: new Date(),
      videos: [],
      totalDuration: 0,
      followers: 0,
      category: newPlaylist.category,
      tags: newPlaylist.tags
    };

    setPlaylists(prev => [playlist, ...prev]);
    setSelectedPlaylist(playlist.id);
    setIsCreateDialogOpen(false);
    setNewPlaylist({
      name: "",
      description: "",
      visibility: "public",
      category: "",
      tags: []
    });
  };

  const addCurrentVideoToPlaylist = (playlistId: string) => {
    if (!currentVideoId) return;

    // Mock video data for the current video
    const mockVideo: PlaylistVideo = {
      id: currentVideoId,
      title: "Current Video",
      duration: 1800,
      thumbnail: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=160&h=90&fit=crop",
      creator: "Current Creator",
      views: 1000,
      addedAt: new Date(),
      position: playlists.find(p => p.id === playlistId)?.videos.length || 0 + 1
    };

    setPlaylists(prev => prev.map(playlist => 
      playlist.id === playlistId
        ? {
            ...playlist,
            videos: [...playlist.videos, mockVideo],
            totalDuration: playlist.totalDuration + mockVideo.duration,
            updatedAt: new Date()
          }
        : playlist
    ));
  };

  const removeVideoFromPlaylist = (playlistId: string, videoId: number) => {
    setPlaylists(prev => prev.map(playlist => 
      playlist.id === playlistId
        ? {
            ...playlist,
            videos: playlist.videos.filter(v => v.id !== videoId),
            totalDuration: playlist.totalDuration - (playlist.videos.find(v => v.id === videoId)?.duration || 0),
            updatedAt: new Date()
          }
        : playlist
    ));
  };

  const selectedPlaylistData = playlists.find(p => p.id === selectedPlaylist);

  if (!isAuthenticated) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-lg font-semibold mb-2">Playlists</h3>
          <p className="text-muted-foreground mb-4">
            Sign in to create playlists and organize your learning journey
          </p>
          <Button asChild>
            <a href="/api/login">Sign In</a>
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Playlist Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <List className="h-6 w-6" />
          <h2 className="text-2xl font-bold">My Playlists</h2>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create Playlist
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Playlist</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input
                placeholder="Playlist name"
                value={newPlaylist.name}
                onChange={(e) => setNewPlaylist(prev => ({ ...prev, name: e.target.value }))}
              />
              <Textarea
                placeholder="Description (optional)"
                value={newPlaylist.description}
                onChange={(e) => setNewPlaylist(prev => ({ ...prev, description: e.target.value }))}
              />
              <Select value={newPlaylist.visibility} onValueChange={(value: any) => setNewPlaylist(prev => ({ ...prev, visibility: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Privacy" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="public">Public</SelectItem>
                  <SelectItem value="unlisted">Unlisted</SelectItem>
                  <SelectItem value="private">Private</SelectItem>
                </SelectContent>
              </Select>
              <Input
                placeholder="Category (e.g., Web Development)"
                value={newPlaylist.category}
                onChange={(e) => setNewPlaylist(prev => ({ ...prev, category: e.target.value }))}
              />
              <div className="flex gap-2">
                <Button onClick={createPlaylist} disabled={!newPlaylist.name.trim()}>
                  Create
                </Button>
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Playlist List */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">My Playlists ({playlists.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-3">
                  {playlists.map((playlist) => (
                    <div
                      key={playlist.id}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedPlaylist === playlist.id
                          ? 'bg-primary/10 border border-primary/20'
                          : 'hover:bg-muted/50'
                      }`}
                      onClick={() => setSelectedPlaylist(playlist.id)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-sm truncate">{playlist.name}</h4>
                          <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                            <span>{playlist.videos.length} videos</span>
                            <span>•</span>
                            <span>{formatDuration(playlist.totalDuration)}</span>
                          </div>
                          <div className="flex items-center gap-1 mt-1">
                            <Badge variant="outline" className="text-xs">
                              {playlist.visibility}
                            </Badge>
                            {playlist.followers > 0 && (
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Users className="h-3 w-3" />
                                {playlist.followers}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        {/* Selected Playlist Details */}
        <div className="lg:col-span-2">
          {selectedPlaylistData ? (
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <CardTitle className="text-xl">{selectedPlaylistData.name}</CardTitle>
                      <Badge variant="outline">{selectedPlaylistData.visibility}</Badge>
                    </div>
                    {selectedPlaylistData.description && (
                      <p className="text-muted-foreground text-sm mb-3">
                        {selectedPlaylistData.description}
                      </p>
                    )}
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <PlayCircle className="h-4 w-4" />
                        {selectedPlaylistData.videos.length} videos
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {formatDuration(selectedPlaylistData.totalDuration)}
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        {selectedPlaylistData.followers} followers
                      </div>
                    </div>
                    {selectedPlaylistData.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {selectedPlaylistData.tags.map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {currentVideoId && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => addCurrentVideoToPlaylist(selectedPlaylistData.id)}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Current Video
                      </Button>
                    )}
                    <Button variant="outline" size="sm">
                      <Share className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  {selectedPlaylistData.videos.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <PlayCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No videos in this playlist yet</p>
                      <p className="text-sm">Add videos to start building your learning path</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {selectedPlaylistData.videos.map((video, index) => (
                        <div
                          key={video.id}
                          className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors group"
                        >
                          <div className="flex items-center gap-3 flex-1 min-w-0">
                            <div className="flex items-center justify-center w-8 h-8 text-sm text-muted-foreground">
                              {index + 1}
                            </div>
                            <div className="relative">
                              <img
                                src={video.thumbnail}
                                alt={video.title}
                                className="w-20 h-11 object-cover rounded"
                              />
                              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <Button
                                  size="sm"
                                  variant="secondary"
                                  className="h-6 w-6 p-0"
                                  onClick={() => onVideoSelect?.(video.id)}
                                >
                                  <Play className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium text-sm truncate">{video.title}</h4>
                              <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                                <span>{video.creator}</span>
                                <span>•</span>
                                <span>{formatDuration(video.duration)}</span>
                                <span>•</span>
                                <span>{(video.views / 1000).toFixed(1)}K views</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0"
                              onClick={() => removeVideoFromPlaylist(selectedPlaylistData.id, video.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <List className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">Select a playlist to view its contents</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}