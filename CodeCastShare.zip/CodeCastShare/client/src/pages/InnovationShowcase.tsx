import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Navigation } from "@/components/Navigation";
import { AICodeAnalyzer } from "@/components/AICodeAnalyzer";
import { LiveCollaboration } from "@/components/LiveCollaboration";
import { MentorshipMatcher } from "@/components/MentorshipMatcher";
import { LearningAnalytics } from "@/components/LearningAnalytics";
import { LiveStreamPlayer } from "@/components/LiveStreamPlayer";
import { AIAssistant } from "@/components/AIAssistant";
import { 
  Brain, 
  Users, 
  Code, 
  BarChart3, 
  Radio, 
  Zap,
  Target,
  Award,
  Rocket,
  Star,
  TrendingUp,
  CheckCircle2
} from "lucide-react";

export default function InnovationShowcase() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeDemo, setActiveDemo] = useState<string | null>(null);

  const innovations = [
    {
      id: "ai-assistant",
      title: "AI Virtual Assistant",
      description: "Intelligent AI companion that provides real-time coding help, learning guidance, and personalized support",
      icon: Brain,
      color: "purple",
      features: [
        "Context-aware code assistance",
        "Real-time debugging help",
        "Personalized learning paths",
        "Voice interaction support",
        "24/7 intelligent guidance"
      ]
    },
    {
      id: "ai-analyzer",
      title: "AI Code Analyzer",
      description: "Revolutionary AI-powered code analysis with performance insights, security scanning, and optimization suggestions",
      icon: Code,
      color: "blue",
      features: [
        "Real-time complexity analysis",
        "Security vulnerability detection", 
        "Performance optimization suggestions",
        "Industry benchmark comparisons",
        "Maintainability scoring"
      ]
    },
    {
      id: "live-collab",
      title: "Live Collaboration",
      description: "Real-time collaborative coding with voice, video, and synchronized code editing",
      icon: Users,
      color: "blue",
      features: [
        "Multi-user code editing",
        "Voice & video integration",
        "Real-time cursor tracking",
        "Integrated chat system",
        "Session recording"
      ]
    },
    {
      id: "mentorship",
      title: "AI Mentorship Matching",
      description: "Intelligent mentor-mentee pairing based on skills, goals, and compatibility",
      icon: Target,
      color: "green",
      features: [
        "AI-powered compatibility scoring",
        "Skill gap analysis",
        "Goal-oriented matching",
        "Progress tracking",
        "Success metrics"
      ]
    },
    {
      id: "analytics",
      title: "Learning Analytics",
      description: "Comprehensive insights into learning patterns, progress, and skill development",
      icon: BarChart3,
      color: "orange",
      features: [
        "Learning velocity tracking",
        "Comprehension analysis",
        "Skill progression mapping",
        "AI-powered recommendations",
        "Performance benchmarking"
      ]
    },
    {
      id: "live-stream",
      title: "Interactive Live Streaming",
      description: "Enhanced live streaming with code snippet saving, interactive chat, and real-time notes",
      icon: Radio,
      color: "red",
      features: [
        "Code snippet capture",
        "Interactive chat overlay",
        "Real-time note taking",
        "Stream analytics",
        "Multi-platform support"
      ]
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      purple: "text-purple-600 bg-purple-100 border-purple-200",
      blue: "text-blue-600 bg-blue-100 border-blue-200",
      green: "text-green-600 bg-green-100 border-green-200",
      orange: "text-orange-600 bg-orange-100 border-orange-200",
      red: "text-red-600 bg-red-100 border-red-200"
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation 
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />
      
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Hero Section */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Rocket className="h-8 w-8 text-blue-600" />
            <h1 className="text-4xl font-bold text-gray-900">CodeCast Innovation Hub</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Experience the future of developer education with our revolutionary AI-powered features
          </p>
          <div className="flex items-center justify-center gap-2">
            <Badge className="bg-green-100 text-green-800">
              <CheckCircle2 className="h-3 w-3 mr-1" />
              Production Ready
            </Badge>
            <Badge className="bg-blue-100 text-blue-800">
              <Zap className="h-3 w-3 mr-1" />
              AI-Powered
            </Badge>
            <Badge className="bg-purple-100 text-purple-800">
              <Star className="h-3 w-3 mr-1" />
              Industry Leading
            </Badge>
          </div>
        </div>

        {/* Innovation Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {innovations.map((innovation) => {
            const Icon = innovation.icon;
            return (
              <Card 
                key={innovation.id}
                className={`hover:shadow-lg transition-all duration-300 cursor-pointer transform hover:-translate-y-1 ${
                  activeDemo === innovation.id ? `ring-2 ring-${innovation.color}-500` : ''
                }`}
                onClick={() => setActiveDemo(innovation.id)}
              >
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${getColorClasses(innovation.color)}`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{innovation.title}</CardTitle>
                      <Badge variant="outline" className="mt-1">
                        Revolutionary
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm mb-4">
                    {innovation.description}
                  </CardDescription>
                  
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-gray-700">Key Features:</p>
                    <ul className="space-y-1">
                      {innovation.features.slice(0, 3).map((feature, index) => (
                        <li key={index} className="text-xs text-gray-600 flex items-center gap-2">
                          <CheckCircle2 className="h-3 w-3 text-green-500" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <Button 
                    className="w-full mt-4" 
                    variant={activeDemo === innovation.id ? "default" : "outline"}
                    size="sm"
                  >
                    {activeDemo === innovation.id ? "Now Showing" : "View Demo"}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Live Demo Section */}
        {activeDemo && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Live Innovation Demo
              </CardTitle>
              <CardDescription>
                Experience {innovations.find(i => i.id === activeDemo)?.title} in action
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeDemo} onValueChange={setActiveDemo} className="w-full">
                <TabsList className="grid w-full grid-cols-6">
                  {innovations.map((innovation) => {
                    const Icon = innovation.icon;
                    return (
                      <TabsTrigger 
                        key={innovation.id} 
                        value={innovation.id}
                        className="flex items-center gap-2"
                      >
                        <Icon className="h-4 w-4" />
                        <span className="hidden sm:inline">{innovation.title.split(' ')[0]}</span>
                      </TabsTrigger>
                    );
                  })}
                </TabsList>

                <TabsContent value="ai-assistant" className="mt-6">
                  <div className="bg-gradient-to-br from-purple-50 to-blue-50 p-6 rounded-lg">
                    <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                      <Brain className="h-5 w-5 text-purple-600" />
                      AI Virtual Assistant Demo
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Experience the power of our AI assistant - your intelligent coding companion available 24/7. 
                      Click the AI assistant button in the bottom right corner to start chatting!
                    </p>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="bg-white p-4 rounded-lg shadow-sm">
                        <h4 className="font-medium mb-2">Context-Aware Help</h4>
                        <p className="text-sm text-gray-600">Ask about code debugging, learning paths, or concept explanations</p>
                      </div>
                      <div className="bg-white p-4 rounded-lg shadow-sm">
                        <h4 className="font-medium mb-2">Real-Time Support</h4>
                        <p className="text-sm text-gray-600">Get instant answers and personalized guidance throughout your journey</p>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="ai-analyzer" className="mt-6">
                  <AICodeAnalyzer 
                    videoId={1}
                    onAnalysisComplete={(analysis) => console.log('Analysis complete:', analysis)}
                  />
                </TabsContent>

                <TabsContent value="live-collab" className="mt-6">
                  <LiveCollaboration 
                    videoId={1}
                    isHost={true}
                    onJoinSession={(sessionId) => console.log('Joined session:', sessionId)}
                  />
                </TabsContent>

                <TabsContent value="mentorship" className="mt-6">
                  <MentorshipMatcher 
                    currentUserSkills={["React", "JavaScript", "Node.js"]}
                    targetSkills={["System Design", "TypeScript", "GraphQL"]}
                  />
                </TabsContent>

                <TabsContent value="analytics" className="mt-6">
                  <LearningAnalytics />
                </TabsContent>

                <TabsContent value="live-stream" className="mt-6">
                  <LiveStreamPlayer 
                    streamId="stream-123"
                    streamTitle="Building Modern React Applications"
                    streamerName="Sarah Chen"
                    category="Frontend Development"
                    isLive={true}
                    viewerCount={1247}
                    onInteraction={(type, data) => console.log('Stream interaction:', type, data)}
                  />
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        )}

        {/* Impact Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-12">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">98%</div>
              <p className="text-sm text-gray-600">Code Analysis Accuracy</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">45%</div>
              <p className="text-sm text-gray-600">Faster Learning Progress</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">92%</div>
              <p className="text-sm text-gray-600">Mentor Match Success</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">10x</div>
              <p className="text-sm text-gray-600">Engagement Increase</p>
            </CardContent>
          </Card>
        </div>

        {/* Call to Action */}
        <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Ready to Experience the Future?</h2>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
              Join thousands of developers already using CodeCast's revolutionary features to accelerate their learning journey
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                <Rocket className="h-5 w-5 mr-2" />
                Start Free Trial
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                View All Features
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}