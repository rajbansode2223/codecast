import React, { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  MessageCircle, 
  Send, 
  Minimize2, 
  Maximize2, 
  X,
  Bot,
  User,
  Lightbulb,
  Code,
  BookOpen,
  HelpCircle,
  Sparkles,
  Mic,
  MicOff
} from "lucide-react";

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
  type?: 'suggestion' | 'code' | 'explanation' | 'question';
}

interface AIAssistantProps {
  currentContext?: {
    page?: string;
    videoId?: number;
    userProgress?: any;
  };
}

export function AIAssistant({ currentContext }: AIAssistantProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      text: "Hi! I'm your AI learning assistant. I can help you understand concepts, debug code, suggest learning paths, and answer questions about your development journey. How can I assist you today?",
      sender: "assistant",
      timestamp: new Date(),
      type: "explanation"
    }
  ]);
  const [newMessage, setNewMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isVoiceMode, setIsVoiceMode] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const quickSuggestions = [
    { text: "Explain this code", icon: Code, type: "code" },
    { text: "Learning path suggestions", icon: BookOpen, type: "suggestion" },
    { text: "Debug help", icon: HelpCircle, type: "question" },
    { text: "Best practices", icon: Lightbulb, type: "explanation" }
  ];

  const generateAIResponse = async (userMessage: string): Promise<string> => {
    setIsTyping(true);
    
    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: userMessage,
          context: currentContext
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setIsTyping(false);
      return data.response;
    } catch (error) {
      setIsTyping(false);
      console.error('AI chat error:', error);
      
      // Provide intelligent fallback responses based on user input
      const message = userMessage.toLowerCase();
      if (message.includes('code') || message.includes('function') || message.includes('component')) {
        return "I can help with code analysis! For React components, focus on proper state management with useState and useEffect hooks. Consider component composition, prop validation, and performance optimization with React.memo when needed.";
      } else if (message.includes('learn') || message.includes('study') || message.includes('path')) {
        return "For your learning journey, I recommend: 1) Master JavaScript fundamentals, 2) Learn React patterns and hooks, 3) Explore TypeScript for type safety, 4) Study testing with Jest, and 5) Practice with real projects. What specific area interests you most?";
      } else if (message.includes('debug') || message.includes('error') || message.includes('problem')) {
        return "Debugging tip: Check the browser console for error messages, verify your component props and state, and use React DevTools for inspection. Common issues include state mutation, missing dependencies in useEffect, and async timing problems.";
      } else {
        return "I'm your coding assistant! I can help with code explanations, debugging, learning paths, best practices, and career guidance. The AI service is temporarily unavailable, but I'm still here to help with general guidance.";
      }
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: newMessage,
      sender: "user",
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setNewMessage("");

    // Generate AI response
    const aiResponse = await generateAIResponse(newMessage);
    
    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      text: aiResponse,
      sender: "assistant",
      timestamp: new Date(),
      type: "explanation"
    };

    setMessages(prev => [...prev, assistantMessage]);
  };

  const handleQuickSuggestion = async (suggestion: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      text: suggestion,
      sender: "user",
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);

    const aiResponse = await generateAIResponse(suggestion);
    
    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      text: aiResponse,
      sender: "assistant",
      timestamp: new Date(),
      type: "explanation"
    };

    setMessages(prev => [...prev, assistantMessage]);
  };

  const getMessageIcon = (type?: string) => {
    switch (type) {
      case 'code': return <Code className="h-3 w-3" />;
      case 'suggestion': return <Lightbulb className="h-3 w-3" />;
      case 'question': return <HelpCircle className="h-3 w-3" />;
      default: return <Sparkles className="h-3 w-3" />;
    }
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-[9999]">
        <Button
          onClick={() => setIsOpen(true)}
          size="lg"
          className="h-14 w-14 rounded-full shadow-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white animate-pulse"
          style={{ zIndex: 9999 }}
        >
          <Bot className="h-6 w-6 text-white" />
        </Button>
      </div>
    );
  }

  return (
    <div className={`fixed bottom-6 right-6 z-50 ${isMinimized ? 'w-80' : 'w-96'}`}>
      <Card className="shadow-xl border-0 bg-white/95 backdrop-blur-sm">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="relative">
                <Avatar className="h-8 w-8 bg-gradient-to-r from-blue-600 to-purple-600">
                  <AvatarFallback className="text-white">
                    <Bot className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-1 -right-1">
                  <div className="h-3 w-3 bg-green-500 rounded-full border-2 border-white"></div>
                </div>
              </div>
              <div>
                <CardTitle className="text-sm">AI Assistant</CardTitle>
                <CardDescription className="text-xs">Ready to help</CardDescription>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsVoiceMode(!isVoiceMode)}
                className="h-8 w-8 p-0"
              >
                {isVoiceMode ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMinimized(!isMinimized)}
                className="h-8 w-8 p-0"
              >
                {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(false)}
                className="h-8 w-8 p-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>

        {!isMinimized && (
          <CardContent className="space-y-4">
            {/* Messages */}
            <div className="h-64 overflow-y-auto space-y-3 p-2 bg-gray-50 rounded-md">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-2 ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {message.sender === 'assistant' && (
                    <Avatar className="h-6 w-6 bg-gradient-to-r from-blue-600 to-purple-600">
                      <AvatarFallback className="text-white text-xs">
                        <Bot className="h-3 w-3" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                  <div
                    className={`max-w-[80%] p-2 rounded-lg text-sm ${
                      message.sender === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-white border shadow-sm'
                    }`}
                  >
                    {message.sender === 'assistant' && message.type && (
                      <div className="flex items-center gap-1 mb-1">
                        {getMessageIcon(message.type)}
                        <Badge variant="outline" className="text-xs">
                          {message.type}
                        </Badge>
                      </div>
                    )}
                    <p>{message.text}</p>
                    <span className="text-xs opacity-70 mt-1 block">
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  {message.sender === 'user' && (
                    <Avatar className="h-6 w-6 bg-gray-300">
                      <AvatarFallback className="text-gray-600 text-xs">
                        <User className="h-3 w-3" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}
              
              {isTyping && (
                <div className="flex gap-2 justify-start">
                  <Avatar className="h-6 w-6 bg-gradient-to-r from-blue-600 to-purple-600">
                    <AvatarFallback className="text-white text-xs">
                      <Bot className="h-3 w-3" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="bg-white border shadow-sm p-2 rounded-lg">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Suggestions */}
            <div className="grid grid-cols-2 gap-2">
              {quickSuggestions.map((suggestion) => {
                const Icon = suggestion.icon;
                return (
                  <Button
                    key={suggestion.text}
                    variant="outline"
                    size="sm"
                    onClick={() => handleQuickSuggestion(suggestion.text)}
                    className="justify-start text-xs h-8"
                  >
                    <Icon className="h-3 w-3 mr-1" />
                    {suggestion.text}
                  </Button>
                );
              })}
            </div>

            {/* Input */}
            <div className="flex gap-2">
              <Input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Ask me anything..."
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                className="flex-1 text-sm"
              />
              <Button onClick={sendMessage} size="sm" disabled={!newMessage.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
}