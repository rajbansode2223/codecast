import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  BookOpen, 
  Clock, 
  Users, 
  Play, 
  CheckCircle, 
  Circle,
  Star,
  Target,
  TrendingUp
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface LearningPathProps {
  path: {
    id: number;
    title: string;
    description: string;
    category: string;
    difficulty: string;
    estimatedHours: number;
    enrollmentCount: number;
    tags: string[];
    creator: {
      id: string;
      firstName: string;
      lastName: string;
      profileImageUrl?: string;
    };
  };
  videos?: Array<{
    id: number;
    title: string;
    duration: number;
    order: number;
    isOptional: boolean;
    notes?: string;
    isCompleted?: boolean;
  }>;
  userProgress?: {
    completedVideos: number;
    totalVideos: number;
    enrolledAt?: string;
  };
  onEnroll?: () => void;
  onVideoClick?: (videoId: number) => void;
}

export function LearningPath({ 
  path, 
  videos = [], 
  userProgress, 
  onEnroll, 
  onVideoClick 
}: LearningPathProps) {
  const [isEnrolled, setIsEnrolled] = useState(!!userProgress);
  const { toast } = useToast();

  const handleEnroll = () => {
    setIsEnrolled(true);
    onEnroll?.();
    toast({
      title: "Enrolled successfully!",
      description: `You're now enrolled in ${path.title}`,
    });
  };

  const progressPercentage = userProgress 
    ? (userProgress.completedVideos / userProgress.totalVideos) * 100 
    : 0;

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "beginner": return "bg-green-100 text-green-800";
      case "intermediate": return "bg-yellow-100 text-yellow-800";
      case "advanced": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="space-y-2 flex-1">
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-blue-500" />
              {path.title}
            </CardTitle>
            <CardDescription>{path.description}</CardDescription>
            
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {path.estimatedHours}h estimated
              </div>
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4" />
                {path.enrollmentCount} enrolled
              </div>
              <div className="flex items-center gap-1">
                <Target className="h-4 w-4" />
                {videos.length} videos
              </div>
            </div>
          </div>

          <div className="text-right space-y-2 ml-4">
            <div className="flex gap-2">
              <Badge className={getDifficultyColor(path.difficulty)}>
                {path.difficulty}
              </Badge>
              <Badge variant="outline">{path.category}</Badge>
            </div>
            
            {!isEnrolled ? (
              <Button onClick={handleEnroll} className="w-full">
                Enroll Now
              </Button>
            ) : (
              <div className="space-y-2">
                <div className="text-sm font-medium">
                  Progress: {userProgress?.completedVideos || 0}/{userProgress?.totalVideos || videos.length}
                </div>
                <Progress value={progressPercentage} className="w-32" />
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 pt-2">
          <Avatar className="h-6 w-6">
            <AvatarImage src={path.creator.profileImageUrl} />
            <AvatarFallback className="text-xs">
              {path.creator.firstName?.[0]}{path.creator.lastName?.[0]}
            </AvatarFallback>
          </Avatar>
          <span className="text-sm text-gray-600">
            by {path.creator.firstName} {path.creator.lastName}
          </span>
        </div>

        <div className="flex flex-wrap gap-1 pt-2">
          {path.tags.map((tag) => (
            <Badge key={tag} variant="secondary" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>
      </CardHeader>

      {isEnrolled && videos.length > 0 && (
        <CardContent>
          <div className="space-y-3">
            <h3 className="font-medium flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Learning Path Videos
            </h3>
            
            <div className="space-y-2">
              {videos
                .sort((a, b) => a.order - b.order)
                .map((video) => (
                  <div
                    key={video.id}
                    className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                      video.isCompleted 
                        ? "bg-green-50 border-green-200" 
                        : "bg-gray-50 border-gray-200 hover:bg-gray-100"
                    }`}
                    onClick={() => onVideoClick?.(video.id)}
                  >
                    <div className="flex-shrink-0">
                      {video.isCompleted ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <Circle className="h-5 w-5 text-gray-400" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium truncate">
                          {video.order}. {video.title}
                        </span>
                        {video.isOptional && (
                          <Badge variant="outline" className="text-xs">
                            Optional
                          </Badge>
                        )}
                      </div>
                      
                      {video.notes && (
                        <p className="text-xs text-gray-600 mt-1">
                          {video.notes}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Clock className="h-4 w-4" />
                      {formatDuration(video.duration)}
                      <Play className="h-4 w-4" />
                    </div>
                  </div>
                ))}
            </div>

            {userProgress && progressPercentage === 100 && (
              <Card className="bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-200">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-yellow-800">
                    <Star className="h-5 w-5 fill-current" />
                    <span className="font-medium">Congratulations!</span>
                  </div>
                  <p className="text-sm text-yellow-700 mt-1">
                    You've completed this learning path. Consider leaving a review!
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </CardContent>
      )}
    </Card>
  );
}