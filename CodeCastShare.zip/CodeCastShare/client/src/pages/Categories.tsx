import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Navigation } from "@/components/Navigation";
import { useState } from "react";
import { Link } from "wouter";
import { 
  Code, 
  Server, 
  Smartphone, 
  Cloud, 
  Database, 
  GamepadIcon, 
  Shield, 
  Coins,
  ChevronRight,
  TrendingUp
} from "lucide-react";

const categoryIcons = {
  'Frontend': Code,
  'Backend': Server,
  'Mobile': Smartphone,
  'DevOps': Cloud,
  'Data Science': Database,
  'Game Development': GamepadIcon,
  'Security': Shield,
  'Web3': Coins
};

export default function Categories() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: categories, isLoading } = useQuery({
    queryKey: ["/api/categories"],
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation 
        searchQuery={searchQuery} 
        onSearchChange={setSearchQuery}
      />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-8 w-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg"></div>
            <h1 className="text-3xl font-bold text-gray-900">Browse Categories</h1>
          </div>
          <p className="text-gray-600 text-lg">
            Explore developer content organized by technology and skill area
          </p>
        </div>

        {/* Featured Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
          {isLoading ? (
            Array.from({ length: 8 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader className="pb-4">
                  <div className="h-8 w-8 bg-gray-200 rounded mb-3"></div>
                  <div className="h-6 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded"></div>
                </CardHeader>
                <CardContent>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded"></div>
                </CardContent>
              </Card>
            ))
          ) : (
            categories?.map((category: any) => {
              const IconComponent = categoryIcons[category.name as keyof typeof categoryIcons] || Code;
              
              return (
                <Link key={category.name} href={`/categories/${category.name.toLowerCase()}`}>
                  <Card className="hover:shadow-lg transition-all duration-200 cursor-pointer group h-full">
                    <CardHeader className="pb-4">
                      <div className="flex items-center justify-between mb-3">
                        <IconComponent className="h-8 w-8 text-blue-500 group-hover:text-blue-600 transition-colors" />
                        <Badge variant="secondary" className="text-xs">
                          {category.count}
                        </Badge>
                      </div>
                      <CardTitle className="text-xl group-hover:text-blue-600 transition-colors">
                        {category.name}
                      </CardTitle>
                      <CardDescription className="text-sm">
                        {category.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">
                          {category.count} videos
                        </span>
                        <Button variant="ghost" size="sm" className="group-hover:bg-blue-50">
                          Explore
                          <ChevronRight className="h-4 w-4 ml-1" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })
          )}
        </div>

        {/* Trending in Categories */}
        <section className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <TrendingUp className="h-6 w-6 text-green-500" />
            <h2 className="text-2xl font-bold text-gray-900">Trending in Categories</h2>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {['Frontend', 'Backend', 'Mobile', 'DevOps'].map((category) => (
              <Card key={category} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl flex items-center gap-2">
                      {React.createElement(categoryIcons[category as keyof typeof categoryIcons] || Code, {
                        className: "h-6 w-6 text-blue-500"
                      })}
                      {category}
                    </CardTitle>
                    <Link href={`/categories/${category.toLowerCase()}`}>
                      <Button variant="outline" size="sm">
                        View All
                      </Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                        <div className="flex-1">
                          <h4 className="font-medium text-sm mb-1">
                            {category} Mastery Course Part {i}
                          </h4>
                          <div className="flex items-center gap-4 text-xs text-gray-600">
                            <span>{(1000 + i * 200).toLocaleString()} views</span>
                            <span>{15 + i * 5} min</span>
                            <Badge variant="outline" className="text-xs">
                              Intermediate
                            </Badge>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <TrendingUp className="h-4 w-4 text-green-500" />
                          <span className="text-xs text-green-600 font-medium">
                            +{20 + i * 10}%
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Popular Learning Paths by Category */}
        <section>
          <div className="flex items-center gap-3 mb-6">
            <div className="h-6 w-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded"></div>
            <h2 className="text-2xl font-bold text-gray-900">Popular Learning Paths</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { name: 'Full Stack Web Development', category: 'Frontend', videos: 24, duration: '18 hours' },
              { name: 'Cloud Architecture Mastery', category: 'DevOps', videos: 16, duration: '12 hours' },
              { name: 'Mobile App Development', category: 'Mobile', videos: 20, duration: '15 hours' },
              { name: 'Data Science Fundamentals', category: 'Data Science', videos: 18, duration: '14 hours' },
              { name: 'Cybersecurity Essentials', category: 'Security', videos: 14, duration: '10 hours' },
              { name: 'Game Development Basics', category: 'Game Development', videos: 22, duration: '16 hours' }
            ].map((path) => (
              <Card key={path.name} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline" className="text-xs">
                      {path.category}
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      {path.videos} videos
                    </Badge>
                  </div>
                  <CardTitle className="text-lg">{path.name}</CardTitle>
                  <CardDescription>
                    Comprehensive learning path covering all essential concepts
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">{path.duration}</span>
                    <Link href="/learning-paths">
                      <Button variant="outline" size="sm">
                        Start Learning
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}