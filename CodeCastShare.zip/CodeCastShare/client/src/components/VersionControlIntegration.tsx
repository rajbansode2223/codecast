import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  GitBranch, 
  GitCommit, 
  GitMerge, 
  GitPullRequest,
  History,
  Save,
  Undo,
  Redo,
  ArrowLeftRight,
  Download,
  Upload,
  Clock,
  User,
  FileText,
  Plus,
  Trash2,
  Copy,
  Eye,
  Archive
} from "lucide-react";

interface Commit {
  id: string;
  message: string;
  author: string;
  timestamp: Date;
  code: string;
  changes: {
    additions: number;
    deletions: number;
    files: string[];
  };
  branch: string;
  parent?: string;
}

interface Branch {
  name: string;
  commits: string[];
  lastCommit: string;
  isActive: boolean;
  created: Date;
  mergedInto?: string;
}

interface VersionControlIntegrationProps {
  initialCode?: string;
  onCodeChange?: (code: string) => void;
  onCommit?: (commit: Commit) => void;
}

export function VersionControlIntegration({ 
  initialCode = "", 
  onCodeChange,
  onCommit 
}: VersionControlIntegrationProps) {
  const [code, setCode] = useState(initialCode);
  const [commits, setCommits] = useState<Commit[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [currentBranch, setCurrentBranch] = useState("main");
  const [commitMessage, setCommitMessage] = useState("");
  const [newBranchName, setNewBranchName] = useState("");
  const [selectedCommit, setSelectedCommit] = useState<string | null>(null);
  const [compareMode, setCompareMode] = useState(false);
  const [compareCommits, setCompareCommits] = useState<{from: string; to: string}>({from: "", to: ""});
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Initialize with sample version history
  useEffect(() => {
    const initialCommits: Commit[] = [
      {
        id: "c1",
        message: "Initial commit: Basic function structure",
        author: "CodeMaster",
        timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        code: "function fibonacci(n) {\n  if (n <= 1) return n;\n  return fibonacci(n - 1) + fibonacci(n - 2);\n}",
        changes: { additions: 4, deletions: 0, files: ["main.js"] },
        branch: "main"
      },
      {
        id: "c2",
        message: "Add input validation",
        author: "CodeMaster",
        timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        code: "function fibonacci(n) {\n  if (typeof n !== 'number' || n < 0) {\n    throw new Error('Input must be a non-negative number');\n  }\n  if (n <= 1) return n;\n  return fibonacci(n - 1) + fibonacci(n - 2);\n}",
        changes: { additions: 3, deletions: 0, files: ["main.js"] },
        branch: "main",
        parent: "c1"
      },
      {
        id: "c3",
        message: "Optimize with memoization",
        author: "OptimizationExpert",
        timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        code: "function fibonacci(n, cache = {}) {\n  if (typeof n !== 'number' || n < 0) {\n    throw new Error('Input must be a non-negative number');\n  }\n  if (n <= 1) return n;\n  if (n in cache) return cache[n];\n  cache[n] = fibonacci(n - 1, cache) + fibonacci(n - 2, cache);\n  return cache[n];\n}",
        changes: { additions: 4, deletions: 2, files: ["main.js"] },
        branch: "optimization",
        parent: "c2"
      },
      {
        id: "c4",
        message: "Add comprehensive test suite",
        author: "TestingNinja",
        timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        code: "function fibonacci(n, cache = {}) {\n  if (typeof n !== 'number' || n < 0) {\n    throw new Error('Input must be a non-negative number');\n  }\n  if (n <= 1) return n;\n  if (n in cache) return cache[n];\n  cache[n] = fibonacci(n - 1, cache) + fibonacci(n - 2, cache);\n  return cache[n];\n}\n\n// Test cases\nconsole.assert(fibonacci(0) === 0);\nconsole.assert(fibonacci(1) === 1);\nconsole.assert(fibonacci(10) === 55);",
        changes: { additions: 5, deletions: 0, files: ["main.js", "tests.js"] },
        branch: "testing",
        parent: "c3"
      },
      {
        id: "c5",
        message: "Merge optimization and testing branches",
        author: "ProjectLead",
        timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        code: "function fibonacci(n, cache = {}) {\n  if (typeof n !== 'number' || n < 0) {\n    throw new Error('Input must be a non-negative number');\n  }\n  if (n <= 1) return n;\n  if (n in cache) return cache[n];\n  cache[n] = fibonacci(n - 1, cache) + fibonacci(n - 2, cache);\n  return cache[n];\n}\n\n// Test cases\nconsole.assert(fibonacci(0) === 0);\nconsole.assert(fibonacci(1) === 1);\nconsole.assert(fibonacci(10) === 55);\n\n// Performance test\nconst start = performance.now();\nconsole.log(fibonacci(40));\nconsole.log(`Execution time: ${performance.now() - start}ms`);",
        changes: { additions: 4, deletions: 0, files: ["main.js"] },
        branch: "main",
        parent: "c4"
      }
    ];

    const initialBranches: Branch[] = [
      {
        name: "main",
        commits: ["c1", "c2", "c5"],
        lastCommit: "c5",
        isActive: true,
        created: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      },
      {
        name: "optimization",
        commits: ["c3"],
        lastCommit: "c3",
        isActive: false,
        created: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
        mergedInto: "main"
      },
      {
        name: "testing",
        commits: ["c4"],
        lastCommit: "c4",
        isActive: false,
        created: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        mergedInto: "main"
      }
    ];

    setCommits(initialCommits);
    setBranches(initialBranches);
    setCode(initialCommits[initialCommits.length - 1].code);
  }, []);

  useEffect(() => {
    if (code !== initialCode) {
      setHasUnsavedChanges(true);
    }
  }, [code, initialCode]);

  const handleCodeChange = (newCode: string) => {
    setCode(newCode);
    setHasUnsavedChanges(true);
    onCodeChange?.(newCode);
  };

  const createCommit = () => {
    if (!commitMessage.trim()) return;

    const newCommit: Commit = {
      id: `c${commits.length + 1}`,
      message: commitMessage,
      author: "CurrentUser",
      timestamp: new Date(),
      code,
      changes: {
        additions: Math.floor(Math.random() * 10) + 1,
        deletions: Math.floor(Math.random() * 5),
        files: ["main.js"]
      },
      branch: currentBranch,
      parent: commits.length > 0 ? commits[commits.length - 1].id : undefined
    };

    setCommits(prev => [...prev, newCommit]);
    setCommitMessage("");
    setHasUnsavedChanges(false);
    
    // Update current branch
    setBranches(prev => prev.map(branch => 
      branch.name === currentBranch 
        ? { ...branch, commits: [...branch.commits, newCommit.id], lastCommit: newCommit.id }
        : branch
    ));

    onCommit?.(newCommit);
  };

  const createBranch = () => {
    if (!newBranchName.trim() || branches.some(b => b.name === newBranchName)) return;

    const newBranch: Branch = {
      name: newBranchName,
      commits: [],
      lastCommit: commits[commits.length - 1]?.id || "",
      isActive: false,
      created: new Date()
    };

    setBranches(prev => [...prev, newBranch]);
    setNewBranchName("");
  };

  const switchBranch = (branchName: string) => {
    setBranches(prev => prev.map(branch => ({
      ...branch,
      isActive: branch.name === branchName
    })));
    setCurrentBranch(branchName);

    // Load the latest commit from the new branch
    const branch = branches.find(b => b.name === branchName);
    if (branch && branch.lastCommit) {
      const commit = commits.find(c => c.id === branch.lastCommit);
      if (commit) {
        setCode(commit.code);
        setHasUnsavedChanges(false);
      }
    }
  };

  const checkoutCommit = (commitId: string) => {
    const commit = commits.find(c => c.id === commitId);
    if (commit) {
      setCode(commit.code);
      setSelectedCommit(commitId);
      setHasUnsavedChanges(false);
    }
  };

  const revertToCommit = (commitId: string) => {
    const commit = commits.find(c => c.id === commitId);
    if (commit) {
      setCode(commit.code);
      setHasUnsavedChanges(true);
    }
  };

  const mergeBranches = (sourceBranch: string, targetBranch: string) => {
    const source = branches.find(b => b.name === sourceBranch);
    const target = branches.find(b => b.name === targetBranch);
    
    if (source && target) {
      // Simple merge: mark source as merged
      setBranches(prev => prev.map(branch => 
        branch.name === sourceBranch 
          ? { ...branch, mergedInto: targetBranch }
          : branch
      ));
    }
  };

  const compareCommitsData = () => {
    if (!compareCommits.from || !compareCommits.to) return null;
    
    const fromCommit = commits.find(c => c.id === compareCommits.from);
    const toCommit = commits.find(c => c.id === compareCommits.to);
    
    if (!fromCommit || !toCommit) return null;
    
    return {
      from: fromCommit,
      to: toCommit,
      diff: {
        additions: Math.abs(toCommit.code.length - fromCommit.code.length),
        deletions: Math.max(0, fromCommit.code.length - toCommit.code.length)
      }
    };
  };

  const exportRepository = () => {
    const repoData = {
      commits,
      branches,
      currentBranch,
      exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(repoData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'code-repository.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const formatTimestamp = (date: Date) => {
    return new Intl.RelativeTimeFormat('en', { numeric: 'auto' }).format(
      Math.ceil((date.getTime() - Date.now()) / (1000 * 60 * 60 * 24)), 
      'day'
    );
  };

  const getCommitsByBranch = (branchName: string) => {
    const branch = branches.find(b => b.name === branchName);
    if (!branch) return [];
    return commits.filter(c => branch.commits.includes(c.id));
  };

  const getCurrentBranch = () => branches.find(b => b.isActive) || branches[0];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <GitBranch className="h-6 w-6" />
          <h2 className="text-2xl font-bold">Version Control Integration</h2>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="flex items-center gap-1">
            <GitBranch className="h-3 w-3" />
            {currentBranch}
          </Badge>
          {hasUnsavedChanges && (
            <Badge variant="destructive">Unsaved Changes</Badge>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Code Editor */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Code Editor
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={() => setCompareMode(!compareMode)}>
                    <ArrowLeftRight className="h-4 w-4 mr-1" />
                    {compareMode ? 'Exit Compare' : 'Compare'}
                  </Button>
                  <Button variant="outline" size="sm" onClick={exportRepository}>
                    <Download className="h-4 w-4 mr-1" />
                    Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={code}
                onChange={(e) => handleCodeChange(e.target.value)}
                className="min-h-80 font-mono text-sm"
                placeholder="Write your code here..."
              />
              
              <div className="flex items-center gap-2">
                <Input
                  value={commitMessage}
                  onChange={(e) => setCommitMessage(e.target.value)}
                  placeholder="Commit message..."
                  className="flex-1"
                />
                <Button 
                  onClick={createCommit} 
                  disabled={!commitMessage.trim() || !hasUnsavedChanges}
                >
                  <GitCommit className="h-4 w-4 mr-2" />
                  Commit
                </Button>
              </div>

              {selectedCommit && (
                <div className="p-3 bg-blue-50 border border-blue-200 rounded">
                  <p className="text-sm text-blue-700">
                    Currently viewing commit: {selectedCommit}
                  </p>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => setSelectedCommit(null)}
                    className="mt-2"
                  >
                    Return to HEAD
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Compare Mode */}
          {compareMode && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ArrowLeftRight className="h-5 w-5" />
                  Compare Commits
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">From Commit</label>
                    <Select 
                      value={compareCommits.from} 
                      onValueChange={(value) => setCompareCommits(prev => ({...prev, from: value}))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select commit" />
                      </SelectTrigger>
                      <SelectContent>
                        {commits.map(commit => (
                          <SelectItem key={commit.id} value={commit.id}>
                            {commit.id}: {commit.message.slice(0, 30)}...
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">To Commit</label>
                    <Select 
                      value={compareCommits.to} 
                      onValueChange={(value) => setCompareCommits(prev => ({...prev, to: value}))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select commit" />
                      </SelectTrigger>
                      <SelectContent>
                        {commits.map(commit => (
                          <SelectItem key={commit.id} value={commit.id}>
                            {commit.id}: {commit.message.slice(0, 30)}...
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {compareCommitsData() && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 bg-red-50 rounded border border-red-200">
                        <h4 className="font-medium text-red-900 mb-2">From: {compareCommitsData()!.from.message}</h4>
                        <pre className="text-xs text-red-700 whitespace-pre-wrap">
                          {compareCommitsData()!.from.code}
                        </pre>
                      </div>
                      <div className="p-3 bg-green-50 rounded border border-green-200">
                        <h4 className="font-medium text-green-900 mb-2">To: {compareCommitsData()!.to.message}</h4>
                        <pre className="text-xs text-green-700 whitespace-pre-wrap">
                          {compareCommitsData()!.to.code}
                        </pre>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="flex items-center gap-1 text-green-600">
                        <Plus className="h-3 w-3" />
                        +{compareCommitsData()!.diff.additions} additions
                      </span>
                      <span className="flex items-center gap-1 text-red-600">
                        <Trash2 className="h-3 w-3" />
                        -{compareCommitsData()!.diff.deletions} deletions
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Version Control Panel */}
        <div className="space-y-4">
          {/* Branch Management */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <GitBranch className="h-5 w-5" />
                Branches
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                {branches.map(branch => (
                  <div 
                    key={branch.name}
                    className={`flex items-center justify-between p-2 rounded cursor-pointer transition-colors ${
                      branch.isActive ? 'bg-primary/10 border border-primary/20' : 'hover:bg-muted/50'
                    }`}
                    onClick={() => switchBranch(branch.name)}
                  >
                    <div className="flex items-center gap-2">
                      <GitBranch className="h-4 w-4" />
                      <span className="font-medium">{branch.name}</span>
                      {branch.isActive && <Badge variant="default" className="text-xs">active</Badge>}
                      {branch.mergedInto && (
                        <Badge variant="secondary" className="text-xs">
                          merged into {branch.mergedInto}
                        </Badge>
                      )}
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {formatTimestamp(branch.created)}
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <Input
                  value={newBranchName}
                  onChange={(e) => setNewBranchName(e.target.value)}
                  placeholder="Branch name..."
                  className="flex-1"
                />
                <Button size="sm" onClick={createBranch} disabled={!newBranchName.trim()}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Commit History */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <History className="h-5 w-5" />
                Commit History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-3">
                  {commits.slice().reverse().map((commit, index) => (
                    <div 
                      key={commit.id}
                      className={`p-3 border rounded cursor-pointer transition-colors ${
                        selectedCommit === commit.id 
                          ? 'border-primary bg-primary/5' 
                          : 'hover:bg-muted/50'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <p className="font-medium text-sm">{commit.message}</p>
                          <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                            <User className="h-3 w-3" />
                            {commit.author}
                            <Clock className="h-3 w-3" />
                            {formatTimestamp(commit.timestamp)}
                          </div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {commit.id}
                        </Badge>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-xs">
                          <span className="flex items-center gap-1 text-green-600">
                            <Plus className="h-3 w-3" />
                            +{commit.changes.additions}
                          </span>
                          <span className="flex items-center gap-1 text-red-600">
                            <Trash2 className="h-3 w-3" />
                            -{commit.changes.deletions}
                          </span>
                          <Badge variant="secondary" className="text-xs">
                            {commit.branch}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            onClick={() => checkoutCommit(commit.id)}
                          >
                            <Eye className="h-3 w-3" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline" 
                            onClick={() => revertToCommit(commit.id)}
                          >
                            <Undo className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start" size="sm">
                <GitMerge className="h-4 w-4 mr-2" />
                Merge Branches
              </Button>
              <Button variant="outline" className="w-full justify-start" size="sm">
                <GitPullRequest className="h-4 w-4 mr-2" />
                Create Pull Request
              </Button>
              <Button variant="outline" className="w-full justify-start" size="sm">
                <Archive className="h-4 w-4 mr-2" />
                Stash Changes
              </Button>
              <Button variant="outline" className="w-full justify-start" size="sm">
                <Copy className="h-4 w-4 mr-2" />
                Clone Repository
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}