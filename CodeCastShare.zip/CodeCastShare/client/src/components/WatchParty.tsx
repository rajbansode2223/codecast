import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, Users, Play, Pause, Volume2, VolumeX, MessageCircle, Settings, Crown } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface WatchPartyUser {
  id: string;
  name: string;
  avatar?: string;
  isHost: boolean;
  isReady: boolean;
  lastSeen: Date;
}

interface WatchPartyProps {
  videoId: number;
  onTimeSync?: (timestamp: number) => void;
  onPlayStateSync?: (isPlaying: boolean) => void;
}

export function WatchParty({ videoId, onTimeSync, onPlayStateSync }: WatchPartyProps) {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [partyId, setPartyId] = useState<string | null>(null);
  const [isHost, setIsHost] = useState(false);
  const [users, setUsers] = useState<WatchPartyUser[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [joinCode, setJoinCode] = useState("");
  const [videoState, setVideoState] = useState({
    currentTime: 0,
    isPlaying: false,
    volume: 1,
    isMuted: false
  });
  const [chatMessages, setChatMessages] = useState<Array<{
    id: string;
    userId: string;
    userName: string;
    message: string;
    timestamp: Date;
    type: 'message' | 'system';
  }>>([]);
  const [newMessage, setNewMessage] = useState("");

  // Generate party ID
  const generatePartyId = () => {
    const id = Math.random().toString(36).substring(2, 8).toUpperCase();
    return id;
  };

  // Create a new watch party
  const createParty = () => {
    const newPartyId = generatePartyId();
    setPartyId(newPartyId);
    setIsHost(true);
    setIsConnected(true);
    
    const hostUser: WatchPartyUser = {
      id: user?.id || "host",
      name: user?.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : "Host",
      avatar: user?.profileImageUrl,
      isHost: true,
      isReady: true,
      lastSeen: new Date()
    };
    
    setUsers([hostUser]);
    
    // Add system message
    setChatMessages([{
      id: "1",
      userId: "system",
      userName: "System",
      message: "Watch party created! Share the code with friends to join.",
      timestamp: new Date(),
      type: 'system'
    }]);

    toast({
      title: "Watch Party Created!",
      description: `Share code: ${newPartyId}`,
    });
  };

  // Join an existing watch party
  const joinParty = () => {
    if (!joinCode.trim()) return;
    
    setPartyId(joinCode.toUpperCase());
    setIsHost(false);
    setIsConnected(true);
    
    // Simulate joining a party with existing users
    const existingUsers: WatchPartyUser[] = [
      {
        id: "host_user",
        name: "PartyHost_123",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face",
        isHost: true,
        isReady: true,
        lastSeen: new Date()
      },
      {
        id: "user_2",
        name: "CodeWatcher_42",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b691?w=40&h=40&fit=crop&crop=face",
        isHost: false,
        isReady: true,
        lastSeen: new Date(Date.now() - 30000)
      }
    ];

    const newUser: WatchPartyUser = {
      id: user?.id || "guest",
      name: user?.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : "Guest",
      avatar: user?.profileImageUrl,
      isHost: false,
      isReady: true,
      lastSeen: new Date()
    };

    setUsers([...existingUsers, newUser]);
    
    // Add system and existing messages
    setChatMessages([
      {
        id: "1",
        userId: "system",
        userName: "System",
        message: "Welcome to the watch party!",
        timestamp: new Date(Date.now() - 120000),
        type: 'system'
      },
      {
        id: "2",
        userId: "host_user",
        userName: "PartyHost_123",
        message: "Hey everyone! Ready to learn together?",
        timestamp: new Date(Date.now() - 90000),
        type: 'message'
      },
      {
        id: "3",
        userId: "user_2",
        userName: "CodeWatcher_42",
        message: "Excited for this tutorial!",
        timestamp: new Date(Date.now() - 60000),
        type: 'message'
      },
      {
        id: "4",
        userId: "system",
        userName: "System",
        message: `${newUser.name} joined the party!`,
        timestamp: new Date(),
        type: 'system'
      }
    ]);

    toast({
      title: "Joined Watch Party!",
      description: `Connected to party: ${joinCode.toUpperCase()}`,
    });
  };

  // Leave watch party
  const leaveParty = () => {
    setPartyId(null);
    setIsHost(false);
    setIsConnected(false);
    setUsers([]);
    setChatMessages([]);
    setJoinCode("");
  };

  // Copy party code to clipboard
  const copyPartyCode = async () => {
    if (!partyId) return;
    
    try {
      await navigator.clipboard.writeText(partyId);
      toast({
        title: "Code Copied!",
        description: "Party code copied to clipboard",
      });
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Could not copy to clipboard",
        variant: "destructive",
      });
    }
  };

  // Send chat message
  const sendMessage = () => {
    if (!newMessage.trim() || !isConnected) return;

    const message = {
      id: `msg_${Date.now()}`,
      userId: user?.id || "current_user",
      userName: user?.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : "You",
      message: newMessage,
      timestamp: new Date(),
      type: 'message' as const
    };

    setChatMessages(prev => [...prev, message]);
    setNewMessage("");
  };

  // Simulate video state synchronization
  useEffect(() => {
    if (!isConnected) return;

    const syncInterval = setInterval(() => {
      // Simulate receiving sync data from other users
      if (isHost) {
        // Host sends sync data
        onTimeSync?.(videoState.currentTime);
        onPlayStateSync?.(videoState.isPlaying);
      } else {
        // Non-host receives sync data
        const simulatedTime = Math.floor(Math.random() * 300) + 10;
        setVideoState(prev => ({
          ...prev,
          currentTime: simulatedTime,
          isPlaying: Math.random() > 0.7
        }));
      }
    }, 2000);

    return () => clearInterval(syncInterval);
  }, [isConnected, isHost, videoState.currentTime, videoState.isPlaying]);

  // Update user activity
  useEffect(() => {
    if (!isConnected) return;

    const activityInterval = setInterval(() => {
      setUsers(prev => prev.map(user => 
        user.id === (user?.id || "current_user")
          ? { ...user, lastSeen: new Date() }
          : user
      ));
    }, 30000);

    return () => clearInterval(activityInterval);
  }, [isConnected, user?.id]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!isAuthenticated) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Users className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-lg font-semibold mb-2">Watch Party</h3>
          <p className="text-muted-foreground mb-4">
            Sign in to create or join watch parties and watch videos together with friends
          </p>
          <Button asChild>
            <a href="/api/login">Sign In</a>
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (!isConnected) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Watch Party
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center space-y-4">
            <p className="text-muted-foreground">
              Watch videos together with friends in real-time
            </p>
            
            <div className="space-y-3">
              <Button onClick={createParty} className="w-full">
                Create Watch Party
              </Button>
              
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">Or</span>
                </div>
              </div>
              
              <div className="flex gap-2">
                <Input
                  placeholder="Enter party code"
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                  onKeyPress={(e) => e.key === "Enter" && joinParty()}
                  maxLength={6}
                />
                <Button onClick={joinParty} disabled={!joinCode.trim()}>
                  Join
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Users className="h-5 w-5" />
            Watch Party
            {isHost && <Crown className="h-4 w-4 text-yellow-500" />}
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              {users.length} viewers
            </Badge>
            <Button variant="outline" size="sm" onClick={leaveParty}>
              Leave
            </Button>
          </div>
        </div>
        
        {partyId && (
          <div className="flex items-center gap-2 p-2 bg-muted rounded-lg">
            <span className="text-sm font-mono">{partyId}</span>
            <Button variant="ghost" size="sm" onClick={copyPartyCode}>
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        )}
      </CardHeader>

      <CardContent className="flex-1 p-4 pt-0">
        <Tabs defaultValue="viewers" className="h-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="viewers">Viewers ({users.length})</TabsTrigger>
            <TabsTrigger value="chat">Chat</TabsTrigger>
          </TabsList>

          <TabsContent value="viewers" className="space-y-4">
            <div className="space-y-3">
              {users.map((user) => (
                <div key={user.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.avatar} />
                    <AvatarFallback>{user.name[0]}</AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm truncate">{user.name}</span>
                      {user.isHost && <Crown className="h-3 w-3 text-yellow-500" />}
                    </div>
                    <div className="flex items-center gap-1">
                      <div className={`w-2 h-2 rounded-full ${user.isReady ? 'bg-green-500' : 'bg-yellow-500'}`} />
                      <span className="text-xs text-muted-foreground">
                        {user.isReady ? 'Ready' : 'Loading...'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {isHost && (
              <div className="border-t pt-4 space-y-3">
                <h4 className="font-medium text-sm">Host Controls</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" size="sm">
                    <Play className="h-4 w-4 mr-2" />
                    Sync Play
                  </Button>
                  <Button variant="outline" size="sm">
                    <Pause className="h-4 w-4 mr-2" />
                    Sync Pause
                  </Button>
                </div>
                <div className="text-xs text-muted-foreground">
                  Current time: {formatTime(videoState.currentTime)}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="chat" className="h-full flex flex-col">
            <div className="flex-1 space-y-3 mb-4 max-h-64 overflow-y-auto">
              {chatMessages.map((msg) => (
                <div key={msg.id} className={`flex gap-2 ${msg.type === 'system' ? 'justify-center' : ''}`}>
                  {msg.type === 'system' ? (
                    <div className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                      {msg.message}
                    </div>
                  ) : (
                    <>
                      <Avatar className="h-6 w-6">
                        <AvatarFallback className="text-xs">{msg.userName[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-xs">{msg.userName}</span>
                          <span className="text-xs text-muted-foreground">
                            {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-sm">{msg.message}</p>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <Input
                placeholder="Type a message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && sendMessage()}
              />
              <Button onClick={sendMessage} disabled={!newMessage.trim()} size="sm">
                <MessageCircle className="h-4 w-4" />
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}