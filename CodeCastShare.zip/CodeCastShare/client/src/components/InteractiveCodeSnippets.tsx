import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Code, 
  Play, 
  Copy, 
  Download, 
  Share, 
  BookOpen,
  Lightbulb,
  Target,
  CheckCircle,
  XCircle,
  Clock,
  Star,
  Filter,
  Search
} from "lucide-react";
import { Input } from "@/components/ui/input";

interface CodeSnippet {
  id: string;
  title: string;
  description: string;
  code: string;
  language: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  category: string;
  tags: string[];
  expectedOutput?: string;
  explanation?: string;
  learningGoals: string[];
  commonMistakes: string[];
  tips: string[];
  author: string;
  rating: number;
  completions: number;
  estimatedTime: number;
}

interface InteractiveCodeSnippetsProps {
  onSnippetSelect?: (snippet: CodeSnippet) => void;
  selectedCategory?: string;
}

export function InteractiveCodeSnippets({ onSnippetSelect, selectedCategory }: InteractiveCodeSnippetsProps) {
  const [snippets, setSnippets] = useState<CodeSnippet[]>([]);
  const [selectedSnippet, setSelectedSnippet] = useState<CodeSnippet | null>(null);
  const [userCode, setUserCode] = useState("");
  const [output, setOutput] = useState("");
  const [isExecuting, setIsExecuting] = useState(false);
  const [filterCategory, setFilterCategory] = useState(selectedCategory || "all");
  const [filterDifficulty, setFilterDifficulty] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  // Sample interactive code snippets
  useEffect(() => {
    const sampleSnippets: CodeSnippet[] = [
      {
        id: "1",
        title: "Array Methods Mastery",
        description: "Learn essential array methods: map, filter, reduce",
        code: "const numbers = [1, 2, 3, 4, 5];\n\n// TODO: Use map to double each number\nconst doubled = numbers.map(num => num * 2);\n\n// TODO: Use filter to get even numbers only\nconst evens = numbers.filter(num => num % 2 === 0);\n\n// TODO: Use reduce to sum all numbers\nconst sum = numbers.reduce((acc, num) => acc + num, 0);\n\nconsole.log('Doubled:', doubled);\nconsole.log('Evens:', evens);\nconsole.log('Sum:', sum);",
        language: "javascript",
        difficulty: "beginner",
        category: "fundamentals",
        tags: ["arrays", "methods", "functional-programming"],
        expectedOutput: "Doubled: [2, 4, 6, 8, 10]\nEvens: [2, 4]\nSum: 15",
        explanation: "Array methods are fundamental tools for data manipulation in JavaScript. Map transforms elements, filter selects elements based on conditions, and reduce combines elements into a single value.",
        learningGoals: [
          "Understand array transformation with map()",
          "Learn filtering techniques with filter()",
          "Master data aggregation using reduce()"
        ],
        commonMistakes: [
          "Forgetting to return values in map callback",
          "Mutating original array instead of creating new one",
          "Not providing initial value for reduce"
        ],
        tips: [
          "Always return a value in map callback",
          "Use descriptive variable names",
          "Chain methods for complex operations"
        ],
        author: "CodeMaster_JS",
        rating: 4.8,
        completions: 1247,
        estimatedTime: 15
      },
      {
        id: "2",
        title: "Async/Await Pattern",
        description: "Master asynchronous JavaScript with modern syntax",
        code: "// Simulated API calls\nconst fetchUser = (id) => {\n  return new Promise(resolve => {\n    setTimeout(() => {\n      resolve({ id, name: `User ${id}`, email: `user${id}@example.com` });\n    }, 1000);\n  });\n};\n\nconst fetchPosts = (userId) => {\n  return new Promise(resolve => {\n    setTimeout(() => {\n      resolve([\n        { id: 1, title: 'Post 1', userId },\n        { id: 2, title: 'Post 2', userId }\n      ]);\n    }, 800);\n  });\n};\n\n// TODO: Use async/await to fetch user and their posts\nasync function getUserWithPosts(userId) {\n  try {\n    const user = await fetchUser(userId);\n    const posts = await fetchPosts(userId);\n    return { user, posts };\n  } catch (error) {\n    console.error('Error:', error);\n  }\n}\n\n// Execute the function\ngetUserWithPosts(1).then(result => {\n  console.log('Result:', result);\n});",
        language: "javascript",
        difficulty: "intermediate",
        category: "async",
        tags: ["promises", "async-await", "error-handling"],
        expectedOutput: "Result: { user: { id: 1, name: 'User 1', email: 'user1@example.com' }, posts: [{ id: 1, title: 'Post 1', userId: 1 }, { id: 2, title: 'Post 2', userId: 1 }] }",
        explanation: "Async/await provides a cleaner way to handle asynchronous operations compared to callback chains or Promise.then().",
        learningGoals: [
          "Understand Promise-based asynchronous programming",
          "Learn async/await syntax and best practices",
          "Implement proper error handling with try/catch"
        ],
        commonMistakes: [
          "Forgetting to use 'await' keyword",
          "Not handling errors properly",
          "Mixing async/await with .then()"
        ],
        tips: [
          "Always wrap async calls in try/catch",
          "Use Promise.all() for parallel execution",
          "Consider loading states in UI applications"
        ],
        author: "AsyncExpert",
        rating: 4.9,
        completions: 892,
        estimatedTime: 20
      },
      {
        id: "3",
        title: "Object Destructuring",
        description: "Extract values from objects and arrays efficiently",
        code: "const user = {\n  id: 1,\n  name: 'John Doe',\n  email: 'john@example.com',\n  address: {\n    street: '123 Main St',\n    city: 'Anytown',\n    zipCode: '12345'\n  },\n  hobbies: ['reading', 'coding', 'gaming']\n};\n\n// TODO: Destructure user properties\nconst { name, email } = user;\n\n// TODO: Destructure nested address with renaming\nconst { address: { city: userCity, zipCode } } = user;\n\n// TODO: Destructure array with default values\nconst [firstHobby, secondHobby, thirdHobby = 'none'] = user.hobbies;\n\n// TODO: Function parameter destructuring\nfunction displayUser({ name, email, address: { city } }) {\n  return `${name} (${email}) lives in ${city}`;\n}\n\nconsole.log('Name:', name);\nconsole.log('Email:', email);\nconsole.log('City:', userCity);\nconsole.log('Zip:', zipCode);\nconsole.log('First hobby:', firstHobby);\nconsole.log('User info:', displayUser(user));",
        language: "javascript",
        difficulty: "intermediate",
        category: "fundamentals",
        tags: ["destructuring", "objects", "arrays", "es6"],
        expectedOutput: "Name: John Doe\nEmail: john@example.com\nCity: Anytown\nZip: 12345\nFirst hobby: reading\nUser info: John Doe (john@example.com) lives in Anytown",
        explanation: "Destructuring assignment allows unpacking values from arrays or properties from objects into distinct variables.",
        learningGoals: [
          "Master object destructuring syntax",
          "Learn nested destructuring patterns",
          "Understand array destructuring with defaults"
        ],
        commonMistakes: [
          "Incorrect nesting syntax",
          "Forgetting to provide default values",
          "Variable name conflicts"
        ],
        tips: [
          "Use renaming to avoid conflicts",
          "Provide defaults for optional properties",
          "Combine with function parameters for cleaner APIs"
        ],
        author: "ES6_Ninja",
        rating: 4.7,
        completions: 1543,
        estimatedTime: 12
      },
      {
        id: "4",
        title: "React Hooks Fundamentals",
        description: "Learn useState and useEffect hooks with practical examples",
        code: "import React, { useState, useEffect } from 'react';\n\n// TODO: Create a counter component using useState\nfunction Counter() {\n  const [count, setCount] = useState(0);\n  const [isEven, setIsEven] = useState(true);\n\n  // TODO: Use useEffect to update isEven when count changes\n  useEffect(() => {\n    setIsEven(count % 2 === 0);\n  }, [count]);\n\n  // TODO: Add cleanup effect for component unmount\n  useEffect(() => {\n    console.log('Counter component mounted');\n    \n    return () => {\n      console.log('Counter component will unmount');\n    };\n  }, []);\n\n  const increment = () => setCount(prev => prev + 1);\n  const decrement = () => setCount(prev => prev - 1);\n  const reset = () => setCount(0);\n\n  return (\n    <div style={{ padding: '20px', textAlign: 'center' }}>\n      <h2>Counter: {count}</h2>\n      <p>Number is: {isEven ? 'Even' : 'Odd'}</p>\n      <button onClick={increment}>+</button>\n      <button onClick={decrement}>-</button>\n      <button onClick={reset}>Reset</button>\n    </div>\n  );\n}\n\n// Usage\nconsole.log('Counter component created');",
        language: "javascript",
        difficulty: "intermediate",
        category: "react",
        tags: ["react", "hooks", "useState", "useEffect"],
        expectedOutput: "Counter component created\nCounter component mounted",
        explanation: "React Hooks allow functional components to use state and lifecycle methods previously only available in class components.",
        learningGoals: [
          "Understand useState for state management",
          "Learn useEffect for side effects",
          "Implement cleanup functions properly"
        ],
        commonMistakes: [
          "Missing dependency arrays in useEffect",
          "Not cleaning up subscriptions",
          "Directly mutating state values"
        ],
        tips: [
          "Always use functional updates for state",
          "Include all dependencies in useEffect array",
          "Use custom hooks for reusable logic"
        ],
        author: "ReactGuru",
        rating: 4.9,
        completions: 2156,
        estimatedTime: 25
      },
      {
        id: "5",
        title: "Python List Comprehensions",
        description: "Create lists efficiently with comprehension syntax",
        code: "# Basic list comprehensions\nnumbers = range(1, 11)\n\n# TODO: Create list of squares\nsquares = [x**2 for x in numbers]\n\n# TODO: Filter even numbers and square them\neven_squares = [x**2 for x in numbers if x % 2 == 0]\n\n# TODO: Nested comprehensions for matrix\nmatrix = [[i*j for j in range(1, 4)] for i in range(1, 4)]\n\n# TODO: Dictionary comprehension\nsquare_dict = {x: x**2 for x in numbers if x <= 5}\n\n# TODO: Set comprehension (unique values)\neven_set = {x for x in numbers if x % 2 == 0}\n\nprint('Numbers:', list(numbers))\nprint('Squares:', squares)\nprint('Even squares:', even_squares)\nprint('Matrix:', matrix)\nprint('Square dict:', square_dict)\nprint('Even set:', even_set)",
        language: "python",
        difficulty: "beginner",
        category: "fundamentals",
        tags: ["python", "comprehensions", "lists", "dictionaries"],
        expectedOutput: "Numbers: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]\nSquares: [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]\nEven squares: [4, 16, 36, 64, 100]\nMatrix: [[1, 2, 3], [2, 4, 6], [3, 6, 9]]\nSquare dict: {1: 1, 2: 4, 3: 9, 4: 16, 5: 25}\nEven set: {2, 4, 6, 8, 10}",
        explanation: "List comprehensions provide a concise way to create lists by applying expressions to sequences with optional filtering.",
        learningGoals: [
          "Master basic list comprehension syntax",
          "Learn conditional filtering in comprehensions",
          "Understand nested and dictionary comprehensions"
        ],
        commonMistakes: [
          "Making comprehensions too complex",
          "Forgetting parentheses for tuples",
          "Not considering memory usage for large lists"
        ],
        tips: [
          "Keep comprehensions simple and readable",
          "Use generator expressions for memory efficiency",
          "Consider regular loops for complex logic"
        ],
        author: "PythonPro",
        rating: 4.6,
        completions: 987,
        estimatedTime: 18
      }
    ];

    setSnippets(sampleSnippets);
    if (sampleSnippets.length > 0) {
      setSelectedSnippet(sampleSnippets[0]);
      setUserCode(sampleSnippets[0].code);
    }
  }, []);

  const filteredSnippets = snippets.filter(snippet => {
    const matchesCategory = filterCategory === "all" || snippet.category === filterCategory;
    const matchesDifficulty = filterDifficulty === "all" || snippet.difficulty === filterDifficulty;
    const matchesSearch = searchTerm === "" || 
      snippet.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      snippet.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      snippet.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    return matchesCategory && matchesDifficulty && matchesSearch;
  });

  const selectSnippet = (snippet: CodeSnippet) => {
    setSelectedSnippet(snippet);
    setUserCode(snippet.code);
    setOutput("");
    onSnippetSelect?.(snippet);
  };

  const executeCode = async () => {
    if (!userCode.trim()) return;

    setIsExecuting(true);
    try {
      // Mock execution - would integrate with actual code execution service
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (selectedSnippet?.expectedOutput) {
        setOutput(selectedSnippet.expectedOutput);
      } else {
        setOutput("Code executed successfully");
      }
    } catch (error) {
      setOutput(`Error: ${error}`);
    } finally {
      setIsExecuting(false);
    }
  };

  const copyCode = () => {
    navigator.clipboard.writeText(userCode);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-100 text-green-700";
      case "intermediate": return "bg-yellow-100 text-yellow-700";
      case "advanced": return "bg-red-100 text-red-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Interactive Code Snippets</h2>
        <Badge variant="outline" className="text-sm">
          {filteredSnippets.length} snippets available
        </Badge>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search snippets..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Category</label>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="fundamentals">Fundamentals</SelectItem>
                  <SelectItem value="async">Async Programming</SelectItem>
                  <SelectItem value="react">React</SelectItem>
                  <SelectItem value="algorithms">Algorithms</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Difficulty</label>
              <Select value={filterDifficulty} onValueChange={setFilterDifficulty}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="beginner">Beginner</SelectItem>
                  <SelectItem value="intermediate">Intermediate</SelectItem>
                  <SelectItem value="advanced">Advanced</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Language</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="All Languages" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Languages</SelectItem>
                  <SelectItem value="javascript">JavaScript</SelectItem>
                  <SelectItem value="python">Python</SelectItem>
                  <SelectItem value="java">Java</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Snippet List */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Available Snippets</h3>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {filteredSnippets.map((snippet) => (
              <Card 
                key={snippet.id} 
                className={`cursor-pointer transition-colors ${
                  selectedSnippet?.id === snippet.id ? 'border-primary bg-primary/5' : 'hover:bg-muted/50'
                }`}
                onClick={() => selectSnippet(snippet)}
              >
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <div className="flex items-start justify-between">
                      <h4 className="font-medium text-sm">{snippet.title}</h4>
                      <Badge className={`text-xs ${getDifficultyColor(snippet.difficulty)}`}>
                        {snippet.difficulty}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{snippet.description}</p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {snippet.estimatedTime}m
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="h-3 w-3" />
                        {snippet.rating}
                      </div>
                      <div className="flex items-center gap-1">
                        <CheckCircle className="h-3 w-3" />
                        {snippet.completions}
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {snippet.tags.slice(0, 3).map((tag, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Code Editor and Details */}
        <div className="lg:col-span-2 space-y-6">
          {selectedSnippet && (
            <>
              {/* Snippet Details */}
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Code className="h-5 w-5" />
                        {selectedSnippet.title}
                      </CardTitle>
                      <p className="text-muted-foreground mt-1">{selectedSnippet.description}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getDifficultyColor(selectedSnippet.difficulty)}>
                        {selectedSnippet.difficulty}
                      </Badge>
                      <Badge variant="outline">{selectedSnippet.language}</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="explanation" className="w-full">
                    <TabsList className="grid w-full grid-cols-4">
                      <TabsTrigger value="explanation">
                        <BookOpen className="h-4 w-4 mr-1" />
                        Explanation
                      </TabsTrigger>
                      <TabsTrigger value="goals">
                        <Target className="h-4 w-4 mr-1" />
                        Goals
                      </TabsTrigger>
                      <TabsTrigger value="tips">
                        <Lightbulb className="h-4 w-4 mr-1" />
                        Tips
                      </TabsTrigger>
                      <TabsTrigger value="mistakes">
                        <XCircle className="h-4 w-4 mr-1" />
                        Mistakes
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="explanation" className="mt-4">
                      <p className="text-sm text-muted-foreground">{selectedSnippet.explanation}</p>
                    </TabsContent>

                    <TabsContent value="goals" className="mt-4">
                      <ul className="space-y-2">
                        {selectedSnippet.learningGoals.map((goal, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                            {goal}
                          </li>
                        ))}
                      </ul>
                    </TabsContent>

                    <TabsContent value="tips" className="mt-4">
                      <ul className="space-y-2">
                        {selectedSnippet.tips.map((tip, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <Lightbulb className="h-4 w-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                            {tip}
                          </li>
                        ))}
                      </ul>
                    </TabsContent>

                    <TabsContent value="mistakes" className="mt-4">
                      <ul className="space-y-2">
                        {selectedSnippet.commonMistakes.map((mistake, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <XCircle className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
                            {mistake}
                          </li>
                        ))}
                      </ul>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>

              {/* Code Editor */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Interactive Code Editor</CardTitle>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" onClick={copyCode}>
                        <Copy className="h-4 w-4 mr-1" />
                        Copy
                      </Button>
                      <Button variant="outline" size="sm">
                        <Share className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                      <Button onClick={executeCode} disabled={isExecuting}>
                        {isExecuting ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-1" />
                        ) : (
                          <Play className="h-4 w-4 mr-1" />
                        )}
                        Run Code
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    value={userCode}
                    onChange={(e) => setUserCode(e.target.value)}
                    className="min-h-64 font-mono text-sm"
                    placeholder="Edit the code here..."
                  />
                  
                  {output && (
                    <div className="space-y-2">
                      <h4 className="font-medium text-sm">Output:</h4>
                      <div className="bg-gray-900 text-green-400 p-4 rounded font-mono text-sm whitespace-pre-wrap">
                        {output}
                      </div>
                    </div>
                  )}

                  {selectedSnippet.expectedOutput && (
                    <div className="space-y-2">
                      <h4 className="font-medium text-sm">Expected Output:</h4>
                      <div className="bg-gray-100 p-4 rounded font-mono text-sm whitespace-pre-wrap">
                        {selectedSnippet.expectedOutput}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  );
}