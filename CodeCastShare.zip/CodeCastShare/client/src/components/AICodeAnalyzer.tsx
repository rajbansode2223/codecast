import React, { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { 
  Brain, 
  Zap, 
  Shield, 
  Bug, 
  TrendingUp, 
  Clock, 
  AlertTriangle,
  CheckCircle,
  Target,
  Code,
  BarChart3
} from "lucide-react";

interface AICodeAnalyzerProps {
  videoId: number;
  onAnalysisComplete?: (analysis: any) => void;
}

interface CodeAnalysisResult {
  complexityScore: number;
  performanceMetrics: {
    timeComplexity: string;
    spaceComplexity: string;
    estimatedRuntime: string;
  };
  securityVulnerabilities: string[];
  codeSmells: string[];
  optimizationSuggestions: string[];
  maintainabilityScore: number;
  testability: number;
  industryBenchmarks: {
    ranking: string;
    percentile: number;
  };
}

export function AICodeAnalyzer({ videoId, onAnalysisComplete }: AICodeAnalyzerProps) {
  const [code, setCode] = useState("");
  const [language, setLanguage] = useState("javascript");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<CodeAnalysisResult | null>(null);

  const analyzeCode = async () => {
    if (!code.trim()) return;
    
    setIsAnalyzing(true);
    
    // Simulate AI analysis (in production, this would call actual AI services)
    setTimeout(() => {
      const mockAnalysis: CodeAnalysisResult = {
        complexityScore: Math.floor(Math.random() * 10) + 1,
        performanceMetrics: {
          timeComplexity: "O(n log n)",
          spaceComplexity: "O(n)",
          estimatedRuntime: "12ms"
        },
        securityVulnerabilities: [
          "Potential SQL injection vulnerability",
          "Input validation missing"
        ],
        codeSmells: [
          "Long method detected",
          "Duplicate code blocks found",
          "Complex conditional logic"
        ],
        optimizationSuggestions: [
          "Consider using memoization for recursive calls",
          "Extract method to improve readability",
          "Use more descriptive variable names",
          "Add error handling for edge cases"
        ],
        maintainabilityScore: 78,
        testability: 85,
        industryBenchmarks: {
          ranking: "Senior Level",
          percentile: 82
        }
      };
      
      setAnalysis(mockAnalysis);
      setIsAnalyzing(false);
      onAnalysisComplete?.(mockAnalysis);
    }, 3000);
  };

  const getComplexityColor = (score: number) => {
    if (score <= 3) return "text-green-600";
    if (score <= 6) return "text-yellow-600";
    return "text-red-600";
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-purple-600" />
            AI Code Analyzer
          </CardTitle>
          <CardDescription>
            Get instant AI-powered insights into your code quality, performance, and security
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Programming Language</label>
            <select 
              value={language} 
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full p-2 border rounded-md"
            >
              <option value="javascript">JavaScript</option>
              <option value="python">Python</option>
              <option value="java">Java</option>
              <option value="cpp">C++</option>
              <option value="go">Go</option>
              <option value="rust">Rust</option>
            </select>
          </div>
          
          <div>
            <label className="text-sm font-medium mb-2 block">Code to Analyze</label>
            <Textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Paste your code here for AI analysis..."
              className="min-h-[200px] font-mono text-sm"
            />
          </div>
          
          <Button 
            onClick={analyzeCode} 
            disabled={!code.trim() || isAnalyzing}
            className="w-full"
          >
            {isAnalyzing ? (
              <>
                <Zap className="h-4 w-4 mr-2 animate-spin" />
                Analyzing Code...
              </>
            ) : (
              <>
                <Brain className="h-4 w-4 mr-2" />
                Analyze Code with AI
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {analysis && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Complexity & Performance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Complexity Analysis
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Complexity Score</span>
                <span className={`text-lg font-bold ${getComplexityColor(analysis.complexityScore)}`}>
                  {analysis.complexityScore}/10
                </span>
              </div>
              <Progress value={analysis.complexityScore * 10} className="h-2" />
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Time Complexity:</span>
                  <code className="bg-gray-100 px-2 py-1 rounded text-xs">
                    {analysis.performanceMetrics.timeComplexity}
                  </code>
                </div>
                <div className="flex justify-between">
                  <span>Space Complexity:</span>
                  <code className="bg-gray-100 px-2 py-1 rounded text-xs">
                    {analysis.performanceMetrics.spaceComplexity}
                  </code>
                </div>
                <div className="flex justify-between">
                  <span>Est. Runtime:</span>
                  <span className="text-green-600 font-medium">
                    {analysis.performanceMetrics.estimatedRuntime}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quality Metrics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                Quality Metrics
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Maintainability</span>
                  <span className={`text-lg font-bold ${getScoreColor(analysis.maintainabilityScore)}`}>
                    {analysis.maintainabilityScore}%
                  </span>
                </div>
                <Progress value={analysis.maintainabilityScore} className="h-2" />
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Testability</span>
                  <span className={`text-lg font-bold ${getScoreColor(analysis.testability)}`}>
                    {analysis.testability}%
                  </span>
                </div>
                <Progress value={analysis.testability} className="h-2" />
              </div>
              
              <div className="pt-2">
                <Badge variant="outline" className="text-xs">
                  {analysis.industryBenchmarks.ranking} • Top {analysis.industryBenchmarks.percentile}%
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Security Issues */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-red-500" />
                Security Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {analysis.securityVulnerabilities.length > 0 ? (
                  analysis.securityVulnerabilities.map((vulnerability, index) => (
                    <div key={index} className="flex items-start gap-2 p-2 bg-red-50 rounded-md">
                      <AlertTriangle className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-red-800">{vulnerability}</span>
                    </div>
                  ))
                ) : (
                  <div className="flex items-center gap-2 p-2 bg-green-50 rounded-md">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-green-800">No security issues detected</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Code Smells */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bug className="h-4 w-4 text-orange-500" />
                Code Quality Issues
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {analysis.codeSmells.map((smell, index) => (
                  <div key={index} className="flex items-start gap-2 p-2 bg-orange-50 rounded-md">
                    <AlertTriangle className="h-4 w-4 text-orange-500 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-orange-800">{smell}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Optimization Suggestions */}
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-blue-500" />
                AI Optimization Suggestions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {analysis.optimizationSuggestions.map((suggestion, index) => (
                  <div key={index} className="flex items-start gap-2 p-3 bg-blue-50 rounded-md">
                    <CheckCircle className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-blue-800">{suggestion}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}