import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Navigation } from "@/components/Navigation";
import { CommentSection } from "@/components/CommentSection";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ThumbsUp, ThumbsDown, Bookmark, Eye, Calendar, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useEffect } from "react";
import type { VideoWithCreator, VideoLike } from "@shared/schema";

export default function VideoPlayer() {
  const { id } = useParams();
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: video, isLoading: videoLoading } = useQuery<VideoWithCreator>({
    queryKey: [`/api/videos/${id}`],
    enabled: !!id,
  });

  const { data: userLike } = useQuery<VideoLike | null>({
    queryKey: [`/api/videos/${id}/like`],
    enabled: !!id && isAuthenticated,
    retry: false,
  });

  const likeMutation = useMutation({
    mutationFn: async ({ isLike }: { isLike: boolean }) => {
      await apiRequest("POST", `/api/videos/${id}/like`, { isLike });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/videos/${id}/like`] });
      queryClient.invalidateQueries({ queryKey: [`/api/videos/${id}`] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update like status",
        variant: "destructive",
      });
    },
  });

  // Record watch history when video loads
  useEffect(() => {
    if (video && isAuthenticated) {
      // Mock recording watch time after 5 seconds
      const timer = setTimeout(() => {
        apiRequest("POST", `/api/videos/${id}/watch`, { watchDuration: 5 });
      }, 5000);

      return () => clearTimeout(timer);
    }
  }, [video, isAuthenticated, id]);

  const handleLike = (isLike: boolean) => {
    if (!isAuthenticated) {
      toast({
        title: "Sign in required",
        description: "Please sign in to like videos",
      });
      return;
    }

    likeMutation.mutate({ isLike });
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getDifficultyVariant = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case 'beginner':
        return 'secondary';
      case 'intermediate':
        return 'default';
      case 'advanced':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  if (videoLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation searchQuery="" onSearchChange={() => {}} />
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div className="aspect-video bg-muted rounded-xl animate-pulse"></div>
              <div className="space-y-4">
                <div className="h-8 bg-muted rounded animate-pulse"></div>
                <div className="h-4 bg-muted rounded w-3/4 animate-pulse"></div>
                <div className="h-16 bg-muted rounded animate-pulse"></div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="h-6 bg-muted rounded animate-pulse"></div>
              <div className="space-y-2">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="h-20 bg-muted rounded animate-pulse"></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!video) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation searchQuery="" onSearchChange={() => {}} />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-16">
            <h1 className="text-2xl font-bold text-foreground mb-2">Video not found</h1>
            <p className="text-muted-foreground">The video you're looking for doesn't exist.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation searchQuery="" onSearchChange={() => {}} />
      
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Video Player Column */}
          <div className="lg:col-span-2">
            {/* Video Player */}
            <div className="bg-black rounded-xl overflow-hidden mb-6">
              <div className="aspect-video bg-black flex items-center justify-center">
                {video.embedUrl ? (
                  <iframe
                    src={video.embedUrl.replace('watch?v=', 'embed/')}
                    className="w-full h-full"
                    allowFullScreen
                    title={video.title}
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-muted-foreground">
                    <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mb-4">
                      <div className="w-0 h-0 border-l-8 border-l-primary border-y-4 border-y-transparent ml-1"></div>
                    </div>
                    <p>Video player would appear here</p>
                  </div>
                )}
              </div>
            </div>
            
            {/* Video Info */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <h1 className="text-2xl font-bold text-foreground flex-1">{video.title}</h1>
                  <Badge variant={getDifficultyVariant(video.difficulty)} className="ml-4">
                    {video.difficulty}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-4">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={video.creator.profileImageUrl || undefined} />
                      <AvatarFallback>
                        {video.creator.firstName?.[0] || video.creator.email?.[0] || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-foreground">
                        {video.creator.firstName && video.creator.lastName 
                          ? `${video.creator.firstName} ${video.creator.lastName}`
                          : video.creator.email
                        }
                      </h3>
                      <p className="text-sm text-muted-foreground">Creator</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button
                      variant={userLike?.isLike === true ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleLike(true)}
                      disabled={likeMutation.isPending}
                    >
                      <ThumbsUp className="w-4 h-4 mr-1" />
                      {video.likes}
                    </Button>
                    <Button
                      variant={userLike?.isLike === false ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleLike(false)}
                      disabled={likeMutation.isPending}
                    >
                      <ThumbsDown className="w-4 h-4 mr-1" />
                      {video.dislikes}
                    </Button>
                    <Button variant="outline" size="sm">
                      <Bookmark className="w-4 h-4 mr-1" />
                      Save
                    </Button>
                  </div>
                </div>

                {/* Video Stats */}
                <div className="flex items-center space-x-6 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Eye className="w-4 h-4 mr-1" />
                    {video.views.toLocaleString()} views
                  </div>
                  {video.duration && (
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {formatDuration(video.duration)}
                    </div>
                  )}
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-1" />
                    {formatDate(video.createdAt!)}
                  </div>
                </div>
                
                <Separator className="my-4" />
                
                {/* Description */}
                {video.description && (
                  <div className="mb-4">
                    <p className="text-muted-foreground whitespace-pre-wrap">
                      {video.description}
                    </p>
                  </div>
                )}
                
                {/* Tags */}
                {video.tags && video.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {video.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* Comments Section */}
            <CommentSection videoId={parseInt(id!)} />
          </div>
          
          {/* Related Videos Sidebar */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Related Videos</h3>
            <p className="text-muted-foreground text-sm">Related videos will appear here</p>
          </div>
        </div>
      </div>
    </div>
  );
}
