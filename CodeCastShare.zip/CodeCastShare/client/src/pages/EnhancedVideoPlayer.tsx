import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CommentSection } from "@/components/CommentSection";
import { CodeChallenge } from "@/components/CodeChallenge";
import { CodeReview } from "@/components/CodeReview";
import { 
  ThumbsUp, 
  ThumbsDown, 
  Share, 
  Bookmark, 
  Eye, 
  Calendar,
  User,
  Clock,
  Code,
  Github,
  ExternalLink,
  Trophy,
  BookOpen,
  Zap,
  Target,
  Brain,
  Building,
  CheckCircle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function EnhancedVideoPlayer() {
  const params = useParams();
  const videoId = params.id ? parseInt(params.id) : null;
  const { toast } = useToast();
  const [isLiked, setIsLiked] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);

  const { data: video, isLoading } = useQuery({
    queryKey: ["/api/videos", videoId],
    enabled: !!videoId,
  });

  // Enhanced video data with developer features
  const enhancedVideo = video ? {
    ...video,
    codeSnippets: ["const [state, setState] = useState(null);", "useEffect(() => { fetchData(); }, []);"],
    githubRepo: "https://github.com/user/react-tutorial",
    stackOverflowLinks: ["https://stackoverflow.com/questions/123456", "https://stackoverflow.com/questions/789012"],
    prerequisites: ["Basic JavaScript", "ES6 Syntax", "HTML/CSS"],
    learningOutcomes: ["Master React Hooks", "Build Dynamic UIs", "Handle State Management"],
    industryRelevance: ["Frontend Development", "Web Applications", "Modern JavaScript"],
    hasLiveDemo: true,
    complexity: 6,
    challenges: [
      {
        id: 1,
        title: "Implement useState Hook",
        description: "Create a counter component using the useState hook",
        startingCode: "import React from 'react';\n\nfunction Counter() {\n  // Your code here\n  return (\n    <div>\n      {/* Counter UI */}\n    </div>\n  );\n}",
        language: "javascript",
        difficulty: "Easy",
        hints: ["Use useState to manage the counter value", "Add buttons for increment and decrement"],
        testCases: ["Counter should start at 0", "Increment should add 1", "Decrement should subtract 1"]
      }
    ],
    codeReviews: [
      {
        id: 1,
        videoId: videoId || 1,
        videoTitle: video.title,
        codeSubmission: "const [count, setCount] = useState(0);\nconst increment = () => setCount(count + 1);",
        status: "pending",
        submitter: {
          id: "1",
          firstName: "Alex",
          lastName: "Developer",
          profileImageUrl: ""
        },
        createdAt: new Date().toISOString()
      }
    ]
  } : null;

  if (!videoId) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Video not found</h1>
          <p className="text-gray-600">The video you're looking for doesn't exist.</p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading video...</p>
        </div>
      </div>
    );
  }

  if (!enhancedVideo) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Video not found</h1>
          <p className="text-gray-600">The video you're looking for doesn't exist.</p>
        </div>
      </div>
    );
  }

  const handleLike = () => {
    setIsLiked(!isLiked);
    if (isDisliked) setIsDisliked(false);
    toast({
      title: isLiked ? "Like removed" : "Video liked",
      description: isLiked ? "You removed your like" : "Thanks for your feedback!",
    });
  };

  const handleDislike = () => {
    setIsDisliked(!isDisliked);
    if (isLiked) setIsLiked(false);
    toast({
      title: isDisliked ? "Dislike removed" : "Feedback recorded",
      description: isDisliked ? "You removed your dislike" : "Thanks for your feedback!",
    });
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast({
      title: "Link copied",
      description: "Video link has been copied to clipboard",
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
    }
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`;
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Video Player */}
        <Card>
          <CardContent className="p-0">
            <div className="aspect-video bg-black rounded-t-lg relative">
              {enhancedVideo.embedUrl ? (
                <iframe
                  src={enhancedVideo.embedUrl}
                  className="w-full h-full rounded-t-lg"
                  allowFullScreen
                  title={enhancedVideo.title}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-white">
                  <p>Video not available</p>
                </div>
              )}
              
              {/* Live Demo Indicator */}
              {enhancedVideo.hasLiveDemo && (
                <div className="absolute top-4 right-4 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1">
                  <Zap className="h-3 w-3" />
                  Live Demo
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Video Info and Developer Features */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3 space-y-6">
            {/* Basic Video Info */}
            <Card>
              <CardHeader>
                <div className="flex flex-wrap gap-2 mb-2">
                  <Badge variant="outline">{enhancedVideo.category}</Badge>
                  <Badge variant="secondary">{enhancedVideo.difficulty}</Badge>
                  <Badge className="bg-purple-100 text-purple-800">
                    Complexity: {enhancedVideo.complexity}/10
                  </Badge>
                  {enhancedVideo.tags?.map((tag: string) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
                <CardTitle className="text-2xl">{enhancedVideo.title}</CardTitle>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Eye className="h-4 w-4" />
                    {enhancedVideo.views?.toLocaleString() || 0} views
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    {formatDate(enhancedVideo.createdAt)}
                  </div>
                  {enhancedVideo.duration && (
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {formatDuration(enhancedVideo.duration)}
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Avatar>
                      <AvatarImage src={enhancedVideo.creator?.profileImageUrl} />
                      <AvatarFallback>
                        <User className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">
                        {enhancedVideo.creator?.firstName} {enhancedVideo.creator?.lastName}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button
                      variant={isLiked ? "default" : "outline"}
                      size="sm"
                      onClick={handleLike}
                      className="flex items-center gap-2"
                    >
                      <ThumbsUp className="h-4 w-4" />
                      {(enhancedVideo.likes || 0) + (isLiked ? 1 : 0)}
                    </Button>
                    <Button
                      variant={isDisliked ? "default" : "outline"}
                      size="sm"
                      onClick={handleDislike}
                      className="flex items-center gap-2"
                    >
                      <ThumbsDown className="h-4 w-4" />
                      {(enhancedVideo.dislikes || 0) + (isDisliked ? 1 : 0)}
                    </Button>
                    <Button variant="outline" size="sm" onClick={handleShare}>
                      <Share className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm">
                      <Bookmark className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <Separator className="my-4" />

                {enhancedVideo.description && (
                  <div className="prose max-w-none">
                    <p className="text-gray-700 whitespace-pre-wrap">{enhancedVideo.description}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Developer-focused Tabs */}
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="code">Code</TabsTrigger>
                <TabsTrigger value="challenges">Challenges</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
                <TabsTrigger value="resources">Resources</TabsTrigger>
                <TabsTrigger value="comments">Comments</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Prerequisites */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <BookOpen className="h-5 w-5 text-blue-500" />
                        Prerequisites
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {enhancedVideo.prerequisites?.map((prereq, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          {prereq}
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Learning Outcomes */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Target className="h-5 w-5 text-green-500" />
                        You'll Learn
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {enhancedVideo.learningOutcomes?.map((outcome, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <Brain className="h-4 w-4 text-purple-500" />
                          {outcome}
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Industry Relevance */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Building className="h-5 w-5 text-orange-500" />
                        Industry Use
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {enhancedVideo.industryRelevance?.map((industry, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {industry}
                        </Badge>
                      ))}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="code" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Code className="h-5 w-5 text-blue-500" />
                      Code Snippets from Video
                    </CardTitle>
                    <CardDescription>
                      Key code examples demonstrated in this video
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {enhancedVideo.codeSnippets?.map((snippet, index) => (
                      <div key={index} className="bg-gray-900 text-gray-100 p-4 rounded-lg">
                        <pre className="text-sm overflow-x-auto">
                          <code>{snippet}</code>
                        </pre>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="challenges" className="space-y-4">
                {enhancedVideo.challenges?.map((challenge) => (
                  <CodeChallenge
                    key={challenge.id}
                    challenge={challenge}
                    onSubmit={(code) => console.log("Challenge submission:", code)}
                  />
                ))}
              </TabsContent>

              <TabsContent value="reviews" className="space-y-4">
                {enhancedVideo.codeReviews?.map((review) => (
                  <CodeReview
                    key={review.id}
                    review={review}
                    onSubmitReview={(comments, rating) => console.log("Review submitted:", { comments, rating })}
                  />
                ))}
              </TabsContent>

              <TabsContent value="resources" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <ExternalLink className="h-5 w-5 text-blue-500" />
                      External Resources
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {enhancedVideo.githubRepo && (
                      <div className="flex items-center gap-3 p-3 border rounded-lg">
                        <Github className="h-6 w-6 text-gray-700" />
                        <div className="flex-1">
                          <p className="font-medium">GitHub Repository</p>
                          <p className="text-sm text-gray-600">Source code and examples</p>
                        </div>
                        <Button variant="outline" size="sm" asChild>
                          <a href={enhancedVideo.githubRepo} target="_blank" rel="noopener noreferrer">
                            View Code
                          </a>
                        </Button>
                      </div>
                    )}
                    
                    {enhancedVideo.stackOverflowLinks?.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="font-medium">Related Stack Overflow Questions</h4>
                        {enhancedVideo.stackOverflowLinks.map((link, index) => (
                          <div key={index} className="flex items-center gap-3 p-3 border rounded-lg">
                            <ExternalLink className="h-5 w-5 text-orange-500" />
                            <div className="flex-1">
                              <p className="text-sm">Stack Overflow Discussion #{index + 1}</p>
                            </div>
                            <Button variant="outline" size="sm" asChild>
                              <a href={link} target="_blank" rel="noopener noreferrer">
                                View
                              </a>
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="comments">
                <CommentSection videoId={videoId} />
              </TabsContent>
            </Tabs>
          </div>

          {/* Enhanced Sidebar */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-yellow-500" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full" variant="outline">
                  <Code className="h-4 w-4 mr-2" />
                  Try Challenge
                </Button>
                <Button className="w-full" variant="outline">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Add to Learning Path
                </Button>
                <Button className="w-full" variant="outline">
                  <Share className="h-4 w-4 mr-2" />
                  Submit Code Review
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Video Series</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-3">
                  This video is part of the "React Fundamentals" series
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>1. React Basics</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm font-medium text-blue-600">
                    <div className="h-4 w-4 bg-blue-500 rounded-full"></div>
                    <span>2. State Management</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <div className="h-4 w-4 border-2 border-gray-300 rounded-full"></div>
                    <span>3. Advanced Patterns</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}