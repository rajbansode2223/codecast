import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Code, 
  MessageSquare, 
  Star, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  User,
  GitPullRequest
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CodeReviewProps {
  review: {
    id: number;
    videoId: number;
    videoTitle: string;
    codeSubmission: string;
    reviewComments?: string;
    status: string;
    rating?: number;
    submitter: {
      id: string;
      firstName: string;
      lastName: string;
      profileImageUrl?: string;
    };
    reviewer?: {
      id: string;
      firstName: string;
      lastName: string;
      profileImageUrl?: string;
    };
    createdAt: string;
    reviewedAt?: string;
  };
  isReviewer?: boolean;
  onSubmitReview?: (comments: string, rating: number) => void;
  onUpdateSubmission?: (code: string) => void;
}

export function CodeReview({ review, isReviewer, onSubmitReview, onUpdateSubmission }: CodeReviewProps) {
  const [reviewComments, setReviewComments] = useState(review.reviewComments || "");
  const [rating, setRating] = useState(review.rating || 0);
  const [editedCode, setEditedCode] = useState(review.codeSubmission);
  const [isEditing, setIsEditing] = useState(false);
  const { toast } = useToast();

  const handleSubmitReview = () => {
    if (!reviewComments.trim()) {
      toast({
        title: "Review required",
        description: "Please provide review comments",
        variant: "destructive",
      });
      return;
    }

    if (rating === 0) {
      toast({
        title: "Rating required",
        description: "Please provide a rating",
        variant: "destructive",
      });
      return;
    }

    onSubmitReview?.(reviewComments, rating);
    toast({
      title: "Review submitted",
      description: "Your code review has been submitted successfully",
    });
  };

  const handleUpdateCode = () => {
    onUpdateSubmission?.(editedCode);
    setIsEditing(false);
    toast({
      title: "Code updated",
      description: "Your code submission has been updated",
    });
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "reviewed": return "bg-blue-100 text-blue-800";
      case "approved": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const renderStars = (currentRating: number, interactive: boolean = false) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < currentRating
            ? "fill-yellow-400 text-yellow-400"
            : "text-gray-300"
        } ${interactive ? "cursor-pointer hover:text-yellow-400" : ""}`}
        onClick={interactive ? () => setRating(i + 1) : undefined}
      />
    ));
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <CardTitle className="flex items-center gap-2">
              <GitPullRequest className="h-5 w-5 text-blue-500" />
              Code Review #{review.id}
            </CardTitle>
            <CardDescription>
              Submission for: {review.videoTitle}
            </CardDescription>
          </div>
          
          <Badge className={getStatusColor(review.status)}>
            {review.status}
          </Badge>
        </div>

        <div className="flex items-center gap-4 text-sm text-gray-600">
          <div className="flex items-center gap-2">
            <Avatar className="h-6 w-6">
              <AvatarImage src={review.submitter.profileImageUrl} />
              <AvatarFallback className="text-xs">
                {review.submitter.firstName?.[0]}{review.submitter.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            <span>
              Submitted by {review.submitter.firstName} {review.submitter.lastName}
            </span>
          </div>
          
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            {formatDate(review.createdAt)}
          </div>

          {review.reviewer && (
            <div className="flex items-center gap-2">
              <Avatar className="h-6 w-6">
                <AvatarImage src={review.reviewer.profileImageUrl} />
                <AvatarFallback className="text-xs">
                  {review.reviewer.firstName?.[0]}{review.reviewer.lastName?.[0]}
                </AvatarFallback>
              </Avatar>
              <span>
                Reviewed by {review.reviewer.firstName} {review.reviewer.lastName}
              </span>
            </div>
          )}
        </div>
      </CardHeader>

      <CardContent>
        <Tabs defaultValue="code" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="code">Code Submission</TabsTrigger>
            <TabsTrigger value="review">Review</TabsTrigger>
            <TabsTrigger value="discussion">Discussion</TabsTrigger>
          </TabsList>

          <TabsContent value="code" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium flex items-center gap-2">
                <Code className="h-4 w-4" />
                Submitted Code
              </h3>
              
              {!isReviewer && review.status === "pending" && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsEditing(!isEditing)}
                >
                  {isEditing ? "Cancel Edit" : "Edit Code"}
                </Button>
              )}
            </div>

            <div className="space-y-2">
              <Textarea
                value={isEditing ? editedCode : review.codeSubmission}
                onChange={isEditing ? (e) => setEditedCode(e.target.value) : undefined}
                className="min-h-[400px] font-mono text-sm"
                readOnly={!isEditing}
              />
              
              {isEditing && (
                <div className="flex gap-2">
                  <Button onClick={handleUpdateCode}>
                    Save Changes
                  </Button>
                  <Button variant="outline" onClick={() => setIsEditing(false)}>
                    Cancel
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="review" className="space-y-4">
            {isReviewer && review.status === "pending" ? (
              <div className="space-y-4">
                <h3 className="font-medium flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Provide Review
                </h3>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Rating:</label>
                  <div className="flex items-center gap-1">
                    {renderStars(rating, true)}
                    <span className="ml-2 text-sm text-gray-600">
                      {rating > 0 ? `${rating}/5 stars` : "No rating"}
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Review Comments:</label>
                  <Textarea
                    value={reviewComments}
                    onChange={(e) => setReviewComments(e.target.value)}
                    className="min-h-[200px]"
                    placeholder="Provide detailed feedback on the code quality, logic, best practices, and suggestions for improvement..."
                  />
                </div>

                <Button onClick={handleSubmitReview} className="w-full">
                  Submit Review
                </Button>
              </div>
            ) : review.reviewComments ? (
              <div className="space-y-4">
                <h3 className="font-medium flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Review Complete
                </h3>

                {review.rating && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">Rating:</span>
                    <div className="flex items-center gap-1">
                      {renderStars(review.rating)}
                      <span className="text-sm text-gray-600">
                        {review.rating}/5 stars
                      </span>
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <label className="text-sm font-medium">Review Comments:</label>
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm whitespace-pre-wrap">
                      {review.reviewComments}
                    </p>
                  </div>
                </div>

                {review.reviewedAt && (
                  <p className="text-xs text-gray-500">
                    Reviewed on {formatDate(review.reviewedAt)}
                  </p>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">
                  {review.status === "pending" 
                    ? "Waiting for review..." 
                    : "No review available"}
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="discussion" className="space-y-4">
            <div className="text-center py-8">
              <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">
                Discussion features coming soon...
              </p>
              <p className="text-xs text-gray-400 mt-2">
                Real-time chat and threaded discussions for collaborative code review
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}