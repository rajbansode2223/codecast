import React, { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Brain, 
  Star, 
  Clock, 
  Target, 
  Users, 
  MessageCircle,
  Calendar,
  TrendingUp,
  Award,
  BookOpen,
  Zap
} from "lucide-react";

interface MentorProfile {
  id: string;
  name: string;
  avatar: string;
  title: string;
  company: string;
  experience: number;
  specialties: string[];
  rating: number;
  totalMentees: number;
  responseTime: string;
  matchScore: number;
  availableSlots: string[];
  bio: string;
  successStories: number;
}

interface MentorshipMatcherProps {
  currentUserSkills?: string[];
  targetSkills?: string[];
}

export function MentorshipMatcher({ currentUserSkills = [], targetSkills = [] }: MentorshipMatcherProps) {
  const [skillGaps, setSkillGaps] = useState<string[]>([]);
  const [experienceLevel, setExperienceLevel] = useState("intermediate");
  const [learningGoals, setLearningGoals] = useState("");
  const [timeline, setTimeline] = useState("3-months");
  const [mentors, setMentors] = useState<MentorProfile[]>([]);
  const [isMatching, setIsMatching] = useState(false);
  const [selectedMentor, setSelectedMentor] = useState<MentorProfile | null>(null);

  const mockMentors: MentorProfile[] = [
    {
      id: "1",
      name: "Sarah Chen",
      avatar: "/api/placeholder/64/64",
      title: "Senior Frontend Engineer",
      company: "Google",
      experience: 8,
      specialties: ["React", "TypeScript", "Performance Optimization", "System Design"],
      rating: 4.9,
      totalMentees: 45,
      responseTime: "< 2 hours",
      matchScore: 95,
      availableSlots: ["Mon 7-8 PM", "Wed 6-7 PM", "Sat 10-11 AM"],
      bio: "Passionate about helping developers master React ecosystem and build scalable applications. Led frontend teams at Google and Meta.",
      successStories: 12
    },
    {
      id: "2",
      name: "Marcus Rodriguez",
      avatar: "/api/placeholder/64/64",
      title: "Staff Backend Engineer",
      company: "Netflix",
      experience: 12,
      specialties: ["Node.js", "Microservices", "Database Design", "Cloud Architecture"],
      rating: 4.8,
      totalMentees: 38,
      responseTime: "< 4 hours",
      matchScore: 88,
      availableSlots: ["Tue 8-9 PM", "Thu 7-8 PM", "Sun 2-3 PM"],
      bio: "Backend architecture specialist with expertise in scaling systems for millions of users. Former tech lead at Netflix and Spotify.",
      successStories: 8
    },
    {
      id: "3",
      name: "Dr. Priya Patel",
      avatar: "/api/placeholder/64/64",
      title: "ML Engineering Manager",
      company: "OpenAI",
      experience: 10,
      specialties: ["Machine Learning", "Python", "MLOps", "AI Ethics"],
      rating: 4.9,
      totalMentees: 29,
      responseTime: "< 6 hours",
      matchScore: 82,
      availableSlots: ["Mon 6-7 PM", "Fri 5-6 PM"],
      bio: "AI/ML expert focused on practical applications and ethical AI development. PhD in Computer Science, published researcher.",
      successStories: 15
    }
  ];

  const findMentors = async () => {
    setIsMatching(true);
    
    // Simulate AI matching algorithm
    setTimeout(() => {
      const sortedMentors = mockMentors
        .map(mentor => ({
          ...mentor,
          matchScore: Math.floor(Math.random() * 30) + 70 // 70-100% match
        }))
        .sort((a, b) => b.matchScore - a.matchScore);
      
      setMentors(sortedMentors);
      setIsMatching(false);
    }, 2000);
  };

  const requestMentorship = (mentor: MentorProfile) => {
    setSelectedMentor(mentor);
    // In a real app, this would send a mentorship request
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 80) return "text-yellow-600";
    return "text-blue-600";
  };

  const getMatchScoreBg = (score: number) => {
    if (score >= 90) return "bg-green-100";
    if (score >= 80) return "bg-yellow-100";
    return "bg-blue-100";
  };

  return (
    <div className="space-y-6">
      {/* Mentorship Preferences */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-purple-600" />
            AI-Powered Mentor Matching
          </CardTitle>
          <CardDescription>
            Find the perfect mentor based on your skills, goals, and learning style
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Experience Level</label>
              <select 
                value={experienceLevel} 
                onChange={(e) => setExperienceLevel(e.target.value)}
                className="w-full p-2 border rounded-md"
              >
                <option value="beginner">Beginner (0-2 years)</option>
                <option value="intermediate">Intermediate (2-5 years)</option>
                <option value="advanced">Advanced (5+ years)</option>
              </select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">Learning Timeline</label>
              <select 
                value={timeline} 
                onChange={(e) => setTimeline(e.target.value)}
                className="w-full p-2 border rounded-md"
              >
                <option value="1-month">1 Month (Intensive)</option>
                <option value="3-months">3 Months (Balanced)</option>
                <option value="6-months">6 Months (Comprehensive)</option>
                <option value="ongoing">Ongoing Mentorship</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="text-sm font-medium mb-2 block">Skills to Develop</label>
            <Input
              value={skillGaps.join(", ")}
              onChange={(e) => setSkillGaps(e.target.value.split(", ").filter(Boolean))}
              placeholder="React, TypeScript, System Design, etc."
            />
          </div>
          
          <div>
            <label className="text-sm font-medium mb-2 block">Learning Goals</label>
            <Textarea
              value={learningGoals}
              onChange={(e) => setLearningGoals(e.target.value)}
              placeholder="Describe what you want to achieve (e.g., land a senior role, build scalable apps, etc.)"
              rows={3}
            />
          </div>
          
          <Button onClick={findMentors} disabled={isMatching} className="w-full">
            {isMatching ? (
              <>
                <Zap className="h-4 w-4 mr-2 animate-spin" />
                Finding Perfect Mentors...
              </>
            ) : (
              <>
                <Brain className="h-4 w-4 mr-2" />
                Find AI-Matched Mentors
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Mentor Results */}
      {mentors.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-gray-900">Your AI-Matched Mentors</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {mentors.map((mentor) => (
              <Card key={mentor.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={mentor.avatar} />
                        <AvatarFallback>{mentor.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold text-lg">{mentor.name}</h3>
                        <p className="text-sm text-gray-600">{mentor.title} at {mentor.company}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                          <span className="text-sm font-medium">{mentor.rating}</span>
                          <span className="text-sm text-gray-500">({mentor.totalMentees} mentees)</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className={`px-3 py-1 rounded-full ${getMatchScoreBg(mentor.matchScore)}`}>
                      <span className={`text-sm font-bold ${getMatchScoreColor(mentor.matchScore)}`}>
                        {mentor.matchScore}% Match
                      </span>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-700">{mentor.bio}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {mentor.specialties.map((skill) => (
                      <Badge key={skill} variant="secondary" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-gray-500" />
                      <span>Responds in {mentor.responseTime}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Award className="h-4 w-4 text-gray-500" />
                      <span>{mentor.successStories} success stories</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Target className="h-4 w-4 text-gray-500" />
                      <span>{mentor.experience} years experience</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-gray-500" />
                      <span>{mentor.availableSlots.length} slots available</span>
                    </div>
                  </div>
                  
                  <div className="pt-2">
                    <p className="text-xs font-medium text-gray-600 mb-2">Available Time Slots:</p>
                    <div className="flex flex-wrap gap-1">
                      {mentor.availableSlots.map((slot, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {slot}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    <Button 
                      onClick={() => requestMentorship(mentor)} 
                      className="flex-1"
                      size="sm"
                    >
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Request Mentorship
                    </Button>
                    <Button variant="outline" size="sm">
                      View Profile
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Success Modal */}
      {selectedMentor && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-800">
              <MessageCircle className="h-5 w-5" />
              Mentorship Request Sent!
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-green-700">
              Your mentorship request has been sent to <strong>{selectedMentor.name}</strong>. 
              You'll receive a response within {selectedMentor.responseTime}.
            </p>
            <div className="mt-4 flex gap-2">
              <Button size="sm" variant="outline" onClick={() => setSelectedMentor(null)}>
                Send Another Request
              </Button>
              <Button size="sm">
                View My Requests
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}