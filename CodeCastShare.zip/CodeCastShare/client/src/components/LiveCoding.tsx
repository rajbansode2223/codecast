import { useState, useEffect, useRef, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  RotateCw, 
  Code, 
  Terminal, 
  Save,
  Download,
  Upload,
  Clock,
  Zap,
  Bug,
  CheckCircle,
  XCircle,
  SkipBack,
  SkipForward,
  History,
  Timer
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

interface CodeSnapshot {
  id: string;
  timestamp: number;
  code: string;
  language: string;
  output: string;
  isExecuted: boolean;
  executionTime?: number;
  hasError: boolean;
  errorMessage?: string;
  description?: string;
}

interface LiveCodingProps {
  initialCode?: string;
  language?: string;
  onCodeChange?: (code: string) => void;
  onExecute?: (code: string, language: string) => Promise<{ output: string; error?: string; executionTime: number }>;
}

export function LiveCoding({ 
  initialCode = "", 
  language = "javascript",
  onCodeChange,
  onExecute 
}: LiveCodingProps) {
  const { user, isAuthenticated } = useAuth();
  const [code, setCode] = useState(initialCode);
  const [currentLanguage, setCurrentLanguage] = useState(language);
  const [output, setOutput] = useState("");
  const [isExecuting, setIsExecuting] = useState(false);
  const [snapshots, setSnapshots] = useState<CodeSnapshot[]>([]);
  const [currentSnapshotIndex, setCurrentSnapshotIndex] = useState(-1);
  const [isReplaying, setIsReplaying] = useState(false);
  const [replaySpeed, setReplaySpeed] = useState(1);
  const [sessionStartTime] = useState(Date.now());
  const [lastSaveTime, setLastSaveTime] = useState(Date.now());
  const [autoSaveInterval, setAutoSaveInterval] = useState(10); // seconds
  
  const replayIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const autoSaveIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const codeTextareaRef = useRef<HTMLTextAreaElement>(null);

  // Sample coding session data for demonstration
  useEffect(() => {
    const sampleSnapshots: CodeSnapshot[] = [
      {
        id: "1",
        timestamp: 0,
        code: "// Welcome to Live Coding!\nconsole.log('Hello, World!');",
        language: "javascript",
        output: "",
        isExecuted: false,
        hasError: false,
        description: "Initial setup"
      },
      {
        id: "2", 
        timestamp: 15000,
        code: "// Let's create a function\nfunction greet(name) {\n  return `Hello, ${name}!`;\n}\n\nconsole.log(greet('CodeCast'));",
        language: "javascript",
        output: "Hello, CodeCast!",
        isExecuted: true,
        executionTime: 2.5,
        hasError: false,
        description: "Added greet function"
      },
      {
        id: "3",
        timestamp: 32000,
        code: "// Adding array manipulation\nfunction greet(name) {\n  return `Hello, ${name}!`;\n}\n\nconst names = ['Alice', 'Bob', 'Charlie'];\nnames.forEach(name => {\n  console.log(greet(name));\n});",
        language: "javascript", 
        output: "Hello, Alice!\nHello, Bob!\nHello, Charlie!",
        isExecuted: true,
        executionTime: 4.2,
        hasError: false,
        description: "Array iteration added"
      },
      {
        id: "4",
        timestamp: 48000,
        code: "// Oops, let's fix this bug\nfunction greet(name) {\n  return `Hello, ${name}!`;\n}\n\nconst names = ['Alice', 'Bob', 'Charlie'];\nnames.forEach(name => {\n  console.log(greet(name));\n});\n\n// Calculate average length\nconst avgLength = names.reduce((sum, name) => sum + name.length, 0) / names.length;\nconsole.log(`Average name length: ${avgLength}`);",
        language: "javascript",
        output: "Hello, Alice!\nHello, Bob!\nHello, Charlie!\nAverage name length: 5.666666666666667",
        isExecuted: true,
        executionTime: 3.8,
        hasError: false,
        description: "Added average calculation"
      },
      {
        id: "5",
        timestamp: 65000,
        code: "// Error example - missing bracket\nfunction greet(name) {\n  return `Hello, ${name}!`;\n}\n\nconst names = ['Alice', 'Bob', 'Charlie'];\nnames.forEach(name => {\n  console.log(greet(name)\n});", // Intentional syntax error
        language: "javascript",
        output: "",
        isExecuted: true,
        executionTime: 0,
        hasError: true,
        errorMessage: "SyntaxError: missing ) after argument list",
        description: "Syntax error introduced"
      },
      {
        id: "6",
        timestamp: 78000,
        code: "// Fixed the error!\nfunction greet(name) {\n  return `Hello, ${name}!`;\n}\n\nconst names = ['Alice', 'Bob', 'Charlie'];\nnames.forEach(name => {\n  console.log(greet(name));\n});\n\n// Calculate average length with better formatting\nconst avgLength = names.reduce((sum, name) => sum + name.length, 0) / names.length;\nconsole.log(`Average name length: ${avgLength.toFixed(2)}`);",
        language: "javascript",
        output: "Hello, Alice!\nHello, Bob!\nHello, Charlie!\nAverage name length: 5.67",
        isExecuted: true,
        executionTime: 3.1,
        hasError: false,
        description: "Bug fixed, formatting improved"
      }
    ];

    setSnapshots(sampleSnapshots);
    setCurrentSnapshotIndex(sampleSnapshots.length - 1);
    setCode(sampleSnapshots[sampleSnapshots.length - 1].code);
    setOutput(sampleSnapshots[sampleSnapshots.length - 1].output);
  }, []);

  // Auto-save functionality
  useEffect(() => {
    if (autoSaveInterval > 0) {
      autoSaveIntervalRef.current = setInterval(() => {
        saveSnapshot("Auto-save");
      }, autoSaveInterval * 1000);

      return () => {
        if (autoSaveIntervalRef.current) {
          clearInterval(autoSaveIntervalRef.current);
        }
      };
    }
  }, [autoSaveInterval, code]);

  const saveSnapshot = useCallback((description?: string) => {
    const timestamp = Date.now() - sessionStartTime;
    const newSnapshot: CodeSnapshot = {
      id: `snapshot_${Date.now()}`,
      timestamp,
      code,
      language: currentLanguage,
      output,
      isExecuted: false,
      hasError: false,
      description: description || `Snapshot at ${formatTime(timestamp)}`
    };

    setSnapshots(prev => [...prev, newSnapshot]);
    setCurrentSnapshotIndex(prev => prev + 1);
    setLastSaveTime(Date.now());
  }, [code, currentLanguage, output, sessionStartTime]);

  const executeCode = async () => {
    if (!code.trim()) return;

    setIsExecuting(true);
    try {
      // Mock code execution - in a real implementation, this would send to a backend service
      const mockExecution = await mockCodeExecution(code, currentLanguage);
      
      setOutput(mockExecution.output);
      
      // Save execution snapshot
      const timestamp = Date.now() - sessionStartTime;
      const executionSnapshot: CodeSnapshot = {
        id: `exec_${Date.now()}`,
        timestamp,
        code,
        language: currentLanguage,
        output: mockExecution.output,
        isExecuted: true,
        executionTime: mockExecution.executionTime,
        hasError: !!mockExecution.error,
        errorMessage: mockExecution.error,
        description: `Executed at ${formatTime(timestamp)}`
      };

      setSnapshots(prev => [...prev, executionSnapshot]);
      setCurrentSnapshotIndex(prev => prev + 1);

      onExecute?.(code, currentLanguage);
    } catch (error) {
      setOutput(`Error: ${error}`);
    } finally {
      setIsExecuting(false);
    }
  };

  const mockCodeExecution = async (code: string, lang: string): Promise<{ output: string; error?: string; executionTime: number }> => {
    // Simulate execution delay
    await new Promise(resolve => setTimeout(resolve, Math.random() * 1000 + 500));

    const executionTime = Math.random() * 10 + 1;

    // Simple mock execution based on language
    if (lang === "javascript") {
      try {
        // Check for syntax errors
        if (code.includes("console.log(greet(name)") && !code.includes("console.log(greet(name))")) {
          return {
            output: "",
            error: "SyntaxError: missing ) after argument list",
            executionTime: 0
          };
        }

        // Mock successful outputs based on code content
        if (code.includes("console.log('Hello, World!')")) {
          return { output: "Hello, World!", executionTime };
        }
        if (code.includes("greet('CodeCast')")) {
          return { output: "Hello, CodeCast!", executionTime };
        }
        if (code.includes("forEach") && code.includes("greet")) {
          return { 
            output: "Hello, Alice!\nHello, Bob!\nHello, Charlie!" + 
                   (code.includes("avgLength") ? "\nAverage name length: 5.67" : ""), 
            executionTime 
          };
        }
        
        return { output: "Code executed successfully", executionTime };
      } catch (error) {
        return { output: "", error: `Error: ${error}`, executionTime: 0 };
      }
    }

    return { output: `${lang} execution not implemented in demo`, executionTime };
  };

  const jumpToSnapshot = (index: number) => {
    if (index >= 0 && index < snapshots.length) {
      const snapshot = snapshots[index];
      setCode(snapshot.code);
      setOutput(snapshot.output);
      setCurrentLanguage(snapshot.language);
      setCurrentSnapshotIndex(index);
      setIsReplaying(false);
    }
  };

  const startReplay = () => {
    if (snapshots.length === 0) return;

    setIsReplaying(true);
    setCurrentSnapshotIndex(0);
    jumpToSnapshot(0);

    let currentIndex = 0;
    replayIntervalRef.current = setInterval(() => {
      currentIndex++;
      if (currentIndex >= snapshots.length) {
        setIsReplaying(false);
        if (replayIntervalRef.current) {
          clearInterval(replayIntervalRef.current);
        }
        return;
      }
      jumpToSnapshot(currentIndex);
    }, 2000 / replaySpeed);
  };

  const stopReplay = () => {
    setIsReplaying(false);
    if (replayIntervalRef.current) {
      clearInterval(replayIntervalRef.current);
    }
  };

  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getCurrentSnapshot = () => {
    return currentSnapshotIndex >= 0 ? snapshots[currentSnapshotIndex] : null;
  };

  const handleCodeChange = (newCode: string) => {
    setCode(newCode);
    onCodeChange?.(newCode);
  };

  const currentSnapshot = getCurrentSnapshot();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Code className="h-6 w-6" />
          <h2 className="text-2xl font-bold">Live Coding Session</h2>
          {isReplaying && (
            <Badge variant="secondary" className="animate-pulse">
              <Play className="h-3 w-3 mr-1" />
              Replaying
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline">
            <Timer className="h-3 w-3 mr-1" />
            {formatTime(Date.now() - sessionStartTime)}
          </Badge>
          <Badge variant="outline">
            {snapshots.length} snapshots
          </Badge>
        </div>
      </div>

      {/* Timeline Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <History className="h-5 w-5" />
            Rewindable Timeline
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Timeline Slider */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Session Start</span>
              <span>Current: {currentSnapshot ? formatTime(currentSnapshot.timestamp) : "0:00"}</span>
              <span>{snapshots.length > 0 ? formatTime(snapshots[snapshots.length - 1].timestamp) : "0:00"}</span>
            </div>
            <Slider
              value={[currentSnapshotIndex]}
              onValueChange={([value]) => jumpToSnapshot(value)}
              max={Math.max(0, snapshots.length - 1)}
              min={0}
              step={1}
              className="w-full"
              disabled={isReplaying}
            />
          </div>

          {/* Control Buttons */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => jumpToSnapshot(Math.max(0, currentSnapshotIndex - 1))}
                disabled={currentSnapshotIndex <= 0 || isReplaying}
              >
                <SkipBack className="h-4 w-4" />
              </Button>
              
              {isReplaying ? (
                <Button variant="outline" size="sm" onClick={stopReplay}>
                  <Pause className="h-4 w-4" />
                </Button>
              ) : (
                <Button variant="outline" size="sm" onClick={startReplay} disabled={snapshots.length === 0}>
                  <Play className="h-4 w-4" />
                </Button>
              )}

              <Button
                variant="outline"
                size="sm"
                onClick={() => jumpToSnapshot(Math.min(snapshots.length - 1, currentSnapshotIndex + 1))}
                disabled={currentSnapshotIndex >= snapshots.length - 1 || isReplaying}
              >
                <SkipForward className="h-4 w-4" />
              </Button>

              <Button variant="outline" size="sm" onClick={() => jumpToSnapshot(0)} disabled={isReplaying}>
                <RotateCcw className="h-4 w-4" />
              </Button>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Speed:</span>
              <Select value={replaySpeed.toString()} onValueChange={(value) => setReplaySpeed(parseFloat(value))}>
                <SelectTrigger className="w-20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0.5">0.5x</SelectItem>
                  <SelectItem value="1">1x</SelectItem>
                  <SelectItem value="2">2x</SelectItem>
                  <SelectItem value="4">4x</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Current Snapshot Info */}
          {currentSnapshot && (
            <div className="p-3 bg-muted rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-sm">{currentSnapshot.description}</span>
                <div className="flex items-center gap-2">
                  {currentSnapshot.isExecuted && (
                    <Badge variant={currentSnapshot.hasError ? "destructive" : "default"} className="text-xs">
                      {currentSnapshot.hasError ? (
                        <XCircle className="h-3 w-3 mr-1" />
                      ) : (
                        <CheckCircle className="h-3 w-3 mr-1" />
                      )}
                      {currentSnapshot.hasError ? "Error" : `${currentSnapshot.executionTime?.toFixed(1)}ms`}
                    </Badge>
                  )}
                  <Badge variant="outline" className="text-xs">
                    {formatTime(currentSnapshot.timestamp)}
                  </Badge>
                </div>
              </div>
              {currentSnapshot.hasError && currentSnapshot.errorMessage && (
                <p className="text-sm text-red-600">{currentSnapshot.errorMessage}</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Main Coding Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Code Editor */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Code className="h-5 w-5" />
                Code Editor
              </CardTitle>
              <div className="flex items-center gap-2">
                <Select value={currentLanguage} onValueChange={setCurrentLanguage} disabled={isReplaying}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="javascript">JavaScript</SelectItem>
                    <SelectItem value="python">Python</SelectItem>
                    <SelectItem value="java">Java</SelectItem>
                    <SelectItem value="cpp">C++</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  onClick={executeCode}
                  disabled={isExecuting || isReplaying}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {isExecuting ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                  ) : (
                    <Play className="h-4 w-4" />
                  )}
                  Run
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Textarea
              ref={codeTextareaRef}
              value={code}
              onChange={(e) => handleCodeChange(e.target.value)}
              className="min-h-96 font-mono text-sm"
              placeholder="Start coding here..."
              disabled={isReplaying}
            />
            <div className="flex items-center justify-between mt-4">
              <Button variant="outline" size="sm" onClick={() => saveSnapshot("Manual save")} disabled={isReplaying}>
                <Save className="h-4 w-4 mr-2" />
                Save Snapshot
              </Button>
              <div className="text-xs text-muted-foreground">
                Last saved: {formatTime(lastSaveTime - sessionStartTime)} ago
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Output Terminal */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Terminal className="h-5 w-5" />
              Output
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96 w-full rounded border bg-gray-900 text-green-400 p-4">
              <pre className="text-sm font-mono whitespace-pre-wrap">
                {output || "No output yet. Run your code to see results."}
              </pre>
            </ScrollArea>
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center gap-2">
                {currentSnapshot?.isExecuted && (
                  <>
                    {currentSnapshot.hasError ? (
                      <Badge variant="destructive" className="text-xs">
                        <Bug className="h-3 w-3 mr-1" />
                        Error
                      </Badge>
                    ) : (
                      <Badge variant="default" className="text-xs">
                        <Zap className="h-3 w-3 mr-1" />
                        {currentSnapshot.executionTime?.toFixed(1)}ms
                      </Badge>
                    )}
                  </>
                )}
              </div>
              <Button variant="outline" size="sm" onClick={() => setOutput("")}>
                Clear
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Snapshot History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Session History ({snapshots.length} snapshots)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-48">
            <div className="space-y-2">
              {snapshots.map((snapshot, index) => (
                <div
                  key={snapshot.id}
                  className={`flex items-center justify-between p-2 rounded cursor-pointer transition-colors ${
                    index === currentSnapshotIndex
                      ? 'bg-primary/10 border border-primary/20'
                      : 'hover:bg-muted/50'
                  }`}
                  onClick={() => jumpToSnapshot(index)}
                >
                  <div className="flex items-center gap-3">
                    <div className="text-sm font-mono text-muted-foreground w-12">
                      #{index + 1}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{snapshot.description}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatTime(snapshot.timestamp)} • {snapshot.language}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {snapshot.isExecuted && (
                      <Badge variant={snapshot.hasError ? "destructive" : "default"} className="text-xs">
                        {snapshot.hasError ? "Error" : "Success"}
                      </Badge>
                    )}
                    <Badge variant="outline" className="text-xs">
                      {snapshot.code.split('\n').length} lines
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}