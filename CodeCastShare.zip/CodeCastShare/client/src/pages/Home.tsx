import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Navigation } from "@/components/Navigation";
import { VideoGrid } from "@/components/VideoGrid";
import { FilterBar } from "@/components/FilterBar";
import { UploadModal } from "@/components/UploadModal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, Clock, Users, Star, ArrowRight, Brain, Zap, Target } from "lucide-react";
import { Link } from "wouter";
import { AIAssistant } from "@/components/AIAssistant";
import type { VideoWithCreator } from "@shared/schema";

interface TrendingCourse {
  id: string;
  title: string;
  instructor: string;
  duration: string;
  level: string;
  category: string;
  rating: number;
  students: number;
  price: string;
  originalPrice?: string;
  description: string;
  thumbnail: string;
  trending: boolean;
  futureScore: number;
  skills: string[];
  jobGrowth: string;
  avgSalary: string;
  completionRate: number;
  lastUpdated: string;
}

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState({
    category: "",
    difficulty: "",
    sortBy: "Latest",
  });
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  
  // Trending courses with strong future prospects
  const trendingCourses: TrendingCourse[] = [
    {
      id: "1",
      title: "AI & Machine Learning with Python",
      instructor: "Dr. Sarah Chen",
      duration: "12 weeks",
      level: "Intermediate",
      category: "AI/ML",
      rating: 4.9,
      students: 15420,
      price: "$89",
      originalPrice: "$199",
      description: "Master AI fundamentals, neural networks, and deploy real ML models to production",
      thumbnail: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=400&h=250&fit=crop",
      trending: true,
      futureScore: 98,
      skills: ["Python", "TensorFlow", "Neural Networks", "Deep Learning"],
      jobGrowth: "+35% annually",
      avgSalary: "$120,000",
      completionRate: 89,
      lastUpdated: "2024-12-01"
    },
    {
      id: "2", 
      title: "Full-Stack Development with Next.js 14",
      instructor: "Alex Rodriguez",
      duration: "10 weeks",
      level: "Intermediate",
      category: "Web Development",
      rating: 4.8,
      students: 12850,
      price: "$79",
      originalPrice: "$159",
      description: "Build modern web applications with React, Next.js, TypeScript, and deploy to production",
      thumbnail: "https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400&h=250&fit=crop",
      trending: true,
      futureScore: 95,
      skills: ["React", "Next.js", "TypeScript", "Tailwind CSS"],
      jobGrowth: "+22% annually",
      avgSalary: "$95,000",
      completionRate: 92,
      lastUpdated: "2024-11-28"
    },
    {
      id: "3",
      title: "Cloud Architecture with AWS",
      instructor: "Michael Thompson",
      duration: "8 weeks",
      level: "Advanced",
      category: "Cloud Computing",
      rating: 4.9,
      students: 9630,
      price: "$99",
      originalPrice: "$249",
      description: "Design scalable cloud solutions, microservices, and implement DevOps best practices",
      thumbnail: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&h=250&fit=crop",
      trending: true,
      futureScore: 97,
      skills: ["AWS", "Docker", "Kubernetes", "Terraform"],
      jobGrowth: "+32% annually",
      avgSalary: "$130,000",
      completionRate: 87,
      lastUpdated: "2024-12-05"
    },
    {
      id: "4",
      title: "Cybersecurity Fundamentals",
      instructor: "Dr. Emily Parker",
      duration: "6 weeks",
      level: "Beginner",
      category: "Security",
      rating: 4.7,
      students: 8940,
      price: "$69",
      originalPrice: "$139",
      description: "Learn ethical hacking, penetration testing, and secure coding practices",
      thumbnail: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=400&h=250&fit=crop",
      trending: true,
      futureScore: 96,
      skills: ["Network Security", "Ethical Hacking", "Risk Assessment"],
      jobGrowth: "+31% annually",
      avgSalary: "$110,000",
      completionRate: 91,
      lastUpdated: "2024-11-25"
    },
    {
      id: "5",
      title: "Blockchain Development",
      instructor: "James Wilson",
      duration: "9 weeks",
      level: "Intermediate",
      category: "Blockchain",
      rating: 4.6,
      students: 7120,
      price: "$119",
      originalPrice: "$299",
      description: "Build DApps, smart contracts, and understand Web3 ecosystem",
      thumbnail: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=400&h=250&fit=crop",
      trending: true,
      futureScore: 94,
      skills: ["Solidity", "Ethereum", "Web3.js", "Smart Contracts"],
      jobGrowth: "+28% annually",
      avgSalary: "$125,000",
      completionRate: 85,
      lastUpdated: "2024-11-30"
    },
    {
      id: "6",
      title: "Data Science with R & Python",
      instructor: "Dr. Lisa Zhang",
      duration: "11 weeks", 
      level: "Intermediate",
      category: "Data Science",
      rating: 4.8,
      students: 11200,
      price: "$85",
      originalPrice: "$179",
      description: "Master data analysis, visualization, and statistical modeling",
      thumbnail: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=250&fit=crop",
      trending: true,
      futureScore: 93,
      skills: ["Python", "R", "Pandas", "Matplotlib", "SQL"],
      jobGrowth: "+25% annually",
      avgSalary: "$105,000",
      completionRate: 88,
      lastUpdated: "2024-12-03"
    }
  ];

  // Debounce search query
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchQuery);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const { data: videosData, isLoading, refetch } = useQuery({
    queryKey: [
      "/api/videos",
      {
        search: debouncedSearch,
        category: filters.category,
        difficulty: filters.difficulty,
        sortBy: filters.sortBy,
      },
    ],
    queryFn: async ({ queryKey }) => {
      const [, params] = queryKey;
      const searchParams = new URLSearchParams();
      
      Object.entries(params as Record<string, string>).forEach(([key, value]) => {
        if (value) searchParams.append(key, value);
      });

      const response = await fetch(`/api/videos?${searchParams}`);
      if (!response.ok) throw new Error("Failed to fetch videos");
      return response.json();
    },
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "AI/ML": return <Brain className="h-5 w-5" />;
      case "Web Development": return <Zap className="h-5 w-5" />;
      case "Cloud Computing": return <Target className="h-5 w-5" />;
      default: return <Star className="h-5 w-5" />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation 
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onUploadClick={() => setIsUploadModalOpen(true)}
      />

      {/* Hero Section with Trending Courses */}
      <section className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950/30 dark:to-purple-950/30 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-2 mb-4">
              <TrendingUp className="h-8 w-8 text-blue-600" />
              <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Trending Future-Ready Courses
              </h1>
            </div>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Master in-demand skills with our top-rated courses designed for the next generation of technology careers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {trendingCourses.map((course) => (
              <Card key={course.id} className="group hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border-0 bg-white/80 backdrop-blur-sm">
                <div className="relative overflow-hidden rounded-t-lg">
                  <img 
                    src={course.thumbnail} 
                    alt={course.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4 flex gap-2">
                    <Badge className="bg-red-500 hover:bg-red-600 text-white">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      Trending
                    </Badge>
                    <Badge variant="secondary" className="bg-white/90 text-gray-800">
                      Future Score: {course.futureScore}%
                    </Badge>
                  </div>
                  <div className="absolute top-4 right-4">
                    <Badge variant="outline" className="bg-white/90 border-gray-200">
                      {getCategoryIcon(course.category)}
                      <span className="ml-1">{course.category}</span>
                    </Badge>
                  </div>
                </div>

                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start mb-2">
                    <Badge 
                      variant={course.level === 'Beginner' ? 'default' : course.level === 'Intermediate' ? 'secondary' : 'destructive'}
                      className="text-xs"
                    >
                      {course.level}
                    </Badge>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-semibold">{course.rating}</span>
                    </div>
                  </div>
                  
                  <CardTitle className="text-lg leading-tight group-hover:text-blue-600 transition-colors">
                    {course.title}
                  </CardTitle>
                  
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {course.description}
                  </p>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {course.duration}
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      {course.students.toLocaleString()} students
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Job Growth:</span>
                      <span className="font-semibold text-green-600">{course.jobGrowth}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Avg Salary:</span>
                      <span className="font-semibold text-blue-600">{course.avgSalary}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Completion Rate</span>
                      <span className="font-semibold">{course.completionRate}%</span>
                    </div>
                    <Progress value={course.completionRate} className="h-2" />
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {course.skills.slice(0, 3).map((skill, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                    {course.skills.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{course.skills.length - 3} more
                      </Badge>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-blue-600">{course.price}</span>
                      {course.originalPrice && (
                        <span className="text-sm text-muted-foreground line-through">
                          {course.originalPrice}
                        </span>
                      )}
                    </div>
                    <Button className="group-hover:bg-blue-600 group-hover:text-white transition-colors">
                      Enroll Now
                      <ArrowRight className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/categories">
              <Button size="lg" variant="outline" className="group">
                View All Courses
                <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <FilterBar 
        filters={filters}
        onFiltersChange={setFilters}
        totalVideos={videosData?.total || 0}
      />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Latest Video Tutorials</h2>
          <p className="text-muted-foreground">Discover the newest educational content from our community</p>
        </div>
        
        <VideoGrid 
          videos={videosData?.videos || []}
          isLoading={isLoading}
          total={videosData?.total || 0}
        />
      </main>

      <UploadModal 
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        onSuccess={() => {
          setIsUploadModalOpen(false);
          refetch();
        }}
      />

      {/* Global AI Assistant */}
      <AIAssistant 
        currentContext={{ 
          page: "Home - Trending Courses",
          userProgress: { coursesViewed: trendingCourses.length }
        }} 
      />
    </div>
  );
}
