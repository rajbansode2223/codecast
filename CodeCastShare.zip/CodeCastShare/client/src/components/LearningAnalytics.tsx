import React, { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Area,
  AreaChart
} from "recharts";
import { 
  Brain, 
  TrendingUp, 
  Clock, 
  Target, 
  Award,
  BookOpen,
  Code,
  Zap,
  Users,
  CheckCircle2,
  AlertCircle,
  Star
} from "lucide-react";

interface LearningMetrics {
  totalWatchTime: number;
  videosCompleted: number;
  averageComprehension: number;
  skillsGained: string[];
  learningVelocity: number;
  challengesCompleted: number;
  streakDays: number;
  weakAreas: string[];
  strongAreas: string[];
}

interface ProgressData {
  week: string;
  watchTime: number;
  comprehension: number;
  challenges: number;
}

interface SkillProgress {
  skill: string;
  current: number;
  target: number;
  improvement: number;
}

export function LearningAnalytics() {
  const [timeRange, setTimeRange] = useState("30d");
  const [metrics, setMetrics] = useState<LearningMetrics>({
    totalWatchTime: 45.5,
    videosCompleted: 23,
    averageComprehension: 87,
    skillsGained: ["React Hooks", "TypeScript", "Performance Optimization", "Testing"],
    learningVelocity: 92,
    challengesCompleted: 18,
    streakDays: 12,
    weakAreas: ["System Design", "Database Optimization"],
    strongAreas: ["Frontend Development", "JavaScript", "React"]
  });

  const progressData: ProgressData[] = [
    { week: "Week 1", watchTime: 8.5, comprehension: 78, challenges: 3 },
    { week: "Week 2", watchTime: 12.2, comprehension: 82, challenges: 5 },
    { week: "Week 3", watchTime: 15.1, comprehension: 85, challenges: 4 },
    { week: "Week 4", watchTime: 9.7, comprehension: 91, challenges: 6 }
  ];

  const skillProgressData: SkillProgress[] = [
    { skill: "React", current: 85, target: 90, improvement: 12 },
    { skill: "TypeScript", current: 78, target: 85, improvement: 18 },
    { skill: "Node.js", current: 65, target: 80, improvement: 8 },
    { skill: "System Design", current: 45, target: 70, improvement: 5 },
    { skill: "Testing", current: 72, target: 85, improvement: 15 }
  ];

  const activityData = [
    { name: "Mon", value: 3.2 },
    { name: "Tue", value: 4.8 },
    { name: "Wed", value: 2.1 },
    { name: "Thu", value: 5.5 },
    { name: "Fri", value: 4.2 },
    { name: "Sat", value: 6.8 },
    { name: "Sun", value: 1.9 }
  ];

  const comprehensionByCategory = [
    { name: "Frontend", value: 92, color: "#8884d8" },
    { name: "Backend", value: 78, color: "#82ca9d" },
    { name: "DevOps", value: 65, color: "#ffc658" },
    { name: "System Design", value: 58, color: "#ff7c7c" }
  ];

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const getProgressColor = (progress: number, target: number) => {
    const percentage = (progress / target) * 100;
    if (percentage >= 90) return "bg-green-500";
    if (percentage >= 70) return "bg-yellow-500";
    return "bg-red-500";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Learning Analytics</h1>
          <p className="text-gray-600">AI-powered insights into your learning journey</p>
        </div>
        <select 
          value={timeRange} 
          onChange={(e) => setTimeRange(e.target.value)}
          className="px-3 py-2 border rounded-md"
        >
          <option value="7d">Last 7 days</option>
          <option value="30d">Last 30 days</option>
          <option value="90d">Last 3 months</option>
          <option value="1y">Last year</option>
        </select>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Watch Time</p>
                <p className="text-2xl font-bold text-gray-900">{metrics.totalWatchTime}h</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +23% from last month
                </p>
              </div>
              <Clock className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Comprehension</p>
                <p className="text-2xl font-bold text-gray-900">{metrics.averageComprehension}%</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +8% this week
                </p>
              </div>
              <Brain className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Learning Velocity</p>
                <p className="text-2xl font-bold text-gray-900">{metrics.learningVelocity}%</p>
                <p className="text-xs text-yellow-600 flex items-center mt-1">
                  <Target className="h-3 w-3 mr-1" />
                  Above average
                </p>
              </div>
              <Zap className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Streak</p>
                <p className="text-2xl font-bold text-gray-900">{metrics.streakDays} days</p>
                <p className="text-xs text-orange-600 flex items-center mt-1">
                  <Award className="h-3 w-3 mr-1" />
                  Personal best!
                </p>
              </div>
              <Star className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Learning Progress Over Time */}
        <Card>
          <CardHeader>
            <CardTitle>Learning Progress</CardTitle>
            <CardDescription>Weekly watch time and comprehension trends</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={progressData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis />
                <Tooltip />
                <Area 
                  type="monotone" 
                  dataKey="watchTime" 
                  stackId="1"
                  stroke="#8884d8" 
                  fill="#8884d8" 
                  fillOpacity={0.6}
                />
                <Area 
                  type="monotone" 
                  dataKey="comprehension" 
                  stackId="2"
                  stroke="#82ca9d" 
                  fill="#82ca9d" 
                  fillOpacity={0.6}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Daily Activity Heatmap */}
        <Card>
          <CardHeader>
            <CardTitle>Weekly Activity</CardTitle>
            <CardDescription>Hours spent learning each day</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#8884d8" radius={4} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Skill Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Skill Development</CardTitle>
          <CardDescription>Your progress towards skill mastery goals</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {skillProgressData.map((skill) => (
              <div key={skill.skill} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{skill.skill}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600">{skill.current}% / {skill.target}%</span>
                    <Badge 
                      variant="outline" 
                      className={skill.improvement > 10 ? "text-green-700 border-green-200" : "text-blue-700 border-blue-200"}
                    >
                      +{skill.improvement}%
                    </Badge>
                  </div>
                </div>
                <div className="relative">
                  <Progress value={(skill.current / skill.target) * 100} className="h-3" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xs font-medium text-white">
                      {Math.round((skill.current / skill.target) * 100)}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Comprehension by Category */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Comprehension by Category</CardTitle>
            <CardDescription>Understanding levels across different topics</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={comprehensionByCategory}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}%`}
                >
                  {comprehensionByCategory.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Recommendations */}
        <Card>
          <CardHeader>
            <CardTitle>AI Recommendations</CardTitle>
            <CardDescription>Personalized suggestions to accelerate learning</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                <CheckCircle2 className="h-5 w-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="font-medium text-blue-900">Focus on System Design</p>
                  <p className="text-sm text-blue-700">Your weakest area. Spend 30 min daily on system design videos.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                <Target className="h-5 w-5 text-green-600 mt-0.5" />
                <div>
                  <p className="font-medium text-green-900">Maintain React Momentum</p>
                  <p className="text-sm text-green-700">You're excelling in React. Take advanced React patterns course next.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg">
                <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
                <div>
                  <p className="font-medium text-yellow-900">Practice More Challenges</p>
                  <p className="text-sm text-yellow-700">Complete 2-3 coding challenges weekly to improve problem-solving.</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Skills Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              Strong Areas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {metrics.strongAreas.map((area) => (
                <Badge key={area} className="bg-green-100 text-green-800 hover:bg-green-200">
                  {area}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-red-600" />
              Areas for Improvement
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {metrics.weakAreas.map((area) => (
                <Badge key={area} variant="destructive" className="bg-red-100 text-red-800 hover:bg-red-200">
                  {area}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}