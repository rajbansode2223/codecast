import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { LiveChat } from "@/components/LiveChat";
import { WatchParty } from "@/components/WatchParty";
import { PlaylistSystem } from "@/components/PlaylistSystem";
import { SkillLeaderboard } from "@/components/SkillLeaderboard";
import { LiveCoding } from "@/components/LiveCoding";
import { 
  MessageCircle, 
  Users, 
  PlayCircle, 
  Trophy, 
  Video,
  Calendar,
  TrendingUp,
  Star,
  Clock,
  Play,
  Code,
  Zap
} from "lucide-react";

export default function SocialHub() {
  const [selectedVideoId, setSelectedVideoId] = useState<number>(1);

  // Mock video for demonstration
  const mockVideo = {
    id: 1,
    title: "Advanced React Patterns and Performance Optimization",
    thumbnail: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=225&fit=crop",
    duration: 2400,
    creator: "ReactMaster_Pro",
    description: "Learn advanced React patterns including render props, compound components, and performance optimization techniques."
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Social Learning Hub
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Connect, collaborate, and learn together with developers worldwide
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <MessageCircle className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">12.4K</p>
                <p className="text-sm text-muted-foreground">Active Discussions</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <Users className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">3.2K</p>
                <p className="text-sm text-muted-foreground">Watch Parties</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <PlayCircle className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">8.7K</p>
                <p className="text-sm text-muted-foreground">Learning Playlists</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Trophy className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">45K</p>
                <p className="text-sm text-muted-foreground">Skill Achievements</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-100 rounded-lg">
                <Code className="h-5 w-5 text-indigo-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">156</p>
                <p className="text-sm text-muted-foreground">Coding Sessions</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Demo Video Section */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Video className="h-6 w-6 text-blue-600" />
            <CardTitle>Currently Featured: Demo Video</CardTitle>
            <Badge variant="secondary" className="bg-blue-100 text-blue-700">Live Demo</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 p-4 bg-white rounded-lg border">
            <img
              src={mockVideo.thumbnail}
              alt={mockVideo.title}
              className="w-32 h-18 object-cover rounded"
            />
            <div className="flex-1">
              <h3 className="font-semibold text-lg mb-2">{mockVideo.title}</h3>
              <p className="text-muted-foreground text-sm mb-2">{mockVideo.description}</p>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {formatDuration(mockVideo.duration)}
                </div>
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4" />
                  4.9 rating
                </div>
                <div>by {mockVideo.creator}</div>
              </div>
            </div>
            <Button>
              <Play className="h-4 w-4 mr-2" />
              Watch Now
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Main Social Features */}
      <Tabs defaultValue="chat" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="chat" className="flex items-center gap-2">
            <MessageCircle className="h-4 w-4" />
            Live Chat
          </TabsTrigger>
          <TabsTrigger value="party" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Watch Party
          </TabsTrigger>
          <TabsTrigger value="playlists" className="flex items-center gap-2">
            <PlayCircle className="h-4 w-4" />
            Playlists
          </TabsTrigger>
          <TabsTrigger value="leaderboard" className="flex items-center gap-2">
            <Trophy className="h-4 w-4" />
            Leaderboards
          </TabsTrigger>
          <TabsTrigger value="coding" className="flex items-center gap-2">
            <Code className="h-4 w-4" />
            Live Coding
          </TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="h-5 w-5" />
                  Live Discussion
                </CardTitle>
                <p className="text-muted-foreground">
                  Real-time chat with video timestamps and community interaction
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Features</Badge>
                    <span className="text-sm text-muted-foreground">
                      Timestamp linking, reactions, replies, moderation
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Live Mode</Badge>
                    <span className="text-sm text-muted-foreground">
                      Auto-refresh with simulated real-time messages
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="h-96">
              <LiveChat 
                videoId={selectedVideoId} 
                isLive={true}
                onTimestampClick={(timestamp) => console.log('Jump to:', timestamp)}
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="party" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Synchronized Viewing
                </CardTitle>
                <p className="text-muted-foreground">
                  Watch videos together with friends in perfect sync
                </p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Features</Badge>
                    <span className="text-sm text-muted-foreground">
                      Party codes, host controls, synchronized playback
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Social</Badge>
                    <span className="text-sm text-muted-foreground">
                      Group chat, user status, viewer list
                    </span>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm font-medium mb-1">Demo Party Code</p>
                    <p className="text-lg font-mono">ABC123</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="h-96">
              <WatchParty 
                videoId={selectedVideoId}
                onTimeSync={(time) => console.log('Sync time:', time)}
                onPlayStateSync={(playing) => console.log('Sync play:', playing)}
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="playlists" className="space-y-6">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PlayCircle className="h-5 w-5" />
                Learning Paths & Playlists
              </CardTitle>
              <p className="text-muted-foreground">
                Organize your learning journey with curated video collections
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Curation</Badge>
                  <span className="text-sm text-muted-foreground">
                    Custom learning paths
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Sharing</Badge>
                  <span className="text-sm text-muted-foreground">
                    Public/private playlists
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Progress</Badge>
                  <span className="text-sm text-muted-foreground">
                    Track completion
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          <PlaylistSystem 
            currentVideoId={selectedVideoId}
            onVideoSelect={(videoId) => setSelectedVideoId(videoId)}
          />
        </TabsContent>

        <TabsContent value="leaderboard" className="space-y-6">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5" />
                Skill Competitions & Rankings
              </CardTitle>
              <p className="text-muted-foreground">
                Compete with developers worldwide and track your skill progression
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Skills</Badge>
                  <span className="text-sm text-muted-foreground">
                    8 technology tracks
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Rankings</Badge>
                  <span className="text-sm text-muted-foreground">
                    Weekly/monthly/all-time
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Achievements</Badge>
                  <span className="text-sm text-muted-foreground">
                    Badges and streaks
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          <SkillLeaderboard selectedSkill="javascript" />
        </TabsContent>

        <TabsContent value="coding" className="space-y-6">
          <div className="grid grid-cols-1 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5" />
                  Interactive Coding Environment
                </CardTitle>
                <p className="text-muted-foreground">
                  Code along with tutorials, rewind your progress, and learn through hands-on practice
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="flex items-center gap-3 p-4 bg-green-50 rounded-lg">
                    <Code className="h-8 w-8 text-green-600" />
                    <div>
                      <p className="font-semibold">24 Active Sessions</p>
                      <p className="text-sm text-muted-foreground">Live coding in progress</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
                    <Clock className="h-8 w-8 text-blue-600" />
                    <div>
                      <p className="font-semibold">Rewindable Timeline</p>
                      <p className="text-sm text-muted-foreground">Jump to any point in session</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-purple-50 rounded-lg">
                    <Zap className="h-8 w-8 text-purple-600" />
                    <div>
                      <p className="font-semibold">Real-time Execution</p>
                      <p className="text-sm text-muted-foreground">Instant code feedback</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">Try Live Coding Demo</h3>
                    <Button asChild>
                      <a href="/live-coding">Open Full Editor</a>
                    </Button>
                  </div>
                  <div className="h-96 border rounded-lg overflow-hidden">
                    <LiveCoding 
                      initialCode="// Welcome to Live Coding Demo!\n// Try editing this code and see the timeline in action\n\nfunction greetUser(name) {\n  return `Hello, ${name}! Welcome to CodeCast`;\n}\n\nconsole.log(greetUser('Developer'));"
                      language="javascript"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Community Stats */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-6 w-6 text-green-600" />
            Community Impact
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-green-600 mb-2">98%</p>
              <p className="text-sm text-muted-foreground">
                of learners say social features improve their learning experience
              </p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-blue-600 mb-2">5.2x</p>
              <p className="text-sm text-muted-foreground">
                higher completion rates with watch parties
              </p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-purple-600 mb-2">45K+</p>
              <p className="text-sm text-muted-foreground">
                active learning communities created
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}