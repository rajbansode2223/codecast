import { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Navigation } from "@/components/Navigation";
import { UploadModal } from "@/components/UploadModal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Video, Eye, ThumbsUp, MessageSquare, Clock, Plus, Edit, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useState } from "react";
import type { VideoWithCreator } from "@shared/schema";

export default function CreatorDashboard() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);

  // Redirect if not authenticated or not a creator
  useEffect(() => {
    if (!authLoading && (!isAuthenticated || (user && user.role !== 'creator' && user.role !== 'admin'))) {
      toast({
        title: "Unauthorized",
        description: "You need creator access to view this page. Redirecting...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, user, toast]);

  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ["/api/creator/analytics"],
    enabled: isAuthenticated && user?.role === 'creator',
    retry: false,
  });

  const { data: videos, isLoading: videosLoading } = useQuery<VideoWithCreator[]>({
    queryKey: ["/api/creator/videos"],
    enabled: isAuthenticated && user?.role === 'creator',
    retry: false,
  });

  const deleteVideoMutation = useMutation({
    mutationFn: async (videoId: number) => {
      await apiRequest("DELETE", `/api/videos/${videoId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/creator/videos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/creator/analytics"] });
      toast({
        title: "Success",
        description: "Video deleted successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete video",
        variant: "destructive",
      });
    },
  });

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  const handleDeleteVideo = (videoId: number) => {
    if (window.confirm('Are you sure you want to delete this video?')) {
      deleteVideoMutation.mutate(videoId);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation searchQuery="" onSearchChange={() => {}} />
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-64"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-32 bg-muted rounded-xl"></div>
              ))}
            </div>
            <div className="h-96 bg-muted rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || (user && user.role !== 'creator' && user.role !== 'admin')) {
    return null; // Will redirect via useEffect
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation 
        searchQuery="" 
        onSearchChange={() => {}} 
        onUploadClick={() => setIsUploadModalOpen(true)}
      />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Creator Dashboard</h1>
          <p className="text-muted-foreground">Manage your content and track performance</p>
        </div>
        
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Views</p>
                  <p className="text-2xl font-bold text-foreground">
                    {analyticsLoading ? "..." : analytics?.totalViews?.toLocaleString() || "0"}
                  </p>
                </div>
                <Eye className="text-primary text-2xl" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Likes</p>
                  <p className="text-2xl font-bold text-foreground">
                    {analyticsLoading ? "..." : analytics?.totalLikes?.toLocaleString() || "0"}
                  </p>
                </div>
                <ThumbsUp className="text-green-400 text-2xl" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Videos Published</p>
                  <p className="text-2xl font-bold text-foreground">
                    {analyticsLoading ? "..." : analytics?.totalVideos || "0"}
                  </p>
                </div>
                <Video className="text-primary text-2xl" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Avg Watch Time</p>
                  <p className="text-2xl font-bold text-foreground">
                    {analyticsLoading ? "..." : formatDuration(analytics?.avgWatchTime || 0)}
                  </p>
                </div>
                <Clock className="text-yellow-400 text-2xl" />
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Video Management */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">Your Videos</CardTitle>
              <Button onClick={() => setIsUploadModalOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Upload New Video
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {videosLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="h-20 bg-muted rounded animate-pulse"></div>
                ))}
              </div>
            ) : videos && videos.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Video</TableHead>
                    <TableHead>Views</TableHead>
                    <TableHead>Likes</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {videos.map((video) => (
                    <TableRow key={video.id}>
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          <div className="w-20 h-12 bg-muted rounded overflow-hidden flex items-center justify-center">
                            <Video className="w-6 h-6 text-muted-foreground" />
                          </div>
                          <div>
                            <h4 className="font-medium text-foreground line-clamp-1">
                              {video.title}
                            </h4>
                            <p className="text-sm text-muted-foreground">
                              {video.duration ? formatDuration(video.duration) : "N/A"} • {formatDate(video.createdAt!)}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-foreground">{video.views.toLocaleString()}</TableCell>
                      <TableCell className="text-foreground">{video.likes}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{video.category}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleDeleteVideo(video.id)}
                            disabled={deleteVideoMutation.isPending}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8">
                <Video className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">No videos yet</h3>
                <p className="text-muted-foreground mb-4">Upload your first video to get started</p>
                <Button onClick={() => setIsUploadModalOpen(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Upload Video
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <UploadModal 
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        onSuccess={() => {
          setIsUploadModalOpen(false);
          queryClient.invalidateQueries({ queryKey: ["/api/creator/videos"] });
          queryClient.invalidateQueries({ queryKey: ["/api/creator/analytics"] });
        }}
      />
    </div>
  );
}
