import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import OpenAI from "openai";
import { insertVideoSchema, insertCommentSchema, insertVideoLikeSchema, insertWatchHistorySchema, insertLearningPathSchema, insertUserProgressSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize OpenAI
  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });

  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Video routes
  app.get('/api/videos', async (req, res) => {
    try {
      const {
        category,
        difficulty,
        tags,
        search,
        sortBy,
        limit = '20',
        offset = '0'
      } = req.query;

      const filters = {
        category: category as string,
        difficulty: difficulty as string,
        tags: tags ? (tags as string).split(',') : undefined,
        search: search as string,
        sortBy: sortBy as string,
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
      };

      const result = await storage.getVideos(filters);
      res.json(result);
    } catch (error) {
      console.error("Error fetching videos:", error);
      res.status(500).json({ message: "Failed to fetch videos" });
    }
  });

  app.get('/api/videos/:id', async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const video = await storage.getVideo(videoId);
      
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }

      // Increment views
      await storage.incrementViews(videoId);
      
      res.json(video);
    } catch (error) {
      console.error("Error fetching video:", error);
      res.status(500).json({ message: "Failed to fetch video" });
    }
  });

  app.post('/api/videos', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || (user.role !== 'creator' && user.role !== 'admin')) {
        return res.status(403).json({ message: "Only creators can upload videos" });
      }

      const videoData = insertVideoSchema.parse({
        ...req.body,
        creatorId: userId,
      });

      const video = await storage.createVideo(videoData);
      res.status(201).json(video);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid video data", errors: error.errors });
      }
      console.error("Error creating video:", error);
      res.status(500).json({ message: "Failed to create video" });
    }
  });

  app.put('/api/videos/:id', isAuthenticated, async (req: any, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const video = await storage.getVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }

      if (video.creatorId !== userId) {
        return res.status(403).json({ message: "You can only edit your own videos" });
      }

      const updates = insertVideoSchema.partial().parse(req.body);
      const updatedVideo = await storage.updateVideo(videoId, updates);
      
      res.json(updatedVideo);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid video data", errors: error.errors });
      }
      console.error("Error updating video:", error);
      res.status(500).json({ message: "Failed to update video" });
    }
  });

  app.delete('/api/videos/:id', isAuthenticated, async (req: any, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const success = await storage.deleteVideo(videoId, userId);
      if (!success) {
        return res.status(404).json({ message: "Video not found or unauthorized" });
      }
      
      res.json({ message: "Video deleted successfully" });
    } catch (error) {
      console.error("Error deleting video:", error);
      res.status(500).json({ message: "Failed to delete video" });
    }
  });

  // Creator specific routes
  app.get('/api/creator/videos', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const videos = await storage.getUserVideos(userId);
      res.json(videos);
    } catch (error) {
      console.error("Error fetching creator videos:", error);
      res.status(500).json({ message: "Failed to fetch videos" });
    }
  });

  app.get('/api/creator/analytics', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || (user.role !== 'creator' && user.role !== 'admin')) {
        return res.status(403).json({ message: "Only creators can access analytics" });
      }

      const analytics = await storage.getCreatorAnalytics(userId);
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching creator analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  // Comment routes
  app.get('/api/videos/:id/comments', async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const comments = await storage.getVideoComments(videoId);
      res.json(comments);
    } catch (error) {
      console.error("Error fetching comments:", error);
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  app.post('/api/videos/:id/comments', isAuthenticated, async (req: any, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const commentData = insertCommentSchema.parse({
        ...req.body,
        videoId,
        userId: req.body.isAnonymous ? null : userId,
      });

      const comment = await storage.createComment(commentData);
      res.status(201).json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid comment data", errors: error.errors });
      }
      console.error("Error creating comment:", error);
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  app.delete('/api/comments/:id', isAuthenticated, async (req: any, res) => {
    try {
      const commentId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Allow deletion if user is admin or comment owner
      const isAdmin = user?.role === 'admin';
      const success = await storage.deleteComment(commentId, isAdmin ? undefined : userId);
      
      if (!success) {
        return res.status(404).json({ message: "Comment not found or unauthorized" });
      }
      
      res.json({ message: "Comment deleted successfully" });
    } catch (error) {
      console.error("Error deleting comment:", error);
      res.status(500).json({ message: "Failed to delete comment" });
    }
  });

  app.post('/api/comments/:id/flag', isAuthenticated, async (req: any, res) => {
    try {
      const commentId = parseInt(req.params.id);
      const success = await storage.flagComment(commentId);
      
      if (!success) {
        return res.status(404).json({ message: "Comment not found" });
      }
      
      res.json({ message: "Comment flagged successfully" });
    } catch (error) {
      console.error("Error flagging comment:", error);
      res.status(500).json({ message: "Failed to flag comment" });
    }
  });

  // Like/Dislike routes
  app.post('/api/videos/:id/like', isAuthenticated, async (req: any, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const { isLike } = req.body;
      
      const like = await storage.toggleVideoLike(videoId, userId, isLike);
      res.json(like);
    } catch (error) {
      console.error("Error toggling video like:", error);
      res.status(500).json({ message: "Failed to toggle like" });
    }
  });

  app.get('/api/videos/:id/like', isAuthenticated, async (req: any, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const like = await storage.getUserVideoLike(videoId, userId);
      res.json(like || null);
    } catch (error) {
      console.error("Error fetching user video like:", error);
      res.status(500).json({ message: "Failed to fetch like status" });
    }
  });

  // Watch history routes
  app.post('/api/videos/:id/watch', isAuthenticated, async (req: any, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const { watchDuration } = req.body;
      
      const historyData = insertWatchHistorySchema.parse({
        videoId,
        userId,
        watchDuration,
      });

      await storage.addWatchHistory(historyData);
      res.json({ message: "Watch history recorded" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid watch data", errors: error.errors });
      }
      console.error("Error recording watch history:", error);
      res.status(500).json({ message: "Failed to record watch history" });
    }
  });

  app.get('/api/user/history', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 10;
      
      const history = await storage.getUserWatchHistory(userId, limit);
      res.json(history);
    } catch (error) {
      console.error("Error fetching watch history:", error);
      res.status(500).json({ message: "Failed to fetch watch history" });
    }
  });

  // AI Assistant API
  app.post('/api/ai/chat', async (req, res) => {
    try {
      const { message, context } = req.body;
      
      if (!message || typeof message !== 'string') {
        return res.status(400).json({ error: 'Message is required' });
      }

      // Create context-aware system prompt
      let systemPrompt = `You are an AI coding assistant for CodeCast, a developer education platform. You help users with:
- Code debugging and explanations
- Learning path recommendations  
- Programming concept clarification
- Best practice guidance
- Career advice for developers

Be helpful, concise, and encouraging. Provide practical examples when possible.`;

      if (context?.page) {
        systemPrompt += `\n\nUser is currently on: ${context.page}`;
      }

      const completion = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: message }
        ],
        max_tokens: 500,
        temperature: 0.7,
      });

      const response = completion.choices[0]?.message?.content;
      
      if (!response) {
        throw new Error('No response from AI');
      }

      res.json({ response });
    } catch (error) {
      console.error("AI chat error:", error);
      res.status(500).json({ error: 'Failed to get AI response' });
    }
  });

  // Admin routes
  app.get('/api/admin/analytics', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const analytics = await storage.getAdminAnalytics();
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching admin analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  app.get('/api/admin/users', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get('/api/admin/flagged-comments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const comments = await storage.getFlaggedComments();
      res.json(comments);
    } catch (error) {
      console.error("Error fetching flagged comments:", error);
      res.status(500).json({ message: "Failed to fetch flagged comments" });
    }
  });

  app.post('/api/admin/comments/:id/moderate', isAuthenticated, async (req: any, res) => {
    try {
      const commentId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { isApproved } = req.body;
      const success = await storage.moderateComment(commentId, isApproved);
      
      if (!success) {
        return res.status(404).json({ message: "Comment not found" });
      }
      
      res.json({ message: "Comment moderated successfully" });
    } catch (error) {
      console.error("Error moderating comment:", error);
      res.status(500).json({ message: "Failed to moderate comment" });
    }
  });

  app.put('/api/admin/users/:id/role', isAuthenticated, async (req: any, res) => {
    try {
      const targetUserId = req.params.id;
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { role } = req.body;
      if (!['viewer', 'creator', 'admin'].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }

      const updatedUser = await storage.updateUserRole(targetUserId, role);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  app.post('/api/admin/users/:id/suspend', isAuthenticated, async (req: any, res) => {
    try {
      const targetUserId = req.params.id;
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const success = await storage.suspendUser(targetUserId);
      if (!success) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ message: "User suspended successfully" });
    } catch (error) {
      console.error("Error suspending user:", error);
      res.status(500).json({ message: "Failed to suspend user" });
    }
  });

  // Categories and trending routes
  app.get('/api/categories', async (req, res) => {
    try {
      // Get all unique categories with video counts
      const categories = [
        { name: 'Frontend', count: 45, description: 'React, Vue, Angular, HTML/CSS' },
        { name: 'Backend', count: 32, description: 'Node.js, Python, Java, APIs' },
        { name: 'Mobile', count: 28, description: 'React Native, Flutter, iOS, Android' },
        { name: 'DevOps', count: 21, description: 'Docker, AWS, CI/CD, Kubernetes' },
        { name: 'Data Science', count: 19, description: 'Python, R, Machine Learning, Analytics' },
        { name: 'Game Development', count: 15, description: 'Unity, Unreal, C#, Game Design' },
        { name: 'Web3', count: 12, description: 'Blockchain, Smart Contracts, Crypto' },
        { name: 'Security', count: 18, description: 'Cybersecurity, Penetration Testing' }
      ];
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get('/api/trending', async (req, res) => {
    try {
      // Get trending videos based on recent views, likes, and engagement
      const trendingVideos = await storage.getVideos({
        sortBy: 'trending',
        limit: 20,
        offset: 0
      });
      
      res.json(trendingVideos);
    } catch (error) {
      console.error("Error fetching trending videos:", error);
      res.status(500).json({ message: "Failed to fetch trending videos" });
    }
  });

  app.get('/api/categories/:category/videos', async (req, res) => {
    try {
      const category = req.params.category;
      const {
        difficulty,
        sortBy = 'newest',
        limit = '20',
        offset = '0'
      } = req.query;

      const filters = {
        category,
        difficulty: difficulty as string,
        sortBy: sortBy as string,
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
      };

      const result = await storage.getVideos(filters);
      res.json(result);
    } catch (error) {
      console.error("Error fetching category videos:", error);
      res.status(500).json({ message: "Failed to fetch category videos" });
    }
  });

  // Learning Paths routes
  app.get('/api/learning-paths', async (req, res) => {
    try {
      const {
        category,
        difficulty,
        search,
        creatorId,
        isPublished,
        limit = '20',
        offset = '0'
      } = req.query;

      const filters = {
        category: category as string,
        difficulty: difficulty as string,
        search: search as string,
        creatorId: creatorId as string,
        isPublished: isPublished === 'true',
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
      };

      const result = await storage.getLearningPaths(filters);
      res.json(result);
    } catch (error) {
      console.error("Error fetching learning paths:", error);
      res.status(500).json({ message: "Failed to fetch learning paths" });
    }
  });

  app.get('/api/learning-paths/:id', async (req, res) => {
    try {
      const pathId = parseInt(req.params.id);
      const path = await storage.getLearningPath(pathId);
      
      if (!path) {
        return res.status(404).json({ message: "Learning path not found" });
      }
      
      res.json(path);
    } catch (error) {
      console.error("Error fetching learning path:", error);
      res.status(500).json({ message: "Failed to fetch learning path" });
    }
  });

  app.get('/api/learning-paths/:id/videos', async (req, res) => {
    try {
      const pathId = parseInt(req.params.id);
      const videos = await storage.getPathVideos(pathId);
      res.json(videos);
    } catch (error) {
      console.error("Error fetching path videos:", error);
      res.status(500).json({ message: "Failed to fetch path videos" });
    }
  });

  app.post('/api/learning-paths', async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub || 'demo-user';
      const pathData = insertLearningPathSchema.parse({
        ...req.body,
        creatorId: userId
      });

      const newPath = await storage.createLearningPath(pathData);
      res.status(201).json(newPath);
    } catch (error) {
      console.error("Error creating learning path:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid path data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create learning path" });
    }
  });

  app.post('/api/learning-paths/:id/enroll', async (req: any, res) => {
    try {
      const pathId = parseInt(req.params.id);
      const userId = req.user?.claims?.sub || 'demo-user';

      const enrollment = await storage.enrollInPath(userId, pathId);
      res.status(201).json(enrollment);
    } catch (error) {
      console.error("Error enrolling in path:", error);
      res.status(500).json({ message: "Failed to enroll in path" });
    }
  });

  app.get('/api/user/enrolled-paths', async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub || 'demo-user';
      const paths = await storage.getUserEnrolledPaths(userId);
      res.json(paths);
    } catch (error) {
      console.error("Error fetching enrolled paths:", error);
      res.status(500).json({ message: "Failed to fetch enrolled paths" });
    }
  });

  app.get('/api/learning-paths/:id/progress', async (req: any, res) => {
    try {
      const pathId = parseInt(req.params.id);
      const userId = req.user?.claims?.sub || 'demo-user';
      
      const progress = await storage.getUserPathProgress(userId, pathId);
      if (!progress) {
        return res.status(404).json({ message: "Not enrolled in this path" });
      }
      
      res.json(progress);
    } catch (error) {
      console.error("Error fetching path progress:", error);
      res.status(500).json({ message: "Failed to fetch path progress" });
    }
  });

  app.post('/api/videos/:id/complete', async (req: any, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const userId = req.user?.claims?.sub || 'demo-user';
      const { pathId } = req.body;

      await storage.markVideoCompleted(userId, videoId, pathId);
      res.json({ message: "Video marked as completed" });
    } catch (error) {
      console.error("Error marking video complete:", error);
      res.status(500).json({ message: "Failed to mark video complete" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
